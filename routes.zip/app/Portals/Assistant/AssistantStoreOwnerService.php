<?php

namespace App\Portals\Assistant;

use App\Models\AdminUser;
use App\Models\AssistantDepartmentOperationScope;
use App\Models\Department;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class AssistantStoreOwnerService
{
    public const OPERATION_DEPARTMENT_CODE = 'dept-000022';

    /**
     * Store ownership is shared by the Operations and Service Operations
     * department trees. Other consumers of operationDepartments() deliberately
     * remain limited to the original Operations tree.
     */
    private const STORE_OWNERSHIP_DEPARTMENT_CODES = [
        self::OPERATION_DEPARTMENT_CODE,
        'dept-000037',
        'dept-000029',
    ];

    /** @return Collection<int, Department> */
    public function operationDepartments(): Collection
    {
        return $this->departmentTrees([self::OPERATION_DEPARTMENT_CODE]);
    }

    /**
     * Departments which an Assistant department may be granted for domain-store
     * ownership. This includes the descendants of both approved root trees.
     *
     * @return Collection<int, Department>
     */
    public function storeOwnershipOperationDepartments(): Collection
    {
        return $this->departmentTrees(self::STORE_OWNERSHIP_DEPARTMENT_CODES);
    }

    /**
     * A root with children is only a visual select-all group. A root without
     * children is itself a leaf and remains selectable for store ownership.
     *
     * @return Collection<int, Department>
     */
    public function storeOwnershipSelectableOperationDepartments(): Collection
    {
        $departments = $this->storeOwnershipOperationDepartments();
        $parentIds = $departments
            ->pluck('parent_id')
            ->filter()
            ->map(static fn (mixed $id): int => (int) $id)
            ->unique();

        return $departments
            ->reject(fn (Department $department): bool => $parentIds->contains((int) $department->getKey()))
            ->values();
    }

    /**
     * Configuration candidates are all business roots and their direct children.
     * Keep the legacy Operations trees above for finance and reporting consumers.
     *
     * @return Collection<int, Department>
     */
    public function scopeConfigurationDepartments(): Collection
    {
        $departments = Department::business()->orderBy('sort')->orderBy('name')->get();
        $children = $departments->groupBy('parent_id');
        $result = collect();

        foreach ($departments->whereNull('parent_id') as $root) {
            $root->setAttribute('tree_depth', 0);
            $result->push($root);
            foreach ($children->get($root->getKey(), collect()) as $child) {
                $child->setAttribute('tree_depth', 1);
                $result->push($child);
            }
        }

        return $result;
    }

    /** @return Collection<int, Department> */
    public function selectableScopeConfigurationDepartments(): Collection
    {
        $departments = $this->scopeConfigurationDepartments();
        $parentIds = $departments->whereNotNull('parent_id')->pluck('parent_id');

        return $departments
            ->reject(fn (Department $department): bool => $department->parent_id === null
                && $parentIds->contains((int) $department->getKey()))
            ->values();
    }

    /**
     * @param list<string> $rootSlugs
     * @return Collection<int, Department>
     */
    private function departmentTrees(array $rootSlugs): Collection
    {
        $roots = Department::business()
            ->whereIn('slug', $rootSlugs)
            ->orderBy('sort')
            ->orderBy('name')
            ->get();
        if ($roots->isEmpty()) {
            return collect();
        }

        $departments = Department::business()
            ->orderBy('sort')
            ->orderBy('name')
            ->get()
            ->keyBy('id');
        $result = collect();
        foreach ($roots as $root) {
            $this->appendDepartmentTree($result, $departments, $root, 0);
        }

        return $result->values();
    }

    public function operationDepartmentForUser(AdminUser $user): ?Department
    {
        return $this->departmentForUserFrom($user, $this->operationDepartments());
    }

    public function storeOwnershipOperationDepartmentForUser(AdminUser $user): ?Department
    {
        return $this->departmentForUserFrom($user, $this->storeOwnershipOperationDepartments());
    }

    /** @param Collection<int, Department> $departmentTree */
    private function departmentForUserFrom(AdminUser $user, Collection $departmentTree): ?Department
    {
        $departmentIds = $departmentTree->pluck('id')->map(static fn ($id): int => (int) $id);
        if ($departmentIds->isEmpty()) return null;

        $rolesTable = config('admin.database.roles_table');
        $departments = $user->departments()
            ->whereIn($rolesTable.'.id', $departmentIds->all())
            ->get([$rolesTable.'.id', $rolesTable.'.name', $rolesTable.'.parent_id']);

        return $departments->first(static fn (Department $department): bool => (bool) ($department->pivot->is_primary ?? false))
            ?: $departments->sortBy('id')->first();
    }

    /** @return Collection<int, Department> */
    public function boundBusinessDepartments(): Collection
    {
        $configuredIds = AssistantDepartmentOperationScope::query()
            ->pluck('operation_department_id')->map(static fn ($id): int => (int) $id)->unique()->values();
        if ($configuredIds->isEmpty()) return collect();

        return Department::business()
            ->whereIn('id', $this->departmentIdsIncludingDescendants($configuredIds->all()))
            ->with('parent:id,name')->orderBy('sort')->orderBy('name')->get();
    }

    public function boundBusinessDepartmentForUser(AdminUser $user): ?Department
    {
        $departmentIds = $this->boundBusinessDepartments()->pluck('id');
        if ($departmentIds->isEmpty()) return null;
        $rolesTable = config('admin.database.roles_table');
        $departments = $user->departments()->whereIn($rolesTable.'.id', $departmentIds->all())
            ->get([$rolesTable.'.id', $rolesTable.'.name', $rolesTable.'.parent_id']);

        return $departments->first(static fn (Department $department): bool => (bool) ($department->pivot->is_primary ?? false))
            ?: $departments->sortBy('id')->first();
    }

    /** @return Collection<int, AdminUser> */
    public function usersInBoundBusinessDepartments(): Collection
    {
        $departmentIds = $this->boundBusinessDepartments()->pluck('id');
        if ($departmentIds->isEmpty()) return collect();

        return AdminUser::query()->where('status', AdminUser::STATUS_ACTIVE)
            ->whereHas('departments', fn ($query) => $query->whereIn('admin_roles.id', $departmentIds->all()))
            ->orderBy('name')->orderBy('username')->get(['id', 'name', 'username'])->unique('id')->values();
    }

    /** @return list<int> */
    public function visibleOperationDepartmentIds(AdminUser $assistantUser): array
    {
        if ($assistantUser->isAdministrator()) {
            return $this->operationDepartments()->pluck('id')->map(static fn ($id): int => (int) $id)->all();
        }

        $assistantRootId = Department::business()->where('slug', AssistantPortalAuthorizationService::EDITOR_DEPARTMENT_CODE)->value('id');
        if ($assistantRootId === null) return [];

        $assistantDepartmentIds = $assistantUser->departments()
            ->where('parent_id', (int) $assistantRootId)
            ->pluck(config('admin.database.roles_table').'.id')
            ->map(static fn ($id): int => (int) $id);
        if ($assistantDepartmentIds->isEmpty()) return [];

        $configuredOperationIds = AssistantDepartmentOperationScope::query()
            ->whereIn('assistant_department_id', $assistantDepartmentIds->all())
            ->pluck('operation_department_id')
            ->map(static fn ($id): int => (int) $id)
            ->unique()
            ->values();

        return $configuredOperationIds->isEmpty()
            ? []
            : $this->departmentIdsIncludingDescendants($configuredOperationIds->all());
    }

    /** @return list<int> */
    public function assistantDepartmentIdsForOperationDepartment(int $operationDepartmentId): array
    {
        $department = Department::business()->find($operationDepartmentId);
        if (! $department) return [];

        $candidateIds = collect([$department->getKey(), $department->parent_id])
            ->filter()->map(static fn ($id): int => (int) $id)->unique()->values();

        return AssistantDepartmentOperationScope::query()
            ->whereIn('operation_department_id', $candidateIds->all())
            ->pluck('assistant_department_id')
            ->map(static fn ($id): int => (int) $id)
            ->unique()->values()->all();
    }

    /** @return array<int, list<int>> */
    public function scopeMap(): array
    {
        return AssistantDepartmentOperationScope::query()
            ->orderBy('operation_department_id')
            ->get(['assistant_department_id', 'operation_department_id'])
            ->groupBy('assistant_department_id')
            ->map(fn (Collection $rows): array => $rows->pluck('operation_department_id')
                ->map(static fn (mixed $id): int => (int) $id)
                ->values()
                ->all())
            ->all();
    }

    /** @return Collection<int, int> */
    public function configuredAssistantDepartmentIds(): Collection
    {
        return AssistantDepartmentOperationScope::query()
            ->select('assistant_department_id')
            ->distinct()
            ->pluck('assistant_department_id')
            ->map(static fn (mixed $id): int => (int) $id)
            ->values();
    }

    /**
     * @param array<int, list<int>> $scopeMap
     */
    public function replaceScopes(array $scopeMap, AdminUser $actor): void
    {
        $connection = config('admin.database.connection') ?: config('database.default');

        DB::connection($connection)->transaction(function () use ($scopeMap, $actor): void {
            AssistantDepartmentOperationScope::query()->delete();
            $now = now();
            $rows = [];

            foreach ($scopeMap as $assistantDepartmentId => $operationDepartmentIds) {
                foreach (array_unique($operationDepartmentIds) as $operationDepartmentId) {
                    $rows[] = [
                        'assistant_department_id' => $assistantDepartmentId,
                        'operation_department_id' => $operationDepartmentId,
                        'last_operator_id' => $actor->getKey(),
                        'created_at' => $now,
                        'updated_at' => $now,
                    ];
                }
            }

            if ($rows !== []) {
                AssistantDepartmentOperationScope::query()->insert($rows);
            }
        });
    }

    /** @return Collection<int, AdminUser> */
    public function eligibleUsersForAssistantDepartment(int $assistantDepartmentId): Collection
    {
        $configuredIds = AssistantDepartmentOperationScope::query()
            ->where('assistant_department_id', $assistantDepartmentId)
            ->pluck('operation_department_id')
            ->map(static fn (mixed $id): int => (int) $id);

        if ($configuredIds->isEmpty()) {
            return collect();
        }

        $allowedDepartmentIds = $this->departmentIdsIncludingDescendants($configuredIds->all());

        return AdminUser::query()
            ->where('status', AdminUser::STATUS_ACTIVE)
            ->whereHas('departments', fn ($query) => $query->whereIn('admin_roles.id', $allowedDepartmentIds))
            ->with(['departments' => fn ($query) => $query
                ->whereIn('admin_roles.id', $allowedDepartmentIds)
                ->orderBy('admin_roles.sort')
                ->orderBy('admin_roles.name')])
            ->orderBy('name')
            ->orderBy('username')
            ->get()
            ->unique('id')
            ->values();
    }

    /** @return Collection<int, AdminUser> */
    public function eligibleUsersForOperationDepartment(int $operationDepartmentId): Collection
    {
        $allowedDepartmentIds = $this->departmentIdsIncludingDescendants([$operationDepartmentId]);

        return AdminUser::query()
            ->where('status', AdminUser::STATUS_ACTIVE)
            ->whereHas('departments', fn ($query) => $query->whereIn('admin_roles.id', $allowedDepartmentIds))
            ->with(['departments' => fn ($query) => $query
                ->whereIn('admin_roles.id', $allowedDepartmentIds)
                ->orderBy('admin_roles.sort')
                ->orderBy('admin_roles.name')])
            ->orderBy('name')
            ->orderBy('username')
            ->get()
            ->unique('id')
            ->values();
    }

    /** @param list<int> $assistantDepartmentIds
     *  @return Collection<int, AdminUser>
     */
    public function eligibleUsersForDepartments(array $assistantDepartmentIds): Collection
    {
        $departmentIds = collect($assistantDepartmentIds)->unique()->values();

        if ($departmentIds->isEmpty()) {
            return collect();
        }

        $sets = $departmentIds
            ->map(fn (int $departmentId): Collection => $this->eligibleUsersForAssistantDepartment($departmentId)->keyBy('id'));
        $eligibleIds = $sets->shift()?->keys() ?? collect();

        foreach ($sets as $set) {
            $eligibleIds = $eligibleIds->intersect($set->keys());
        }

        if ($eligibleIds->isEmpty()) {
            return collect();
        }

        return $this->eligibleUsersForAssistantDepartment((int) $departmentIds->first())
            ->whereIn('id', $eligibleIds->all())
            ->values();
    }

    /**
     * Existing assignments are preserved when a manager narrows a scope.
     * This only identifies assignments that should be shown with a warning.
     *
     * @param Collection<int, \App\Models\AssistantDomainStore> $stores
     * @return list<int>
     */
    public function outOfScopeStoreIds(Collection $stores): array
    {
        return $stores
            ->filter(static fn ($store): bool => $store->owner_user_id !== null && $store->owner_department_id !== null)
            ->groupBy('owner_department_id')
            ->flatMap(function (Collection $departmentStores, mixed $assistantDepartmentId): Collection {
                $eligibleUserIds = $this->eligibleUsersForAssistantDepartment((int) $assistantDepartmentId)
                    ->pluck('id')
                    ->map(static fn (mixed $id): int => (int) $id);

                return $departmentStores
                    ->reject(static fn ($store): bool => $eligibleUserIds->contains((int) $store->owner_user_id))
                    ->pluck('id');
            })
            ->map(static fn (mixed $id): int => (int) $id)
            ->values()
            ->all();
    }

    /** @param list<int> $departmentIds
     *  @return list<int>
     */
    private function departmentIdsIncludingDescendants(array $departmentIds): array
    {
        $all = Department::business()->get(['id', 'parent_id']);
        $selected = collect($departmentIds)->map(static fn (mixed $id): int => (int) $id)->unique();
        $result = $selected;

        do {
            $children = $all->whereIn('parent_id', $result->all())->pluck('id')->map(static fn (mixed $id): int => (int) $id);
            $expanded = $result->merge($children)->unique()->values();
            $changed = $expanded->count() !== $result->count();
            $result = $expanded;
        } while ($changed);

        return $result->all();
    }

    /** @param Collection<int, Department> $result
     *  @param Collection<int, Department> $departments
     */
    private function appendDepartmentTree(Collection $result, Collection $departments, Department $department, int $depth): void
    {
        $department->setAttribute('tree_depth', $depth);
        $result->push($department);

        foreach ($departments->where('parent_id', $department->getKey()) as $child) {
            $this->appendDepartmentTree($result, $departments, $child, $depth + 1);
        }
    }
}
