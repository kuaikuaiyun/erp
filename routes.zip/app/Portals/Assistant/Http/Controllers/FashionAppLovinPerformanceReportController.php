<?php

namespace App\Portals\Assistant\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use App\Models\AppLovinAccountStoreBinding;
use App\Models\AppLovinSpendScreenshot;
use App\Support\AppLovinGiftConsumption;
use App\Models\AssistantDomainStore;
use App\Models\Department;
use App\Models\FashionAdvertisingReport;
use App\Models\FashionLogisticsOrder;
use App\Portal\Http\Controllers\PortalEntryController;
use App\Portals\Assistant\AssistantPortalAuthorizationService;
use App\Portals\Assistant\AppLovinHistoricalSpendService;
use App\Portals\Assistant\AssistantStoreOwnerService;
use App\Portals\Assistant\AssistantStoreOwnerAttributionService;
use App\Portals\Assistant\OperationDashboardDepartmentScopeService;
use App\Portals\Fashion\OperationProjectCatalog;
use App\Services\DepartmentAuthorizationService;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class FashionAppLovinPerformanceReportController extends Controller
{
    public function __construct(
        private readonly PortalEntryController $portalEntries,
        private readonly AssistantPortalAuthorizationService $authorization,
        private readonly AssistantStoreOwnerService $storeOwners,
        private readonly AssistantStoreOwnerAttributionService $ownerAttribution,
        private readonly DepartmentAuthorizationService $departmentAuthorization,
        private readonly OperationDashboardDepartmentScopeService $dashboardScopes,
        private readonly AppLovinHistoricalSpendService $historicalSpend,
    ) {}

    public function index(Request $request): Response|View
    {
        $context = $this->portalEntries->portalContext($request);
        if ($context instanceof Response) {
            return $context;
        }
        $isFashionPortal = $request->routeIs('fashion.applovin-performance-reports.*');
        $isDashboard = $request->routeIs('operation-dashboard.fashion-applovin-performance-reports.*');
        if ($isDashboard) {
            abort_unless($context['portal']->code === 'yunying-kanban', 404);
        } elseif ($isFashionPortal) {
            abort_unless($context['portal']->code === 'fuzhuang', 404);
        } else {
            $this->authorization->assertAssistantPortal($context['portal']);
            abort_unless($this->authorization->isAssistantDepartmentMember($context['user']), 403);
        }

        $canSeeAll = $context['user']->isAdministrator() || strcasecmp((string) $context['user']->username, 'kky_boss') === 0;
        $projectCode = 'fuzhuang';
        $projectDepartmentIds = OperationProjectCatalog::departmentIds($projectCode)
            ->map(fn ($id) => (int) $id)->values()->all();
        $managedDepartmentIds = $this->departmentAuthorization->managedDepartmentIds($context['user'])
            ->map(fn ($id) => (int) $id)->values()->all();
        $managedProjectDepartmentIds = array_values(array_intersect($managedDepartmentIds, $projectDepartmentIds));
        $operatorOnly = $isFashionPortal && ! $canSeeAll && $managedProjectDepartmentIds === [];
        $visibleDepartmentIds = $isDashboard
            ? $this->dashboardScopes->visibleDepartmentIds($context['user'])
            : ($isFashionPortal
            ? ($canSeeAll ? $projectDepartmentIds : $managedProjectDepartmentIds)
            : $this->visibleDepartmentIds($context['user']));
        if ($visibleDepartmentIds !== null) {
            $visibleDepartmentIds = array_values(array_intersect($visibleDepartmentIds, $projectDepartmentIds));
        }
        $submitterIds = FashionAdvertisingReport::query()->whereHas('adSpendEntries', fn ($query) => $query->whereRaw("LOWER(TRIM(media)) = 'applovin'"))
            ->where('project_code', $projectCode)
            ->where('status', FashionAdvertisingReport::STATUS_APPROVED)
            ->when($operatorOnly, fn ($query) => $query->where('submitter_id', $context['user']->getKey()))
            ->when(! $operatorOnly && $visibleDepartmentIds !== null, fn ($query) => $visibleDepartmentIds === []
                ? $query->whereRaw('1 = 0')
                : $query->whereHas('submitter.departments', fn ($departments) => $departments->whereIn('admin_roles.id', $visibleDepartmentIds)))
            ->pluck('submitter_id')->filter()->unique()->values();
        $departments = Department::business()->whereHas('departmentMembers', fn ($query) => $query->whereIn('admin_users.id', $submitterIds))
            ->whereIn('id', $projectDepartmentIds)
            ->when(! $operatorOnly && $visibleDepartmentIds !== null, fn ($query) => $query->whereIn('id', $visibleDepartmentIds))
            ->orderBy('sort')->orderBy('name')->get(['id', 'parent_id', 'name']);
        $departmentIds = $departments->pluck('id')->map(fn ($id) => (int) $id)->all();
        $timezoneOptions = $this->timezoneOptions();
        $filters = $request->validate([
            'date_from' => ['nullable', 'date_format:Y-m-d'],
            'date_to' => ['nullable', 'date_format:Y-m-d'],
            'date_range' => ['nullable', Rule::in(['custom', 'yesterday', 'last_3', 'last_7', 'last_15', 'last_30', 'last_60', 'last_90', 'last_6_months', 'last_year'])],
            'timezone' => ['nullable', Rule::in(array_keys($timezoneOptions))],
            'department_ids' => ['nullable', 'array'],
            'department_ids.*' => ['integer', 'distinct', Rule::in($departmentIds)],
            'operator' => ['nullable', 'string', 'max:100'],
            'display_mode' => ['nullable', Rule::in(['performance', 'team'])],
            'store_domain' => ['nullable', 'string', 'max:191'],
            'gift_status' => ['nullable', Rule::in(['yes', 'no'])],
            'consumption_range' => ['nullable', Rule::in(['lt_5000', '5000_10000', 'gt_10000', 'custom'])],
            'consumption_custom' => ['nullable', 'numeric', 'min:0', 'required_if:consumption_range,custom'],
            'consumption_custom_max' => ['nullable', 'numeric', 'min:0', 'required_if:consumption_range,custom', 'gte:consumption_custom'],
        ]);
        $timezone = (string) ($filters['timezone'] ?? '-08:00');
        $today = now($timezone)->startOfDay();
        $dateRange = (string) ($filters['date_range'] ?? ($request->hasAny(['date_from', 'date_to']) ? 'custom' : 'last_7'));
        [$presetFrom, $presetTo] = match ($dateRange) {
            'yesterday' => [$today->copy()->subDay(), $today->copy()->subDay()],
            'last_3' => [$today->copy()->subDays(2), $today->copy()],
            'last_15' => [$today->copy()->subDays(14), $today->copy()],
            'last_30' => [$today->copy()->subDays(29), $today->copy()],
            'last_60' => [$today->copy()->subDays(59), $today->copy()],
            'last_90' => [$today->copy()->subDays(89), $today->copy()],
            'last_6_months' => [$today->copy()->subMonths(6)->addDay(), $today->copy()],
            'last_year' => [$today->copy()->subYear()->addDay(), $today->copy()],
            default => [$today->copy()->subDays(6), $today->copy()],
        };
        $dateFrom = $dateRange === 'custom' ? (string) ($filters['date_from'] ?? $presetFrom->toDateString()) : $presetFrom->toDateString();
        $dateTo = $dateRange === 'custom' ? (string) ($filters['date_to'] ?? $presetTo->toDateString()) : $presetTo->toDateString();
        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        $selectedDepartmentIds = collect($filters['department_ids'] ?? [])->map(fn ($id) => (int) $id)->unique()->values()->all();
        $reportQuery = FashionAdvertisingReport::query()
            ->where('project_code', $projectCode)
            ->where('status', FashionAdvertisingReport::STATUS_APPROVED)
            ->whereHas('adSpendEntries', fn ($query) => $query->whereRaw("LOWER(TRIM(media)) = 'applovin'"))
            ->with([
                'adSpendEntries' => fn ($query) => $query->whereRaw("LOWER(TRIM(media)) = 'applovin'"),
                'performanceEntries',
                'submitter.departments' => fn ($query) => $query->whereIn('admin_roles.id', $projectDepartmentIds),
            ])
            ->when($operatorOnly, fn ($query) => $query->where('submitter_id', $context['user']->getKey()))
            ->when(! $operatorOnly && $visibleDepartmentIds !== null, fn ($query) => $visibleDepartmentIds === []
                ? $query->whereRaw('1 = 0')
                : $query->whereHas('submitter.departments', fn ($departments) => $departments->whereIn('admin_roles.id', $visibleDepartmentIds)))
            ->when($selectedDepartmentIds !== [], fn ($query) => $query->whereHas('submitter.departments', fn ($department) => $department->whereKey($selectedDepartmentIds)))
            ->when($filters['operator'] ?? null, fn ($query, $name) => $query->where('submitter_name', 'like', '%'.$name.'%'));
        $accountSpendReports = (clone $reportQuery)->orderBy('report_date')->orderBy('id')->get();
        $reports = (clone $reportQuery)->whereBetween('report_date', [$dateFrom, $dateTo])->orderBy('report_date')->get();

        $accountBindings = AppLovinAccountStoreBinding::query()->pluck('assistant_domain_store_id', 'account_key');
        $accountIdentity = static function (int $operatorId, string $agency, string $accountNumber): string {
            $normalizedAgency = mb_strtolower(trim($agency));
            $normalizedNumber = preg_replace('/[\s\p{Cf}]+/u', '', mb_strtolower($accountNumber)) ?? '';

            return implode('|', [$operatorId, $normalizedAgency, $normalizedNumber]);
        };
        $bindingByIdentity = collect();
        $accountSpendReports->each(function (FashionAdvertisingReport $report) use ($accountBindings, $accountIdentity, $bindingByIdentity): void {
            $report->adSpendEntries->each(function ($entry) use ($report, $accountBindings, $accountIdentity, $bindingByIdentity): void {
                $exactKey = AppLovinSpendScreenshot::accountKey((int) $report->submitter_id, (string) $entry->agency, (string) $entry->media, (string) $entry->account_name, (string) $entry->account_number);
                $storeId = (int) ($entry->assistant_domain_store_id ?: ($accountBindings->get($exactKey) ?? 0));
                if ($storeId > 0) {
                    $bindingByIdentity->put($accountIdentity((int) $report->submitter_id, (string) $entry->agency, (string) $entry->account_number), $storeId);
                }
            });
        });
        $storeIds = $reports->flatMap->adSpendEntries->pluck('assistant_domain_store_id')->merge($accountBindings->values())->merge($bindingByIdentity->values())
            ->filter()->map(fn ($id) => (int) $id)->unique()->values();
        $stores = AssistantDomainStore::query()->whereIn('id', $storeIds)->get(['id', 'domain', 'site_builder'])->keyBy('id');
        $ownerTimelines = $this->ownerAttribution->timelines($storeIds);
        $performanceMetricsCache = [];
        $performanceMetrics = function (int $storeId, string $platform, CarbonImmutable $from, CarbonImmutable $to, int $operatorId) use ($ownerTimelines, &$performanceMetricsCache): array {
            $cacheKey = implode('|', [$storeId, $platform, $from->timestamp, $to->timestamp, $operatorId]);
            if (isset($performanceMetricsCache[$cacheKey])) return $performanceMetricsCache[$cacheKey];

            $orders = FashionLogisticsOrder::query()
                ->where('assistant_domain_store_id', $storeId)
                ->where('source_platform', $platform)
                ->whereBetween('order_created_at', [$from, $to])
                ->get(['id', 'order_created_at', 'total_amount']);
            $hasOwnershipHistory = $ownerTimelines->get($storeId, collect())->isNotEmpty();
            if ($hasOwnershipHistory) {
                $orders = $orders->filter(function (FashionLogisticsOrder $order) use ($ownerTimelines, $storeId, $operatorId): bool {
                    $orderedAt = $order->getRawOriginal('order_created_at') ?: $order->order_created_at;
                    $assignment = $this->ownerAttribution->resolve($ownerTimelines, $storeId, $orderedAt);

                    return $assignment['owner_user_id'] === $operatorId;
                })->values();
            }

            return $performanceMetricsCache[$cacheKey] = [
                'order_count' => $orders->count(),
                'revenue' => (float) $orders->sum('total_amount'),
            ];
        };
        $accountSpendRecords = $accountSpendReports->flatMap(fn (FashionAdvertisingReport $report) => $report->adSpendEntries->map(function ($entry) use ($report): array {
            $accountKey = AppLovinSpendScreenshot::accountKey(
                (int) $report->submitter_id,
                (string) $entry->agency,
                (string) $entry->media,
                (string) $entry->account_name,
                (string) $entry->account_number,
            );

            return [
                'account_identity' => AppLovinGiftConsumption::accountIdentity(
                    (int) $report->submitter_id,
                    (string) $entry->account_number,
                    $accountKey,
                ),
                'spend' => (float) $entry->actual_spend_usd,
            ];
        }));
        $accountSpendTotals = $accountSpendRecords->groupBy('account_identity')->map(fn ($items) => (float) $items->sum('spend'));
        $globalSpendTotals = $this->historicalSpend->totalsByAccountNumber();
        $giftScreenshots = AppLovinSpendScreenshot::query()
            ->whereIn('operator_user_id', $accountSpendReports->pluck('submitter_id')->filter()->unique()->values())
            ->get()
            ->keyBy(fn (AppLovinSpendScreenshot $screenshot): string => AppLovinGiftConsumption::accountIdentity(
                (int) $screenshot->operator_user_id,
                (string) $screenshot->account_number,
                (string) $screenshot->account_key,
            ));
        $historicalRevenueByAccount = $accountSpendReports->reduce(function (array $totals, FashionAdvertisingReport $report) use ($stores, $accountBindings, $accountIdentity, $bindingByIdentity, $timezone, $performanceMetrics): array {
            $groups = $report->adSpendEntries->map(function ($entry) use ($report, $stores, $accountBindings, $accountIdentity, $bindingByIdentity): array {
                $accountKey = AppLovinSpendScreenshot::accountKey((int) $report->submitter_id, (string) $entry->agency, (string) $entry->media, (string) $entry->account_name, (string) $entry->account_number);
                $identity = $accountIdentity((int) $report->submitter_id, (string) $entry->agency, (string) $entry->account_number);
                // The same AppLovin account is occasionally entered with different agency casing
                // or an older store binding. Use the latest normalized identity binding first so
                // historical rows stay together instead of being split into duplicate report rows.
                $storeId = (int) ($bindingByIdentity->get($identity, 0) ?: $entry->assistant_domain_store_id ?: ($accountBindings->get($accountKey) ?? 0));

                return [
                    'store_id' => $storeId,
                    'domain' => trim((string) ($stores->get($storeId)?->domain ?: $entry->store_domain ?: '')),
                    'account_identity' => AppLovinGiftConsumption::accountIdentity(
                        (int) $report->submitter_id,
                        (string) $entry->account_number,
                        $accountKey,
                    ),
                    'spend' => (float) $entry->actual_spend_usd,
                ];
            })->filter(fn (array $entry): bool => $entry['store_id'] > 0)->groupBy('store_id');

            foreach ($groups as $entriesForStore) {
                $storeId = (int) $entriesForStore->first()['store_id'];
                $store = $stores->get($storeId);
                $from = CarbonImmutable::parse($report->report_date->format('Y-m-d').' 00:00:00', $timezone)->utc();
                $to = CarbonImmutable::parse($report->report_date->format('Y-m-d').' 23:59:59', $timezone)->utc();
                $platform = $store && mb_strtolower(trim((string) $store->site_builder)) === 'shopline' ? 'shopline' : 'xshoppy';
                $revenue = (float) $performanceMetrics($storeId, $platform, $from, $to, (int) $report->submitter_id)['revenue'];
                $accounts = $entriesForStore->groupBy('account_identity')->map(fn ($rows): float => (float) $rows->sum('spend'));
                $totalSpend = (float) $accounts->sum();
                foreach ($accounts as $accountIdentityKey => $spend) {
                    $share = $totalSpend > 0
                        ? (float) $spend / $totalSpend
                        : 1 / max(1, $accounts->count());
                    $totals[$accountIdentityKey] = ($totals[$accountIdentityKey] ?? 0.0) + ($revenue * $share);
                }
            }

            return $totals;
        }, []);
        $dailyRows = $reports->flatMap(function (FashionAdvertisingReport $report) use ($stores, $accountBindings, $accountSpendTotals, $accountIdentity, $bindingByIdentity, $timezone, $departments, $performanceMetrics): array {
            $reportDepartment = $report->submitter?->departments?->first(fn ($department) => $departments->contains('id', $department->id));
            return $report->adSpendEntries->map(function ($entry) use ($report, $accountBindings, $accountIdentity, $bindingByIdentity) {
                $accountKey = AppLovinSpendScreenshot::accountKey((int) $report->submitter_id, (string) $entry->agency, (string) $entry->media, (string) $entry->account_name, (string) $entry->account_number);
                $identity = $accountIdentity((int) $report->submitter_id, (string) $entry->agency, (string) $entry->account_number);
                $storeId = (int) ($bindingByIdentity->get($identity, 0) ?: $entry->assistant_domain_store_id ?: ($accountBindings->get($accountKey) ?? 0));
                $entry->setAttribute('resolved_account_key', $accountKey);
                $entry->setAttribute('resolved_account_identity', AppLovinGiftConsumption::accountIdentity(
                    (int) $report->submitter_id,
                    (string) $entry->account_number,
                    $accountKey,
                ));
                $entry->setAttribute('resolved_store_id', $storeId);
                $entry->setAttribute('resolved_group_key', $storeId > 0 ? 'store:'.$storeId : 'identity:'.$identity);

                return $entry;
            })->groupBy('resolved_group_key')->map(function ($entries) use ($report, $stores, $accountSpendTotals, $timezone, $reportDepartment, $performanceMetrics): array {
                $storeId = (int) $entries->first()->resolved_store_id;
                $store = $stores->get((int) $storeId);
                $from = CarbonImmutable::parse($report->report_date->format('Y-m-d').' 00:00:00', $timezone)->utc();
                $to = CarbonImmutable::parse($report->report_date->format('Y-m-d').' 23:59:59', $timezone)->utc();
                $platform = $store && mb_strtolower(trim((string) $store->site_builder)) === 'shopline' ? 'shopline' : 'xshoppy';
                $metrics = $storeId > 0
                    ? $performanceMetrics($storeId, $platform, $from, $to, (int) $report->submitter_id)
                    : ['order_count' => 0, 'revenue' => 0.0];
                $orders = (int) $metrics['order_count'];
                $revenue = round((float) $metrics['revenue'], 2);
                $spend = round((float) $entries->sum('actual_spend_usd'), 2);

                return [
                    'date' => $report->report_date->format('Y-m-d'),
                    'department_id' => (int) ($reportDepartment?->id ?? 0),
                    'department' => (string) ($reportDepartment?->name ?: '—'),
                    'team_position' => (string) ($reportDepartment?->pivot?->position ?: Department::POSITION_MEMBER),
                    'operator_id' => (int) $report->submitter_id,
                    'operator' => (string) $report->submitter_name,
                    'store_id' => (int) $storeId,
                    'store_domain' => (string) ($store?->domain ?: $entries->pluck('store_domain')->filter()->first() ?: '未绑定店铺'),
                    'site_builder' => $storeId > 0 ? ($platform === 'shopline' ? 'Shopline' : 'XShoppy') : '未绑定',
                    'account_numbers' => $entries->pluck('account_number')->map(fn ($number) => trim((string) $number))->filter()->unique()->values()->all(),
                    'account_keys' => $entries->pluck('resolved_account_identity')->filter()->unique()->values()->all(),
                    'orders' => $orders,
                    'revenue' => $revenue,
                    'ad_spend' => $spend,
                    'roi' => $spend > 0 ? $revenue / $spend : null,
                    'total_consumption' => round((float) $entries->pluck('resolved_account_identity')->filter()->unique()->sum(fn ($key) => (float) ($accountSpendTotals->get($key) ?? 0)), 2),
                ];
            })->filter()->values()->all();
        })->values();

        $rows = $dailyRows->groupBy(fn (array $row) => $row['operator_id'].'|'.$row['store_id'])
            ->map(function ($group) use ($accountSpendTotals, $globalSpendTotals, $giftScreenshots, $historicalRevenueByAccount): array {
                $first = $group->first();
                $orders = (int) $group->sum('orders');
                $revenue = round((float) $group->sum('revenue'), 2);
                $spend = round((float) $group->sum('ad_spend'), 2);
                $accountKeys = $group->pluck('account_keys')->flatten()->filter()->unique()->values();
                $accountNumberValues = $group->pluck('account_numbers')->flatten()->filter()->unique()->values();
                $giftEligibleKeys = $accountKeys->filter(fn ($key) => (float) ($accountSpendTotals->get($key) ?? 0) >= 5000);
                $giftStatus = $giftEligibleKeys->isEmpty()
                    ? 'not_eligible'
                    : ($giftEligibleKeys->contains(fn ($key) => $giftScreenshots->has($key)) ? 'available' : 'pending_upload');
                $deductedConsumption = round((float) $accountKeys->sum(function ($key) use ($accountSpendTotals, $giftScreenshots): float {
                    $consumption = (float) ($accountSpendTotals->get($key) ?? 0);

                    return AppLovinGiftConsumption::net($consumption, $giftScreenshots->has($key));
                }), 2);
                $historicalRevenue = round(max(
                    (float) $accountKeys->sum(fn ($key) => (float) ($historicalRevenueByAccount[$key] ?? 0)),
                    $revenue,
                ), 2);

                return [...$first, 'date_label' => $group->min('date') === $group->max('date') ? $group->min('date') : $group->min('date').' 至 '.$group->max('date'),
                    'orders' => $orders, 'revenue' => $revenue, 'ad_spend' => $spend, 'roi' => $spend > 0 ? $revenue / $spend : null,
                    'account_numbers' => $group->pluck('account_numbers')->flatten()->filter()->unique()->implode('、'),
                    'account_number_values' => $accountNumberValues->all(),
                    'account_keys' => $accountKeys->all(),
                    'total_consumption' => round((float) $accountKeys->sum(fn ($key) => (float) ($accountSpendTotals->get($key) ?? 0)), 2),
                    'global_total_consumption' => $this->historicalSpend->sumForAccountNumbers($globalSpendTotals, $accountNumberValues),
                    'deducted_consumption' => $deductedConsumption,
                    'historical_revenue' => $historicalRevenue,
                    'estimated_total_roi' => $deductedConsumption > 0 ? $historicalRevenue / $deductedConsumption : null,
                    'gift_status' => $giftStatus,
                    'details' => $group->sortByDesc('date')->map(function (array $detail): array {
                        $detail['account_numbers'] = implode('、', $detail['account_numbers']);

                        return $detail;
                    })->values()->all()];
            })->values();
        if (($filters['gift_status'] ?? '') === 'yes') {
            $rows = $rows->where('gift_status', 'available')->values();
        } elseif (($filters['gift_status'] ?? '') === 'no') {
            $rows = $rows->where('gift_status', '!=', 'available')->values();
        }
        $domainOptions = $rows->pluck('store_domain')->filter()->unique(fn ($domain) => mb_strtolower((string) $domain))->sort()->values();
        if (($filters['store_domain'] ?? '') !== '') {
            $selectedDomain = mb_strtolower(trim((string) $filters['store_domain']));
            $rows = $rows->filter(fn (array $row): bool => mb_strtolower(trim((string) $row['store_domain'])) === $selectedDomain)->values();
        }
        if (($filters['consumption_range'] ?? '') === 'lt_5000') {
            $rows = $rows->filter(fn (array $row): bool => (float) $row['total_consumption'] < 5000)->values();
        } elseif (($filters['consumption_range'] ?? '') === '5000_10000') {
            $rows = $rows->filter(fn (array $row): bool => (float) $row['total_consumption'] >= 5000 && (float) $row['total_consumption'] <= 10000)->values();
        } elseif (($filters['consumption_range'] ?? '') === 'gt_10000') {
            $rows = $rows->filter(fn (array $row): bool => (float) $row['total_consumption'] > 10000)->values();
        } elseif (($filters['consumption_range'] ?? '') === 'custom') {
            $minimumConsumption = (float) ($filters['consumption_custom'] ?? 0);
            $maximumConsumption = (float) ($filters['consumption_custom_max'] ?? 0);
            $rows = $rows->filter(fn (array $row): bool => (float) $row['total_consumption'] >= $minimumConsumption
                && (float) $row['total_consumption'] <= $maximumConsumption)->values();
        }
        $displayMode = (string) ($filters['display_mode'] ?? 'performance');
        $rows = $rows->sort(function (array $left, array $right) use ($displayMode): int {
            if ($displayMode === 'team') {
                $rank = static fn (array $row): int => match ($row['team_position'] ?? Department::POSITION_MEMBER) {
                    Department::POSITION_MANAGER => 0,
                    Department::POSITION_DEPUTY => 1,
                    default => 2,
                };

                return [$left['department'], $rank($left), $left['operator'], $left['store_domain']]
                    <=> [$right['department'], $rank($right), $right['operator'], $right['store_domain']];
            }
            $orderComparison = (int) $right['orders'] <=> (int) $left['orders'];

            return $orderComparison !== 0 ? $orderComparison : ((float) $right['ad_spend'] <=> (float) $left['ad_spend']);
        })->values();
        $totalAccountKeys = $rows->pluck('account_keys')->flatten()->filter()->unique()->values();
        $totals = ['stores' => $rows->pluck('store_id')->filter(fn ($id) => (int) $id > 0)->unique()->count(), 'orders' => (int) $rows->sum('orders'),
            'revenue' => round((float) $rows->sum('revenue'), 2), 'ad_spend' => round((float) $rows->sum('ad_spend'), 2),
            'total_consumption' => round((float) $totalAccountKeys->sum(fn ($key) => (float) ($accountSpendTotals->get($key) ?? 0)), 2)];
        $totals['global_total_consumption'] = $this->historicalSpend->sumForAccountNumbers(
            $globalSpendTotals,
            $rows->pluck('account_number_values')->flatten()->filter()->unique(),
        );
        $totals['roi'] = $totals['ad_spend'] > 0 ? $totals['revenue'] / $totals['ad_spend'] : null;
        $totals['deducted_consumption'] = round((float) $totalAccountKeys->sum(function ($key) use ($accountSpendTotals, $giftScreenshots): float {
            $consumption = (float) ($accountSpendTotals->get($key) ?? 0);

            return AppLovinGiftConsumption::net($consumption, $giftScreenshots->has($key));
        }), 2);
        $totals['historical_revenue'] = round(max(
            (float) $totalAccountKeys->sum(fn ($key) => (float) ($historicalRevenueByAccount[$key] ?? 0)),
            (float) $totals['revenue'],
        ), 2);
        $totals['estimated_total_roi'] = $totals['deducted_consumption'] > 0
            ? $totals['historical_revenue'] / $totals['deducted_consumption']
            : null;
        $exportRows = $rows->map(fn (array $row): array => [
            'date_label' => $row['date_label'],
            'department' => $row['department'],
            'operator' => $row['operator'],
            'store_domain' => $row['store_domain'],
            'orders' => $row['orders'],
            'revenue' => $row['revenue'],
            'ad_spend' => $row['ad_spend'],
            'roi' => $row['roi'],
            'gift_status' => $row['gift_status'],
            'account_numbers' => $row['account_numbers'],
            'total_consumption' => $row['total_consumption'],
            'global_total_consumption' => $row['global_total_consumption'],
            'deducted_consumption' => $row['deducted_consumption'],
            'historical_revenue' => $row['historical_revenue'],
            'estimated_total_roi' => $row['estimated_total_roi'],
        ])->values();
        $page = max(1, (int) $request->query('page', 1));
        $rows = new LengthAwarePaginator($rows->forPage($page, 30)->values(), $rows->count(), 30, $page, ['path' => $request->url(), 'query' => $request->query()]);

        return view('portals.assistant.fashion-applovin-performance-reports.index', [
            'portal' => $context['portal']->loadMissing('menus'), 'user' => $context['user'], 'rows' => $rows, 'exportRows' => $exportRows, 'totals' => $totals,
            'dateFrom' => $dateFrom, 'dateTo' => $dateTo, 'operator' => $filters['operator'] ?? '',
            'displayMode' => $displayMode,
            'timezone' => $timezone, 'timezoneOptions' => $timezoneOptions,
            'dateRange' => $dateRange, 'selectedStoreDomain' => $filters['store_domain'] ?? '', 'domainOptions' => $domainOptions,
            'selectedGiftStatus' => $filters['gift_status'] ?? '', 'selectedConsumptionRange' => $filters['consumption_range'] ?? '',
            'consumptionCustom' => $filters['consumption_custom'] ?? '', 'consumptionCustomMax' => $filters['consumption_custom_max'] ?? '',
            'selectedDepartmentIds' => $selectedDepartmentIds, 'departmentOptions' => $departments,
            'performanceResetRoute' => $isDashboard
                ? 'operation-dashboard.fashion-applovin-performance-reports.index'
                : ($isFashionPortal
                    ? 'fashion.applovin-performance-reports.index'
                    : 'assistant.fashion-applovin-performance-reports.index'),
        ]);
    }

    /** @return list<int>|null null means unrestricted administrator or BOSS access. */
    private function visibleDepartmentIds(AdminUser $user): ?array
    {
        if ($user->isAdministrator() || strcasecmp((string) $user->username, 'kky_boss') === 0) {
            return null;
        }

        return $this->storeOwners->visibleOperationDepartmentIds($user);
    }

    /** @return array<string,string> */
    private function timezoneOptions(): array
    {
        $options = [];
        for ($offset = -12; $offset <= 14; $offset++) {
            $value = sprintf('%s%02d:00', $offset < 0 ? '-' : '+', abs($offset));
            $label = 'UTC'.($offset >= 0 ? '+' : '').$offset;
            if ($value === '+08:00') $label .= '（北京时间）';
            if ($value === '-08:00') $label .= '（默认）';
            $options[$value] = $label;
        }

        return $options;
    }
}
