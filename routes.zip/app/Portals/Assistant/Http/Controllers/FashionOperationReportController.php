<?php

namespace App\Portals\Assistant\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use App\Models\AssistantDomainStore;
use App\Models\Department;
use App\Models\FashionAdvertisingReport;
use App\Models\FashionLogisticsOrder;
use App\Portal\Http\Controllers\PortalEntryController;
use App\Portals\Assistant\AssistantPortalAuthorizationService;
use App\Portals\Assistant\AssistantStoreOwnerService;
use App\Portals\Assistant\OperationDashboardDepartmentScopeService;
use App\Portals\Fashion\OperationProjectCatalog;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class FashionOperationReportController extends Controller
{
    private const FASHION_ROOT_DEPARTMENT_SLUG = 'dept-000037';

    private const FASHION_ROOT_DEPARTMENT_NAMES = [
        '服装运营部门',
        '单包服装运营部门',
        '单包服装运营系统',
    ];

    public function __construct(
        private readonly PortalEntryController $portalEntries,
        private readonly AssistantPortalAuthorizationService $authorization,
        private readonly AssistantStoreOwnerService $storeOwners,
        private readonly OperationDashboardDepartmentScopeService $dashboardScopes,
    ) {}

    public function index(Request $request): Response|View
    {
        $context = $this->portalEntries->portalContext($request);
        if ($context instanceof Response) {
            return $context;
        }
        $isDashboard = $request->routeIs('operation-dashboard.fashion-operation-reports.*');
        if ($isDashboard) {
            abort_unless($context['portal']->code === 'yunying-kanban', 404);
        } else {
            $this->authorization->assertAssistantPortal($context['portal']);
        }
        $projectCode = (string) $request->query('project_code', 'fuzhuang');
        abort_unless(array_key_exists($projectCode, OperationProjectCatalog::all()), 404);
        $project = OperationProjectCatalog::get($projectCode);
        $visibleDepartmentIds = $isDashboard
            ? $this->dashboardScopes->visibleDepartmentIds($context['user'])
            : ($context['user']->isAdministrator() ? null : $this->storeOwners->visibleOperationDepartmentIds($context['user']));

        $timezones = $this->timezoneOptions();
        $validated = $request->validate([
            'date_range' => ['nullable', Rule::in(['today', 'yesterday', 'last_7_days', 'last_15_days', 'last_30_days', 'this_month', 'last_month', 'custom'])],
            'date_from' => ['nullable', 'date_format:Y-m-d'],
            'date_to' => ['nullable', 'date_format:Y-m-d'],
            'timezone' => ['nullable', Rule::in(array_keys($timezones))],
            'department_ids' => ['nullable', 'array'],
            'department_ids.*' => ['integer', 'distinct'],
            'operator' => ['nullable', 'string', 'max:100'],
            'exclude_resigned' => ['nullable', 'boolean'],
            'sort_by' => ['nullable', Rule::in(['order_count', 'revenue'])],
            'sort_order' => ['nullable', Rule::in(['asc', 'desc'])],
            'display_mode' => ['nullable', Rule::in(['personal', 'performance', 'team'])],
            'personal_range' => ['nullable', Rule::in(['7', '14', 'custom'])],
            'profit_coefficient' => ['nullable', 'numeric', 'gt:0', 'max:1000000'],
        ]);
        $timezone = (string) ($validated['timezone'] ?? '-08:00');
        $excludeResigned = (bool) ($validated['exclude_resigned'] ?? false);
        $displayMode = (string) ($validated['display_mode'] ?? ($isDashboard ? 'personal' : 'performance'));
        $isPersonalMode = $isDashboard && $displayMode === 'personal';
        $personalRangeMode = (string) ($validated['personal_range'] ?? '7');
        $personalRange = $personalRangeMode === '14' ? 14 : 7;
        $profitCoefficient = (float) ($validated['profit_coefficient'] ?? 1.65);
        $reportNow = now($timezone);
        $personalCalendarNow = now('Asia/Shanghai');
        $dateRange = (string) ($validated['date_range'] ?? (
            $request->filled('date_from') || $request->filled('date_to') ? 'custom' : 'yesterday'
        ));
        [$dateFrom, $dateTo] = match ($dateRange) {
            'today' => [$reportNow->toDateString(), $reportNow->toDateString()],
            'yesterday' => [$reportNow->copy()->subDay()->toDateString(), $reportNow->copy()->subDay()->toDateString()],
            'last_7_days' => [$reportNow->copy()->subDays(6)->toDateString(), $reportNow->toDateString()],
            'last_15_days' => [$reportNow->copy()->subDays(14)->toDateString(), $reportNow->toDateString()],
            'last_30_days' => [$reportNow->copy()->subDays(29)->toDateString(), $reportNow->toDateString()],
            'last_month' => [
                $reportNow->copy()->subMonthNoOverflow()->startOfMonth()->toDateString(),
                $reportNow->copy()->subMonthNoOverflow()->endOfMonth()->toDateString(),
            ],
            'custom' => [
                (string) ($validated['date_from'] ?? $reportNow->copy()->startOfMonth()->toDateString()),
                (string) ($validated['date_to'] ?? $reportNow->copy()->endOfMonth()->toDateString()),
            ],
            default => [
                $reportNow->copy()->startOfMonth()->toDateString(),
                $reportNow->copy()->endOfMonth()->toDateString(),
            ],
        };
        if ($dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }
        if ($isPersonalMode) {
            if ($request->filled('date_from') && $request->filled('date_to')) {
                $dateFrom = (string) $validated['date_from'];
                $dateTo = (string) $validated['date_to'];
            } else {
                // Personal-report defaults follow the China business date, so
                // "today 21st" always closes on the 19th regardless of the
                // selected reporting timezone (for example UTC-8).
                $personalDateTo = $personalCalendarNow->copy()->subDays(2);
                $dateFrom = $personalDateTo->copy()->subDays($personalRange - 1)->toDateString();
                $dateTo = $personalDateTo->toDateString();
            }
        }
        // Keep the assistant report on the exact same time basis as the fashion
        // performance report. The legacy paid_at_utc column stores a
        // China-normalized payment time for orders from every supported builder.
        $storageFrom = CarbonImmutable::parse($dateFrom.' 00:00:00', $timezone)
            ->setTimezone('Asia/Shanghai')->format('Y-m-d H:i:s');
        $storageTo = CarbonImmutable::parse($dateTo.' 23:59:59', $timezone)
            ->setTimezone('Asia/Shanghai')->format('Y-m-d H:i:s');

        $stores = AssistantDomainStore::query()
            ->whereIn(\DB::raw('TRIM(project)'), OperationProjectCatalog::storeProjectNames($project))
            ->with('ownerUser.departments')
            ->orderBy('shop_name')->get();
        $nameUsers = AdminUser::query()->with('departments')->whereIn('name', $stores->pluck('user_name')->filter()->unique())
            ->orWhereIn('username', $stores->pluck('user_name')->filter()->unique())->get()
            ->keyBy(fn (AdminUser $user) => mb_strtolower((string) ($user->name ?: $user->username)));

        $storesByOperator = $stores->groupBy(function (AssistantDomainStore $store) use ($nameUsers): int {
            if ($store->owner_user_id) {
                return (int) $store->owner_user_id;
            }

            return (int) ($nameUsers->get(mb_strtolower(trim((string) $store->user_name)))?->getKey() ?? 0);
        })->forget(0);
        $operatorIds = $storesByOperator->keys()->map(fn ($id) => (int) $id)->values();
        $operators = AdminUser::query()->with('departments')->whereIn('id', $operatorIds)
            ->whereHas('departments', fn ($departments) => $departments->whereIn('admin_roles.id', OperationProjectCatalog::departmentIds($projectCode)))
            ->when($excludeResigned, fn ($query) => $query->where(function ($employment) {
                $employment->whereNull('employment_status')->orWhere('employment_status', '!=', 'resigned');
            }))
            ->when($visibleDepartmentIds !== null, fn ($query) => $visibleDepartmentIds === []
                ? $query->whereRaw('1 = 0')
                : $query->whereHas('departments', fn ($departments) => $departments->whereIn('admin_roles.id', $visibleDepartmentIds)))
            ->get()->keyBy('id');
        $operatorIds = $operators->keys()->map(fn ($id): int => (int) $id)->values();
        // groupBy 后每个值都是一个店铺集合，不是 Eloquent 模型；按分组键过滤，
        // 避免 Eloquent Collection::only() 把子集合当模型调用 getKey()。
        $storesByOperator = $storesByOperator
            ->filter(fn ($operatorStores, $operatorId): bool => $operatorIds->contains((int) $operatorId));
        $stores = $stores->filter(fn (AssistantDomainStore $store): bool => $storesByOperator->has((int) ($store->owner_user_id
            ?: ($nameUsers->get(mb_strtolower(trim((string) $store->user_name)))?->getKey() ?? 0))))->values();
        $departmentRows = Department::business()->get(['id', 'name', 'slug', 'parent_id', 'sort']);
        $projectRootDepartmentIds = $departmentRows->whereIn('name', $project['departments'])->pluck('id')
            ->map(fn ($id): int => (int) $id)->values();
        $fashionDepartmentIds = OperationProjectCatalog::departmentIds($projectCode);
        $fashionRootDepartmentId = (int) ($projectRootDepartmentIds->first() ?? 0);
        /*
        // 部门名称允许业务侧随时调整；报表归属应使用稳定 slug，避免改名后整张报表为空。
        // 名称匹配仅用于兼容尚未统一 slug 的旧环境。
        $fashionDepartment = $departmentRows->firstWhere('slug', self::FASHION_ROOT_DEPARTMENT_SLUG)
            ?: $departmentRows->first(fn (Department $department): bool => in_array(
                trim((string) $department->name),
                self::FASHION_ROOT_DEPARTMENT_NAMES,
                true
            ));
        $fashionDepartmentIds = collect($fashionDepartment ? [(int) $fashionDepartment->id] : []);
        do {
            $childIds = $departmentRows->whereIn('parent_id', $fashionDepartmentIds)
                ->pluck('id')->map(fn ($id): int => (int) $id)->diff($fashionDepartmentIds)->values();
            $before = $fashionDepartmentIds->count();
            $fashionDepartmentIds = $fashionDepartmentIds->merge($childIds)->unique()->values();
        } while ($fashionDepartmentIds->count() > $before);
        */
        $storeIdsByPlatform = $stores->groupBy(function (AssistantDomainStore $store): string {
            $platform = mb_strtolower(trim((string) $store->site_builder));

            return $platform === 'xshopy' ? 'xshoppy' : $platform;
        })->filter(fn ($platformStores, string $platform): bool => $platform !== '');
        $ordersQuery = FashionLogisticsOrder::query()
            ->whereIn('assistant_domain_store_id', $stores->pluck('id'))
            ->where(function ($platformQuery) use ($storeIdsByPlatform): void {
                foreach ($storeIdsByPlatform as $platform => $platformStores) {
                    $platformQuery->orWhere(function ($matchingPlatform) use ($platform, $platformStores): void {
                        $matchingPlatform->whereRaw('LOWER(TRIM(source_platform)) = ?', [$platform])
                            ->whereIn('assistant_domain_store_id', $platformStores->pluck('id'))
                            ->when(in_array($platform, ['nbc', 'shopyy'], true), fn ($paid) => $paid->where('payment_status', '230'));
                    });
                }
            })
            ->whereNotNull('paid_at_utc')
            ->whereBetween('paid_at_utc', [$storageFrom, $storageTo]);
        $personalOrderMetrics = collect();
        if ($isPersonalMode) {
            $timezoneMinutes = $this->timezoneOffsetMinutes($timezone);
            $reportDateExpression = sprintf('DATE(DATE_ADD(paid_at_utc, INTERVAL %d MINUTE))', $timezoneMinutes - 480);
            $personalOrderMetrics = (clone $ordersQuery)
                ->selectRaw("assistant_domain_store_id, {$reportDateExpression} report_date, COUNT(*) order_count, COALESCE(SUM(total_amount),0) revenue")
                ->groupBy('assistant_domain_store_id')
                ->groupByRaw($reportDateExpression)
                ->get()
                ->keyBy(fn (FashionLogisticsOrder $order): string => (int) $order->assistant_domain_store_id.'|'.$order->report_date);
            $orderMetrics = $personalOrderMetrics->groupBy('assistant_domain_store_id')->map(function ($metrics) {
                return (object) [
                    'order_count' => (int) $metrics->sum('order_count'),
                    'revenue' => (float) $metrics->sum('revenue'),
                ];
            });
        } else {
            $orderMetrics = $ordersQuery
                ->selectRaw('assistant_domain_store_id, COUNT(*) order_count, COALESCE(SUM(total_amount),0) revenue')
                ->groupBy('assistant_domain_store_id')->get()->keyBy('assistant_domain_store_id');
        }

        $reports = FashionAdvertisingReport::query()
            ->where('project_code', $projectCode)
            ->whereBetween('report_date', [$dateFrom, $dateTo])
            ->whereIn('submitter_id', $operatorIds)
            ->with('adSpendEntries')->get()->groupBy('submitter_id');
        $reportsByOperatorDate = $reports->flatMap(function ($operatorReports, $operatorId) {
            return $operatorReports->mapWithKeys(fn (FashionAdvertisingReport $report) => [
                (int) $operatorId.'|'.$report->report_date->format('Y-m-d') => $report,
            ]);
        });
        $personalDates = $isPersonalMode
            ? collect(range(0, (int) CarbonImmutable::parse($dateFrom, $timezone)->diffInDays(CarbonImmutable::parse($dateTo, $timezone))))
                ->map(fn (int $offset): string => CarbonImmutable::parse($dateFrom, $timezone)->addDays($offset)->toDateString())
            : collect();

        $selectedDepartmentIds = $request->has('department_ids')
            ? collect($validated['department_ids'] ?? [])->map(fn ($id) => (int) $id)->intersect($fashionDepartmentIds)->unique()->values()->all()
            : [];
        $allRows = $storesByOperator->map(function ($operatorStores, int $operatorId) use ($operators, $orderMetrics, $reports, $dateTo, $fashionDepartmentIds, $fashionRootDepartmentId, $isPersonalMode, $personalDates, $personalOrderMetrics, $reportsByOperatorDate, $profitCoefficient): ?array {
            $operator = $operators->get($operatorId);
            if (! $operator) {
                return null;
            }
            $department = $operator->departments->first(fn ($item) => (int) $item->id !== $fashionRootDepartmentId && $fashionDepartmentIds->contains((int) $item->id))
                ?: $operator->departments->first(fn ($item) => $fashionDepartmentIds->contains((int) $item->id))
                ?: $operator->departments->first(fn ($item) => (bool) ($item->pivot->is_primary ?? false))
                ?: $operator->departments->first();
            $storeRows = $operatorStores->map(function (AssistantDomainStore $store) use ($orderMetrics): array {
                $metric = $orderMetrics->get($store->getKey());

                $builder = mb_strtolower(trim((string) $store->site_builder));

                return ['name' => (string) ($store->shop_name ?: $store->domain), 'domain' => (string) $store->domain,
                    'site_builder' => match ($builder) {
                        'xshoppy', 'xshopy' => 'XShoppy',
                        'shopline' => 'Shopline',
                        'nbc' => 'NBC',
                        'shopyy' => 'ShopYY',
                        default => (string) ($store->site_builder ?: '未填写'),
                    },
                    'orders' => (int) ($metric->order_count ?? 0), 'revenue' => (float) ($metric->revenue ?? 0)];
            })->values();
            $orderCount = (int) $storeRows->sum('orders');
            $revenue = round((float) $storeRows->sum('revenue'), 2);
            $operatorReports = $reports->get($operatorId, collect());
            $includedReports = $operatorReports->whereIn('status', [FashionAdvertisingReport::STATUS_APPROVED, FashionAdvertisingReport::STATUS_REJECTED]);
            $media = $includedReports->flatMap->adSpendEntries->groupBy(fn ($entry) => trim((string) $entry->media) ?: '未设置媒体')
                ->map(function ($entries, string $name) use ($revenue): array {
                    $spend = round((float) $entries->sum('actual_spend_usd'), 2);

                    return ['name' => $name, 'spend' => $spend, 'roi' => $spend > 0 ? $revenue / $spend : null];
                })->sortKeys()->values();
            $totalSpend = round((float) $media->sum('spend'), 2);
            $submissionStatus = $operatorReports->isEmpty()
                ? 'not_submitted'
                : ($operatorReports->contains('status', FashionAdvertisingReport::STATUS_PENDING) ? 'pending' : 'submitted');
            $hireDays = $operator->hired_at ? max(1, $operator->hired_at->diffInDays(CarbonImmutable::parse($dateTo)) + 1) : null;
            $position = (string) ($department?->pivot?->position ?: Department::POSITION_MEMBER);
            $personalDays = $isPersonalMode ? $personalDates->map(function (string $date) use ($operatorStores, $operatorId, $personalOrderMetrics, $reportsByOperatorDate, $profitCoefficient, $department): array {
                $dayMetrics = $operatorStores->map(function (AssistantDomainStore $store) use ($personalOrderMetrics, $date) {
                    return $personalOrderMetrics->get((int) $store->getKey().'|'.$date);
                })->filter();
                $dayRevenue = round((float) $dayMetrics->sum('revenue'), 2);
                $dayOrders = (int) $dayMetrics->sum('order_count');
                $dayReport = $reportsByOperatorDate->get($operatorId.'|'.$date);
                $daySpend = $dayReport && in_array($dayReport->status, [FashionAdvertisingReport::STATUS_APPROVED, FashionAdvertisingReport::STATUS_REJECTED], true)
                    ? round((float) $dayReport->adSpendEntries->sum('actual_spend_usd'), 2)
                    : 0.0;
                $profit = round($dayRevenue / $profitCoefficient - $daySpend, 2);

                return ['date' => $date, 'order_count' => $dayOrders, 'revenue' => $dayRevenue, 'ad_spend' => $daySpend,
                    'roi' => $daySpend > 0 ? $dayRevenue / $daySpend : null, 'roi_class' => $this->roiClass($daySpend > 0 ? $dayRevenue / $daySpend : null), 'profit' => $profit,
                    'profit_status' => $profit > 0 ? 'profit' : ($profit < 0 ? 'loss' : 'even')];
            })->values() : collect();

            return ['department' => (string) ($department?->name ?: '未分配部门'), 'department_id' => (int) ($department?->id ?? 0), 'operator' => (string) ($operator->name ?: $operator->username),
                'is_resigned' => (string) $operator->employment_status === 'resigned',
                'team_position' => $position, 'team_rank' => match ($position) { Department::POSITION_MANAGER => 0, Department::POSITION_DEPUTY => 1, default => 2 },
                'hired_at' => $operator->hired_at?->format('Y-m-d'), 'hire_days' => $hireDays, 'stores' => $storeRows,
                'order_count' => $orderCount, 'revenue' => $revenue, 'aov' => $orderCount > 0 ? $revenue / $orderCount : null,
                'media' => $media, 'ad_spend' => $totalSpend, 'roi' => $totalSpend > 0 ? $revenue / $totalSpend : null,
                'roi_class' => $this->roiClass($totalSpend > 0 ? $revenue / $totalSpend : null),
                'personal_days' => $personalDays,
                'submission_status' => $submissionStatus,
                'submission_label' => match ($submissionStatus) {
                    'pending' => '已提报·待审核',
                    'submitted' => '已提报',
                    default => '未提报',
                }];
        })->filter()->values();

        $departmentOptions = $fashionDepartmentIds->isNotEmpty()
            ? $departmentRows->filter(fn (Department $department): bool => $fashionDepartmentIds->contains((int) $department->id)
                // 部门树尚未配置子部门时，项目根部门本身也必须可筛选；
                // 否则筛选菜单会被排空，只剩“全选/清空”按钮。
                )
                ->when($visibleDepartmentIds !== null, fn ($departments) => $departments->whereIn('id', $visibleDepartmentIds))
                ->sortBy(fn (Department $department): string => str_pad((string) ((int) $department->sort), 8, '0', STR_PAD_LEFT)
                    .mb_strtolower((string) $department->name))
                ->values()
            : collect();

        $rows = $allRows->filter(function (array $row) use ($validated, $selectedDepartmentIds, $fashionDepartmentIds, $fashionRootDepartmentId): bool {
            $operator = trim((string) ($validated['operator'] ?? ''));
            $matchesDepartment = $selectedDepartmentIds === []
                || (in_array($fashionRootDepartmentId, $selectedDepartmentIds, true) && $fashionDepartmentIds->contains((int) $row['department_id']))
                || in_array((int) $row['department_id'], $selectedDepartmentIds, true);

            return $matchesDepartment
                && ($operator === '' || str_contains(mb_strtolower($row['operator']), mb_strtolower($operator)));
        });
        $sortBy = (string) ($validated['sort_by'] ?? 'order_count');
        $sortOrder = (string) ($validated['sort_order'] ?? 'desc');
        $rows = $rows->sort(function (array $left, array $right) use ($sortBy, $sortOrder, $displayMode): int {
                if ($displayMode === 'team') {
                    return [$left['department'], $left['team_rank'], $left['operator']]
                        <=> [$right['department'], $right['team_rank'], $right['operator']];
                }
                $comparison = ((float) $left[$sortBy]) <=> ((float) $right[$sortBy]);
                if ($comparison === 0) {
                    $comparison = [$left['department'], $left['operator']] <=> [$right['department'], $right['operator']];
                }

                return $sortOrder === 'desc' ? -$comparison : $comparison;
            })->values();

        $personalRows = $isPersonalMode
            ? $rows->flatMap(function (array $row) {
                return collect($row['personal_days'] ?? [])->map(function (array $day) use ($row): array {
                    return [...$day, 'department' => $row['department'], 'operator' => $row['operator']];
                });
            })->sortByDesc(fn (array $row): string => $row['date'].'|'.$row['operator'])->values()
            : collect();
        $personalSummaryRows = $isPersonalMode
            ? $rows->map(function (array $row) use ($profitCoefficient): array {
                $days = collect($row['personal_days'] ?? []);
                $revenue = round((float) $days->sum('revenue'), 2);
                $adSpend = round((float) $days->sum('ad_spend'), 2);
                $profit = round($revenue / $profitCoefficient - $adSpend, 2);

                return [
                    'department' => $row['department'],
                    'operator' => $row['operator'],
                    'order_count' => (int) $days->sum('order_count'),
                    'revenue' => $revenue,
                    'ad_spend' => $adSpend,
                    'roi' => $adSpend > 0 ? $revenue / $adSpend : null,
                    'roi_class' => $this->roiClass($adSpend > 0 ? $revenue / $adSpend : null),
                    'profit' => $profit,
                    'continuous_loss_7' => $this->hasConsecutiveLosses($days, 7),
                    'continuous_loss_14' => $this->hasConsecutiveLosses($days, 14),
                    'continuous_loss' => $this->hasConsecutiveLosses($days, 7),
                    'days' => $days->values(),
                ];
            })->sortByDesc('profit')->values()
            : collect();

        $teamBands = [];
        if ($displayMode === 'team') {
            $departmentBands = [];
            foreach ($rows as $index => $row) {
                $departmentKey = (string) ($row['department_id'] ?? 0).'|'.(string) ($row['department'] ?? '');
                if (! array_key_exists($departmentKey, $departmentBands)) {
                    $departmentBands[$departmentKey] = count($departmentBands) % 2;
                }
                $teamBands[$index] = $departmentBands[$departmentKey];
            }
        }

        $summaryRevenue = (float) $rows->sum('revenue');
        $summarySpend = (float) $rows->sum('ad_spend');
        $roiRevenue = (float) $rows
            ->filter(fn (array $row): bool => (float) ($row['ad_spend'] ?? 0) > 0)
            ->sum('revenue');
        $summaryRoi = $summarySpend > 0 ? $roiRevenue / $summarySpend : null;
        return view('portals.assistant.fashion-operation-reports.index', [
            ...$context, 'rows' => $rows, 'personalRows' => $personalRows, 'personalSummaryRows' => $personalSummaryRows, 'isPersonalMode' => $isPersonalMode,
            'personalSummary' => ['profit' => (float) $personalSummaryRows->sum('profit'),
                'continuous_loss_people' => $personalSummaryRows->where('continuous_loss', true)->count(),
                'continuous_loss_7_people' => $personalSummaryRows->where('continuous_loss_7', true)->count(),
                'continuous_loss_14_people' => $personalSummaryRows->where('continuous_loss_14', true)->count()],
            'isDashboard' => $isDashboard, 'teamBands' => $teamBands, 'timezoneOptions' => $timezones,
            'fashionReportIndexRoute' => $isDashboard
                ? 'operation-dashboard.fashion-operation-reports.index'
                : 'assistant.fashion-operation-reports.index',
            'reportProject' => $project,
            'reportProjectLabel' => OperationProjectCatalog::shortName($projectCode),
            'departmentOptions' => $departmentOptions,
            'filters' => [...$validated, 'date_range' => $dateRange, 'date_from' => $dateFrom, 'date_to' => $dateTo, 'timezone' => $timezone,
                'exclude_resigned' => $excludeResigned, 'personal_range' => $personalRangeMode, 'profit_coefficient' => $profitCoefficient,
                'department_ids' => $selectedDepartmentIds, 'sort_by' => $sortBy, 'sort_order' => $sortOrder, 'display_mode' => $displayMode],
            'summary' => ['people' => $rows->count(), 'stores' => $rows->sum(fn ($row) => count($row['stores'])),
                'orders' => $rows->sum('order_count'), 'revenue' => $summaryRevenue, 'ad_spend' => $summarySpend,
                'aov' => $rows->sum('order_count') > 0 ? $summaryRevenue / $rows->sum('order_count') : null,
                'roi' => $summaryRoi, 'roi_class' => $this->roiClass($summaryRoi)],
        ]);
    }

    private function roiClass(?float $roi): string
    {
        if ($roi === null) return '';
        if ($roi > 1.8) return 'roi-excellent';
        if ($roi >= 1.6) return 'roi-good';
        if ($roi >= 1.4) return 'roi-warning';
        if ($roi >= 1.2) return 'roi-poor';
        return 'roi-danger';
    }

    private function timezoneOptions(): array
    {
        $options = [];
        for ($offset = -12; $offset <= 14; $offset++) {
            $value = sprintf('%s%02d:00', $offset < 0 ? '-' : '+', abs($offset));
            $options[$value] = 'UTC'.($offset >= 0 ? '+' : '').$offset.($offset === -8 ? '（默认）' : ($offset === 8 ? '（北京时间）' : ''));
        }

        return $options;
    }

    private function timezoneOffsetMinutes(string $timezone): int
    {
        $sign = str_starts_with($timezone, '-') ? -1 : 1;
        [$hours, $minutes] = array_map('intval', explode(':', ltrim($timezone, '+-')));

        return $sign * ($hours * 60 + $minutes);
    }

    /** @param \Illuminate\Support\Collection<int, array<string, mixed>> $days */
    private function hasConsecutiveLosses(\Illuminate\Support\Collection $days, int $requiredDays): bool
    {
        $streak = 0;
        foreach ($days as $day) {
            $streak = ($day['profit_status'] ?? null) === 'loss' ? $streak + 1 : 0;
            if ($streak >= $requiredDays) return true;
        }

        return false;
    }
}
