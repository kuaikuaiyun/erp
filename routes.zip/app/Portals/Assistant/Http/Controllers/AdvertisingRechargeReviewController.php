<?php

namespace App\Portals\Assistant\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\DailyAdvertisingRecharge;
use App\Models\InternalMessage;
use App\Models\InternalMessageRecipient;
use App\Portal\Http\Controllers\PortalEntryController;
use App\Portals\Assistant\AssistantPortalAuthorizationService;
use App\Portals\Assistant\AssistantStoreOwnerService;
use App\Portals\Assistant\DailyReportDepartmentScopeService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class AdvertisingRechargeReviewController extends Controller
{
    public function __construct(
        private readonly PortalEntryController $portalEntries,
        private readonly AssistantPortalAuthorizationService $authorization,
        private readonly AssistantStoreOwnerService $assistantStoreOwners,
        private readonly DailyReportDepartmentScopeService $departmentScopes,
    ) {}

    public function index(Request $request): Response|View
    {
        $context = $this->context($request);
        if ($context instanceof Response) return $context;
        $filters = $request->validate([
            'operation_department_ids' => ['nullable', 'array'],
            'operation_department_ids.*' => ['integer', 'distinct'],
            'status' => ['nullable', 'in:pending,processing,processed,rejected'],
            'date_from' => ['nullable', 'date_format:Y-m-d'],
            'date_to' => ['nullable', 'date_format:Y-m-d'],
            'operator' => ['nullable', 'string', 'max:100'],
        ]);

        $query = DailyAdvertisingRecharge::query();
        $allDepartments = $this->assistantStoreOwners->boundBusinessDepartments();
        $departmentIds = null;
        $departmentIds = $this->departmentScopes->visibleIdsForReview($context['user']);
        if ($departmentIds !== null) {
            $departmentIds === [] ? $query->whereRaw('1 = 0') : $query->whereIn('operation_department_id', $departmentIds);
        }
        $departmentOptions = $departmentIds === null
            ? $allDepartments
            : $allDepartments->whereIn('id', $departmentIds)->values();

        $today = now('Asia/Shanghai')->toDateString();
        $summaryFrom = $filters['date_from'] ?? $filters['date_to'] ?? $today;
        $summaryTo = $filters['date_to'] ?? $filters['date_from'] ?? $today;
        if ($summaryFrom > $summaryTo) [$summaryFrom, $summaryTo] = [$summaryTo, $summaryFrom];
        $summaryQuery = (clone $query)
            ->when($filters['operation_department_ids'] ?? [], fn ($q, $ids) => $q->whereIn('operation_department_id', $ids))
            ->when($filters['status'] ?? null, fn ($q, $status) => $q->where('status', $status))
            ->when($filters['operator'] ?? null, fn ($q, $name) => $q->where('operator_name', 'like', '%'.$name.'%'))
            ->whereDate('report_date', '>=', $summaryFrom)
            ->whereDate('report_date', '<=', $summaryTo);
        $todaySubmissions = $summaryQuery->orderBy('report_date')->orderBy('id')->get();
        $todayRechargeGroups = [];
        foreach ($todaySubmissions as $submission) {
            foreach ($submission->entries ?? [] as $entryIndex => $entry) {
                $entryStatus = (string) ($entry['status'] ?? ($submission->status === DailyAdvertisingRecharge::STATUS_PROCESSED ? DailyAdvertisingRecharge::STATUS_PROCESSED : DailyAdvertisingRecharge::STATUS_PENDING));
                if ($entryStatus === DailyAdvertisingRecharge::STATUS_REJECTED) continue;
                $agencyName = trim((string) ($entry['agency'] ?? '')) ?: '未设置代理';
                $mediaName = trim((string) ($entry['media'] ?? '')) ?: '未设置平台';
                $key = mb_strtolower($mediaName).'|'.mb_strtolower($agencyName);
                if (! isset($todayRechargeGroups[$key])) {
                    $todayRechargeGroups[$key] = [
                        'agency_id' => (int) ($entry['agency_id'] ?? 0),
                        'agency' => $agencyName,
                        'media' => $mediaName,
                        'details' => [],
                    ];
                }
                $todayRechargeGroups[$key]['details'][] = [
                    'submission_id' => (int) $submission->getKey(),
                    'entry_index' => (int) $entryIndex,
                    'operator_user_id' => (int) $submission->operator_user_id,
                    'operator_name' => (string) $submission->operator_name,
                    'operation_department_name' => (string) ($submission->operation_department_name ?? ''),
                    'account_name' => (string) ($entry['account_name'] ?? ''),
                    'account_number' => (string) ($entry['account_number'] ?? ''),
                    'amount' => round((float) ($entry['amount'] ?? 0), 2),
                    'submitted_at' => $submission->created_at?->timezone('Asia/Shanghai')->format('Y-m-d H:i:s'),
                    'status' => $entryStatus,
                ];
            }
        }
        $todayTotalAmount = collect($todayRechargeGroups)->sum(fn ($group) => collect($group['details'])->sum('amount'));
        $todayRechargeGroups = collect($todayRechargeGroups)->map(function (array $group) use ($todayTotalAmount): array {
            $details = collect($group['details']);
            $amount = round((float) $details->sum('amount'), 2);
            return [...$group,
                'entry_count' => $details->count(),
                'people_count' => $details->pluck('operator_user_id')->unique()->count(),
                'amount' => $amount,
                'percentage' => $todayTotalAmount > 0 ? round($amount / $todayTotalAmount * 100, 1) : 0,
            ];
        })->values();

        $query->when($filters['operation_department_ids'] ?? [], fn ($q, $ids) => $q->whereIn('operation_department_id', $ids))
            ->when($filters['status'] ?? null, fn ($q, $status) => $q->where('status', $status))
            ->when($filters['date_from'] ?? null, fn ($q, $date) => $q->whereDate('report_date', '>=', $date))
            ->when($filters['date_to'] ?? null, fn ($q, $date) => $q->whereDate('report_date', '<=', $date))
            ->when($filters['operator'] ?? null, fn ($q, $name) => $q->where('operator_name', 'like', '%'.$name.'%'));

        return view('portals.assistant.daily-submissions.advertising-recharge', [
            'portal' => $context['portal']->loadMissing('menus'),
            'user' => $context['user'],
            'filters' => $filters,
            'departmentOptions' => $departmentOptions,
            'today' => $summaryFrom === $summaryTo ? $summaryFrom : $summaryFrom.' 至 '.$summaryTo,
            'summaryFrom' => $summaryFrom,
            'summaryTo' => $summaryTo,
            'summaryDateLabel' => $summaryFrom === $summaryTo ? $summaryFrom : $summaryFrom.' 至 '.$summaryTo,
            'todayRechargeGroups' => $todayRechargeGroups,
            'todayRechargeSummary' => [
                'group_count' => $todayRechargeGroups->count(),
                'entry_count' => $todayRechargeGroups->sum('entry_count'),
                'people_count' => collect($todayRechargeGroups)->flatMap(fn ($group) => $group['details'])->pluck('operator_user_id')->unique()->count(),
                'amount' => $todayTotalAmount,
            ],
            'submissions' => $query->orderByRaw("CASE WHEN status = 'pending' THEN 0 ELSE 1 END")
                ->latest('report_date')->latest('id')->paginate(20)->withQueryString(),
        ]);
    }

    public function process(Request $request, DailyAdvertisingRecharge $submission): RedirectResponse
    {
        $context = $this->context($request);
        if ($context instanceof Response) abort($context->getStatusCode());
        $visibleDepartmentIds = $this->departmentScopes->visibleIdsForReview($context['user']);
        if ($visibleDepartmentIds !== null) abort_unless(in_array((int) $submission->operation_department_id, $visibleDepartmentIds, true), 403);

        $validated = $request->validate([
            'entry_index' => ['required', 'integer', 'min:0'],
            'decision' => ['required', 'in:processed,rejected'],
            'response_text' => ['nullable', 'string', 'max:5000', 'required_if:decision,rejected'],
        ], [
            'entry_index.required' => '请选择要处理的广告充值明细。',
            'response_text.required_if' => '请填写驳回原因。',
        ]);
        $entryIndex = (int) $validated['entry_index'];
        $decision = (string) $validated['decision'];
        $responseText = trim((string) ($validated['response_text'] ?? ''));
        $processorId = (int) $context['user']->getKey();
        $processorName = (string) ($context['user']->name ?: $context['user']->username);

        $submission->getConnection()->transaction(function () use ($submission, $entryIndex, $decision, $responseText, $processorId, $processorName): void {
            /** @var DailyAdvertisingRecharge $locked */
            $locked = DailyAdvertisingRecharge::query()->lockForUpdate()->findOrFail($submission->getKey());
            $entries = array_values($locked->entries ?? []);
            abort_unless(isset($entries[$entryIndex]), 422, '该广告充值明细不存在，请刷新页面后重试。');
            $currentStatus = (string) ($entries[$entryIndex]['status'] ?? ($locked->status === DailyAdvertisingRecharge::STATUS_PROCESSED ? DailyAdvertisingRecharge::STATUS_PROCESSED : DailyAdvertisingRecharge::STATUS_PENDING));
            abort_unless(in_array($currentStatus, [DailyAdvertisingRecharge::STATUS_PENDING, DailyAdvertisingRecharge::STATUS_PROCESSING], true), 422, '该广告充值明细已经处理，请刷新页面查看最新状态。');

            $processedAt = now();
            $entries[$entryIndex]['status'] = $decision;
            $entries[$entryIndex]['response_text'] = $responseText ?: null;
            $entries[$entryIndex]['processed_by'] = $processorId;
            $entries[$entryIndex]['processed_by_name'] = $processorName;
            $entries[$entryIndex]['processed_at'] = $processedAt->toDateTimeString();
            $aggregateStatus = $this->aggregateStatus($entries);

            $locked->update([
                'entries' => $entries,
                'status' => $aggregateStatus,
                'processed_by' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? $processorId : null,
                'processed_by_name' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? $processorName : null,
                'processed_at' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? $processedAt : null,
            ]);
        });

        return back()->with('success', $decision === DailyAdvertisingRecharge::STATUS_REJECTED ? '该条广告充值明细已驳回，且不会计入充值统计。' : '该条广告充值明细已标记为已处理。');
    }

    public function markProcessing(Request $request, DailyAdvertisingRecharge $submission): RedirectResponse
    {
        $context = $this->context($request);
        if ($context instanceof Response) abort($context->getStatusCode());
        $visibleDepartmentIds = $this->departmentScopes->visibleIdsForReview($context['user']);
        if ($visibleDepartmentIds !== null) abort_unless(in_array((int) $submission->operation_department_id, $visibleDepartmentIds, true), 403);
        $validated = $request->validate(['entry_index' => ['required', 'integer', 'min:0']]);
        $entryIndex = (int) $validated['entry_index'];
        $processorId = (int) $context['user']->getKey();
        $processorName = (string) ($context['user']->name ?: $context['user']->username);

        $submission->getConnection()->transaction(function () use ($submission, $entryIndex, $processorId, $processorName): void {
            $locked = DailyAdvertisingRecharge::query()->lockForUpdate()->findOrFail($submission->getKey());
            $entries = array_values($locked->entries ?? []);
            abort_unless(isset($entries[$entryIndex]), 422, '该广告充值明细不存在，请刷新页面后重试。');
            $currentStatus = (string) ($entries[$entryIndex]['status'] ?? DailyAdvertisingRecharge::STATUS_PENDING);
            abort_unless($currentStatus === DailyAdvertisingRecharge::STATUS_PENDING, 422, '该广告充值明细已进入处理流程，请刷新页面查看最新状态。');
            $entries[$entryIndex]['status'] = DailyAdvertisingRecharge::STATUS_PROCESSING;
            $entries[$entryIndex]['processed_by'] = $processorId;
            $entries[$entryIndex]['processed_by_name'] = $processorName;
            $entries[$entryIndex]['processed_at'] = now()->toDateTimeString();
            $locked->update(['entries' => $entries, 'status' => $this->aggregateStatus($entries)]);
        });

        return back()->with('success', '该条广告充值明细已标记为处理中，运营端可同步查看。');
    }

    public function processSelected(Request $request): RedirectResponse
    {
        $context = $this->context($request);
        if ($context instanceof Response) abort($context->getStatusCode());
        $validated = $request->validate([
            'records' => ['required', 'array', 'min:1', 'max:100'],
            'records.*' => ['required', 'string', 'regex:/^\d+:\d+$/'],
        ], ['records.required' => '请至少勾选一条充值记录。', 'records.min' => '请至少勾选一条充值记录。']);

        $selected = collect($validated['records'])->unique()->map(function (string $record): array {
            [$submissionId, $entryIndex] = array_map('intval', explode(':', $record, 2));
            return compact('submissionId', 'entryIndex');
        })->groupBy('submissionId');
        $processorId = (int) $context['user']->getKey();
        $processorName = (string) ($context['user']->name ?: $context['user']->username);
        $visibleDepartmentIds = $this->departmentScopes->visibleIdsForReview($context['user']);
        $today = now('Asia/Shanghai')->toDateString();

        $processedCount = DB::connection((new DailyAdvertisingRecharge)->getConnectionName())->transaction(function () use ($selected, $processorId, $processorName, $visibleDepartmentIds, $today, $context): int {
            $notifications = [];
            $processedCount = 0;
            foreach ($selected as $submissionId => $items) {
                $submission = DailyAdvertisingRecharge::query()->lockForUpdate()->findOrFail((int) $submissionId);
                abort_unless($submission->report_date?->toDateString() === $today, 422, '只能从今日充值统计中处理当天提交的记录。');
                if ($visibleDepartmentIds !== null) abort_unless(in_array((int) $submission->operation_department_id, $visibleDepartmentIds, true), 403);
                $entries = array_values($submission->entries ?? []);
                foreach ($items->pluck('entryIndex')->unique() as $entryIndex) {
                    abort_unless(isset($entries[$entryIndex]), 422, '所选充值明细不存在，请刷新页面后重试。');
                    $status = (string) ($entries[$entryIndex]['status'] ?? ($submission->status === DailyAdvertisingRecharge::STATUS_PROCESSED ? DailyAdvertisingRecharge::STATUS_PROCESSED : DailyAdvertisingRecharge::STATUS_PENDING));
                    if (! in_array($status, [DailyAdvertisingRecharge::STATUS_PENDING, DailyAdvertisingRecharge::STATUS_PROCESSING], true)) continue;
                    $processedAt = now();
                    $entries[$entryIndex]['status'] = DailyAdvertisingRecharge::STATUS_PROCESSED;
                    $entries[$entryIndex]['processed_by'] = $processorId;
                    $entries[$entryIndex]['processed_by_name'] = $processorName;
                    $entries[$entryIndex]['processed_at'] = $processedAt->toDateTimeString();
                    $notifications[(int) $submission->operator_user_id][] = $entries[$entryIndex];
                    $processedCount++;
                }
                $aggregateStatus = $this->aggregateStatus($entries);
                $submission->update([
                    'entries' => $entries,
                    'status' => $aggregateStatus,
                    'processed_by' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? $processorId : null,
                    'processed_by_name' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? $processorName : null,
                    'processed_at' => in_array($aggregateStatus, [DailyAdvertisingRecharge::STATUS_PROCESSED, DailyAdvertisingRecharge::STATUS_REJECTED], true) ? now() : null,
                ]);
            }
            abort_if($processedCount === 0, 422, '所选记录均已处理，请刷新页面查看最新状态。');
            foreach ($notifications as $recipientId => $entries) {
                $lines = collect($entries)->map(fn (array $entry) => sprintf(
                    '%s / %s｜账户：%s（%s）｜充值金额：$%s',
                    $entry['agency'] ?? '未设置代理', $entry['media'] ?? '未设置社媒',
                    $entry['account_name'] ?? '—', $entry['account_number'] ?? '—',
                    number_format((float) ($entry['amount'] ?? 0), 2)
                ));
                $message = InternalMessage::query()->create([
                    'title' => '广告充值处理完成通知',
                    'content' => "您提交的以下广告充值记录已处理完成：\n\n".$lines->implode("\n")."\n\n处理人：{$processorName}",
                    'sender_user_id' => $processorId,
                    'sender_name' => $processorName,
                    'sender_portal_code' => (string) $context['portal']->code,
                    'sender_portal_name' => (string) $context['portal']->name,
                    'published_at' => now(),
                ]);
                InternalMessageRecipient::query()->create([
                    'internal_message_id' => $message->getKey(),
                    'recipient_user_id' => $recipientId,
                ]);
            }
            return $processedCount;
        });

        return back()->with('success', "已处理 {$processedCount} 条充值记录，并已发送站内消息通知对应运营人员。");
    }

    private function context(Request $request): array|Response
    {
        $context = $this->portalEntries->portalContext($request);
        if ($context instanceof Response) return $context;
        $this->authorization->assertAssistantPortal($context['portal']);
        abort_unless($this->authorization->isAssistantDepartmentMember($context['user']), 403);
        return $context;
    }

    /** @param list<array<string, mixed>> $entries */
    private function aggregateStatus(array $entries): string
    {
        $statuses = collect($entries)->map(fn (array $entry) => (string) ($entry['status'] ?? DailyAdvertisingRecharge::STATUS_PENDING));
        if ($statuses->contains(DailyAdvertisingRecharge::STATUS_PROCESSING)) return DailyAdvertisingRecharge::STATUS_PROCESSING;
        if ($statuses->contains(DailyAdvertisingRecharge::STATUS_PENDING)) return DailyAdvertisingRecharge::STATUS_PENDING;
        if ($statuses->contains(DailyAdvertisingRecharge::STATUS_REJECTED)) {
            return DailyAdvertisingRecharge::STATUS_REJECTED;
        }

        return DailyAdvertisingRecharge::STATUS_PROCESSED;
    }
}
