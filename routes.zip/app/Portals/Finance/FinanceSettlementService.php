<?php

namespace App\Portals\Finance;

use App\Models\AdminUser;
use App\Models\AssistantDomainStore;
use App\Models\AssistantDomainStoreOwnerHistory;
use App\Models\FinancePaymentAccount;
use App\Models\FinanceRecord;
use App\Models\LogisticsOrderPaymentReference;
use App\Portals\Assistant\AssistantStoreOwnerService;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Collection;

class FinanceSettlementService
{
    public const CREDIT_SUMMARY_VERSION = 3;

    public const PAYPAL_SUMMARY_VERSION = 3;

    public static function summarySourceSchemaVersion(string $channel): int
    {
        return match ($channel) {
            'credit_card' => 3 + self::CREDIT_SUMMARY_VERSION,
            'paypal' => 2 + self::PAYPAL_SUMMARY_VERSION,
            default => 4,
        };
    }

    public const REPORT_CHANNELS = ['paypal' => 'PayPal', 'xuzong' => '徐总支付', 'xuzong1' => '徐总支付 1', 'xuzong2' => '徐总支付 2',
        'ye' => '叶总支付', 'worldpay' => 'Worldpay', 'credit_card' => '信用卡合计', 'combined' => '全部通道'];
    public const PAYPAL_COST_HEADERS = ['通途订单', '物流-元', '采购成本-元'];

    public const OPERATION_DEPARTMENT = '运营所属部门';

    public const CARD_TRANSACTION_STATUSES = ['success' => '成功', 'failed' => '失败', 'pending' => '处理中'];
    public const CARD_FAILURE_STATUSES = ['D', 'FAIL', 'FAILED', 'FAILURE', 'DECLINED', 'ERROR', '已拒绝', '失败'];

    private const TRANSACTION_STATUS_CODES = [
        'success' => ['S', 'SUCCESS', 'COMPLETED', 'PAID', '已付款', '已完成', '成功'],
        'failed' => self::CARD_FAILURE_STATUSES,
        'pending' => ['P', 'PENDING', 'PROCESSING', '待处理', '处理中'],
    ];

    public const CONDITION_FIELDS = ['account' => '支付账户', 'reference' => '交易单号', 'team' => '团队', 'owner' => '使用人',
        'domain' => '域名', 'subscription' => '订阅类型', 'gross' => '原币总额', 'settlement' => '结算金额',
        'fee' => '手续费', 'refund' => '退款金额', 'note' => '备注'];
    public const MONEY = [
        'converted_usd' => '转换美元',
        'usd_rate' => '折算美元汇率', 'fee' => '手续费', 'hold' => '冻结金额', 'dispute_hold' => '争议冻结金额',
        ...FinancePayPalSettlementOrders::REFUND_SPLIT_COLUMNS,
        'refund' => '退款金额', 'refund_fee' => '退款费用', 'dispute_refund' => '争议退款', 'dispute_fee' => '争议费',
        'fee_return' => '返还手续费', 'dispute_release' => '返还争议冻结', 'release' => '返还冻结',
        'per_order_fee' => '单笔费用（含失败交易）', 'chargeback' => '拒付金额', 'chargeback_fee' => '拒付费用',
        'ethoca_refund' => 'ETHOCA预警退款', 'ethoca_fee' => 'ETHOCA费用', 'rdr_refund' => 'RDR退款', 'rdr_fee' => 'RDR费用',
        'cdrn_fee' => 'CDRN费用', 'chargeback_return' => '拒付返还',
        'logistics' => '物流费用（人民币）', 'purchase' => '采购成本（人民币）',
    ];
    public const TEXT = ['domain' => '域名', 'subscription' => '订阅类型', 'upsell' => '是否加购', 'erp_order' => '通途订单', 'note' => '备注'];
    public const EXPORT = ['id' => '记录ID', 'account' => '支付账户', 'reference' => '交易单号', 'date' => '交易时间', 'timezone' => '时区', 'month' => '年月', 'status' => '支付状态', 'currency' => '原币币种', 'gross' => '原币总额', 'settlement' => '结算金额（美元）', 'domain' => '域名', 'owner' => '使用人', 'team' => '团队', 'subscription' => '订阅类型', 'upsell' => '是否加购', 'erp_order' => '通途订单', 'note' => '备注'];

    public function __construct(private readonly FinanceWorkbookService $workbooks) {}

    public function textFields(string $channel): array
    {
        return $channel === 'paypal'
            ? [...self::TEXT, 'owner' => '使用人', 'team' => '团队', 'paypal_12' => '偏好设定 Txn ID']
            : [...self::TEXT, 'owner' => '使用人', 'team' => '团队'];
    }

    public function importFields(string $channel): array
    {
        if ($channel === 'paypal') {
            return ['reference' => '交易 ID', 'erp_order' => '通途订单', 'converted_usd' => '转换美元', 'usd_rate' => '汇率', 'hold' => '冻结金额', 'dispute_hold' => '争议冻结金额',
                ...FinancePayPalSettlementOrders::REFUND_SPLIT_COLUMNS,
                'refund' => '退款金额', 'refund_fee' => '退款费用', 'dispute_refund' => '争议退款', 'dispute_fee' => '争议费',
                'fee_return' => '返还手续费', 'dispute_release' => '返还争议冻结', 'release' => '返还冻结',
                'logistics' => '物流-元', 'purchase' => '采购成本-元',
                ...$this->textFields($channel)];
        }

        return ['merchant_order' => '商户订单号', 'reference' => '平台订单号', 'erp_order' => '通途订单',
            'settlement' => '结算金额', 'hold' => '保证金', 'fee' => '交易手续费', 'per_order_fee' => '单笔费用',
            'refund' => '退款金额', 'refund_fee' => '退款费用', 'chargeback' => '拒付金额', 'chargeback_fee' => '拒付费用',
            'ethoca_refund' => 'ethoca预警退款', 'ethoca_fee' => '拒付预警ethoca', 'rdr_refund' => '拒付RDR金额',
            'rdr_fee' => '拒付RDR+CDRN费用', 'release' => '保证金返还', 'logistics' => '物流-元', 'purchase' => '采购成本-元',
            'usd_rate' => '汇率', ...$this->textFields($channel)];
    }

    public function columns(string $channel): array
    {
        if ($channel !== 'paypal') {
            return [...self::EXPORT, 'source_settlement_usd' => '结算-美元', ...$this->moneyFields($channel), 'currency_warning' => '币种核对'];
        }
        $source = [];
        foreach (array_slice(FinanceCatalog::dataset('paypal-orders')['headers'], 0, 15) as $index => $header) {
            $source[$index === 11 ? 'reference' : 'paypal_'.$index] = FinanceCatalog::simplified($header);
        }

        return ['id' => '记录ID', 'account' => '支付账户', ...$source,
            'month' => '年月', 'date' => '时间点', 'timezone' => '导出时区', 'subscription' => '订阅类型', 'upsell' => '是否加购',
            'converted_usd' => '转换美元', 'usd_rate' => '汇率', 'settlement' => '结算金额-美元',
            ...array_diff_key($this->moneyFields('paypal'), array_flip(['converted_usd', 'usd_rate'])),
            'domain' => '域名', 'owner' => '使用人', 'team' => self::OPERATION_DEPARTMENT, 'operation_region' => '地区',
            'erp_order' => '通途订单', 'note' => '备注', 'product_name' => '商品名称-简称'];
    }

    public function exportColumns(string $channel): array
    {
        $columns = $this->listColumns($channel);
        if ($channel !== 'paypal') {
            return $columns;
        }

        return $columns + FinancePayPalSettlementOrders::sourceExportColumns();
    }

    public const SHOP_DIFFERENCE_LABEL = '与店铺差额（美元）';

    public const SHOP_DIFFERENCE_COLUMN = ['shop_difference_usd' => self::SHOP_DIFFERENCE_LABEL];

    public function listColumns(string $channel): array
    {
        $columns = $this->columns($channel) + self::SHOP_DIFFERENCE_COLUMN;

        return $channel === 'paypal' ? FinancePayPalSettlementOrders::listColumns($columns) : $columns;
    }

    public function conditionFields(string $channel): array
    {
        if ($channel !== 'paypal') {
            return self::CONDITION_FIELDS;
        }

        return $this->listColumns($channel) + ['gross' => self::CONDITION_FIELDS['gross']];
    }

    public function numericConditionFields(string $channel): array
    {
        return $channel === 'paypal'
            ? ['id', 'gross', 'paypal_7', 'paypal_8', 'paypal_9', 'settlement', 'payable', 'open_hold',
                ...array_keys($this->moneyFields($channel))]
            : ['gross', 'settlement', 'fee', 'refund'];
    }

    public function query(string $channel, array $filters)
    {
        $creditSources = ['xuzong2-orders', 'xuzong2-details', 'xuzong1-details'];
        if (! empty($filters['summary_only'])) {
            $creditSources = [...$creditSources, ...array_values(FinanceCatalog::XUZONG_REPORT_IMPORTS), FinanceLogisticsCreditOrders::IMPORTED_DATASET];
        }
        $structured = empty($filters['_legacy_source']) && empty($filters['card_wallet'])
            && ! in_array($filters['card_match'] ?? null, ['matched', 'waiting'], true) && app(FinanceTransactions::class)->ready();
        $query = FinanceRecord::query();
        if ($structured) $query->from('finance_transactions as finance_records');
        $query->whereIn('finance_records.dataset', $channel === 'paypal' ? ['paypal-orders'] : $creditSources);
        $query->whereNotIn('finance_records.id', function ($deleted): void {
            $deleted->select('finance_settlement_supplements.finance_record_id')->from('finance_settlement_supplements')
                ->whereNotNull('finance_settlement_supplements.finance_record_id')
                ->whereNotNull('finance_settlement_supplements.payload->_deleted_at');
        });
        $this->filterAccountHistory($query, $channel);
        if ($channel === 'paypal') {
            $types = $this->workbooks->database()->table('finance_transaction_types')->where('category', '结账付款')->pluck('raw_type');
            $query->whereIn('finance_records.raw_type', $types)->where('finance_records.raw_type', 'not like', 'T04%')
                ->where('finance_records.raw_type', 'not like', 'T02%');
        } elseif (($filters['source'] ?? '') !== '') {
            $query->where('finance_records.dataset', $filters['source']);
        } else {
            // Imported current-card details take precedence over an order with the same account/reference.
            $query->where(function ($query) use ($structured): void {
                $query->whereNotIn('finance_records.dataset', ['xuzong2-orders', FinanceLogisticsCreditOrders::IMPORTED_DATASET])->orWhereNotExists(function ($sub) use ($structured): void {
                    $sub->selectRaw('1')->from(($structured ? 'finance_transactions' : 'finance_records').' as detail')->where('detail.dataset', 'xuzong2-details')
                        ->whereColumn('detail.account', 'finance_records.account')->whereColumn('detail.reference', 'finance_records.reference');
                    if ($structured) {
                        $sub->join('finance_card_transaction_details as detail_refs', 'detail_refs.record_id', '=', 'detail.id')
                            ->whereExists(function ($refs): void {
                                $refs->selectRaw('1')->from('finance_card_transaction_details as order_refs')->whereColumn('order_refs.record_id', 'finance_records.id')
                                    ->where(fn ($match) => $match->whereColumn('detail_refs.merchant_order', 'order_refs.shopify_order')
                                        ->orWhereColumn('detail_refs.merchant_order', 'order_refs.merchant_order'));
                            });
                    } else {
                        $sub->where(function ($match): void {
                            $match->whereColumn('detail.payload->商户订单号', 'finance_records.payload->Shopify订单号')
                                ->orWhereColumn('detail.payload->商户订单号', 'finance_records.payload->商户订单号');
                        });
                    }
                    $sub->whereColumn('detail.occurred_at', 'finance_records.occurred_at')->whereColumn('detail.currency', 'finance_records.currency')
                        ->whereColumn('detail.status', 'finance_records.status');
                });
            });
        }
        if ($channel === 'credit_card' && filled($filters['card_channel'] ?? null)) {
            FinanceCreditSettlementLayout::filter($query, $filters['card_channel'], structured: empty($filters['_legacy_source']));
        }
        if ($channel === 'credit_card' && ! empty($filters['summary_payment_channels']) && app(FinanceTransactions::class)->ready()) {
            app(FinanceTransactions::class)->filter($query, $filters['summary_payment_channels']);
        } elseif ($channel === 'credit_card' && ! empty($filters['summary_payment_channels'])) {
            $accounts = FinancePaymentAccount::query()->where('account_type', 'credit_card')->get();
            $predicates = [];
            foreach (['ye', 'worldpay'] as $platform) {
                $match = FinanceRecord::query();
                FinanceCreditSettlementLayout::filter($match, $platform, $accounts);
                $predicates[$platform] = [substr($match->getQuery()->getGrammar()->compileWheres($match->getQuery()), strlen('where ')), $match->getBindings()];
            }
            if (array_intersect($filters['summary_payment_channels'], ['xuzong1', 'xuzong2'])) {
                foreach ($predicates as [$predicate, $bindings]) {
                    // CASE preserves the classifier's treatment of SQL NULL as not matched.
                    $query->whereRaw('CASE WHEN '.$predicate.' THEN 1 ELSE 0 END = 0', $bindings);
                }
            } else {
                $query->where(function ($scope) use ($predicates, $filters) {
                    foreach ($filters['summary_payment_channels'] as $platform) {
                        if (isset($predicates[$platform])) {
                            [$predicate, $bindings] = $predicates[$platform];
                            $scope->orWhereRaw('CASE WHEN '.$predicate.' THEN 1 ELSE 0 END = 1', $bindings);
                        }
                    }
                });
            }
        }
        if (($filters['card_channel'] ?? null) === 'ye' && in_array($filters['card_match'] ?? null, ['matched', 'waiting'], true)) {
            app(FinanceConfluxSettlement::class)->filterOrderMatch($query, $filters['card_match'] === 'matched');
        }
        if (($filters['card_channel'] ?? null) === 'ye' && ! empty($filters['card_wallet'])) {
            app(FinanceConfluxSettlement::class)->filterWalletCandidates($query);
        }
        if (! empty($filters['export_record_ids'])) {
            $query->whereIntegerInRaw('finance_records.id', $filters['export_record_ids']);
        }
        if (($filters['card_channel'] ?? null) === 'worldpay' && filled($filters['gateway'] ?? null)) {
            if (app(FinanceTransactions::class)->ready()) {
                $query->whereIn('finance_records.id', $this->workbooks->database()->table('finance_card_transaction_details')
                    ->select('record_id')->where('gateway', $filters['gateway']));
            } else $query->where('finance_records.payload->网关接入号', $filters['gateway']);
        }
        if (($filters['card_channel'] ?? null) === 'worldpay') {
            if (app(FinanceTransactions::class)->ready() && filled($filters['worldpay_exception'] ?? null)) {
                $query->whereIn('finance_records.id', $this->workbooks->database()->table('finance_card_transaction_details')->select('record_id')
                    ->where('has_worldpay_events', $filters['worldpay_exception'] === 'yes'));
            } else {
            match ($filters['worldpay_exception'] ?? null) {
                'yes' => $query->whereNotNull('finance_records.payload->_worldpay_events'),
                'no' => $query->whereNull('finance_records.payload->_worldpay_events'),
                default => null,
            };
            }
        }
        if ($channel === 'credit_card' && filled($filters['card_group'] ?? null)) {
            $query->whereIn('finance_records.account', FinancePaymentAccount::query()->where('account_type', 'credit_card')
                ->where('card_group_id', $filters['card_group'])->select('activity_account'));
        }
        $statusCodes = self::TRANSACTION_STATUS_CODES[$filters['card_transaction_status'] ?? ''] ?? null;
        if ($channel === 'credit_card' && $statusCodes !== null) {
            $query->whereIn($structured ? 'finance_records.status_code' : $query->getQuery()->raw('UPPER(TRIM(finance_records.status))'), $statusCodes);
        }
        foreach (['account', 'reference'] as $field) {
            if (filled($filters[$field] ?? null)) {
                $query->where('finance_records.'.$field, $filters[$field]);
            }
        }
        if ($channel === 'credit_card') FinanceFilterSelection::applyQuery($query, 'finance_records.account', $filters['accounts'] ?? []);
        $zone = $filters['timezone'] ?? 'Asia/Shanghai';
        if (filled($filters['from'] ?? null)) {
            $query->where('finance_records.occurred_at', '>=', CarbonImmutable::parse($filters['from'], $zone)->utc());
        }
        if (filled($filters['to'] ?? null)) {
            $query->where('finance_records.occurred_at', '<', CarbonImmutable::parse($filters['to'], $zone)->addDay()->utc());
        }

        return $query;
    }

    public function filterAccountHistory($query, string $channel): void
    {
        // Materialize the small account list instead of correlated account subqueries.
        $accounts = FinancePaymentAccount::withTrashed()->where('account_type', $channel)
            ->get(['id', 'activity_account', 'deleted_at']);
        $deleted = $accounts->whereNotNull('deleted_at');
        $liveNames = $accounts->whereNull('deleted_at')->pluck('activity_account');
        $deletedNames = $deleted->pluck('activity_account')->diff($liveNames)->unique()->values();
        if ($deleted->isNotEmpty()) {
            $db = $this->workbooks->database();
            $query->whereNotIn('finance_records.id', $db->table('finance_payment_transactions')
                ->select('finance_record_id')->whereIn('payment_account_id', $deleted->pluck('id')));
            if ($deletedNames->isNotEmpty()) {
                $query->where(function ($scope) use ($deletedNames, $db): void {
                    $scope->whereNotIn('finance_records.account', $deletedNames)
                        ->orWhereIn('finance_records.id', $db->table('finance_payment_transactions')
                            ->select('finance_record_id'));
                });
            }
        }
    }

    public function rowContext(string $channel): array
    {
        $accountModels = FinancePaymentAccount::query()->where('account_type', $channel)->get();
        $accounts = $accountModels->pluck('account_name', 'activity_account');
        $accountsById = $accountModels->keyBy('id');
        $domainGroups = $this->workbooks->domainGroups(withAssignedOwner: $channel === 'paypal');
        $storesById = $channel === 'paypal' ? $domainGroups->keyBy('id') : collect();
        $domains = $channel === 'paypal'
            ? $domainGroups->groupBy('domain')->filter(fn ($groups) => $groups->count() === 1)->map(fn ($groups) => $groups->first())
            : $domainGroups->keyBy('domain');
        $uniqueDomains = $domainGroups->groupBy(fn ($store) => strtolower(trim($store->domain)))
            ->filter(fn ($stores) => $stores->count() === 1)->map(fn ($stores) => $stores->first());
        $yeDomains = $domainGroups->keyBy(fn ($store) => FinanceYeDomains::normalize($store->domain));
        $brushStores = $channel === 'paypal' ? $domainGroups
            ->filter(fn ($group) => filled($group->shop_name ?? null))
            ->groupBy(fn ($group) => trim($group->shop_name))
            ->filter(fn ($groups) => $groups->count() === 1 && str_contains((string) $groups->first()->owner, '刷单'))
            ->map(fn ($groups) => $groups->first()) : collect();
        $locks = $this->workbooks->database()->table('finance_period_locks')->whereNotNull('report_snapshot')->pluck('month')->all();

        return compact('accountModels', 'accounts', 'accountsById', 'storesById', 'domains', 'yeDomains', 'uniqueDomains', 'brushStores', 'locks');
    }

    /** Resolve derived ownership before pagination, without hydrating the entire ledger. */
    public function confluxBusinessQuery(array $filters): ?\Illuminate\Database\Eloquent\Builder
    {
        if (($filters['card_channel'] ?? null) !== 'ye'
            || ! collect($filters)->only(['team', 'teams', 'region', 'regions', 'domain'])->contains(fn ($value) => filled($value))
            || collect($filters)->only(['subscription', 'subscriptions', 'conditions', 'card_wallet', 'card_exceptions', 'card_match', 'ledger_settlement_type'])->contains(fn ($value) => filled($value))) return null;

        $query = $this->query('credit_card', $filters);
        $context = $this->rowContext('credit_card');
        $mysql = in_array($query->getConnection()->getDriverName(), ['mysql', 'mariadb'], true);
        // PHP business matching is case sensitive, including domain substring filters.
        $domain = $mysql ? \Illuminate\Support\Facades\DB::raw('BINARY finance_records.domain') : 'finance_records.domain';
        $dimensionsQuery = (clone $query)->toBase()->reorder()->selectRaw(($mysql ? 'BINARY ' : '').'finance_records.domain as domain')->distinct();
        $dimensionScope = 'conflux-business-domains:v1:'.hash('sha256', json_encode([
            $dimensionsQuery->toSql(), $dimensionsQuery->getBindings(),
        ], JSON_THROW_ON_ERROR));
        $dimensions = app(FinanceReportCache::class)->remember($dimensionScope, ['ye'], fn () => $dimensionsQuery->get()->pluck('domain')->all());
        $known = $matching = [];
        foreach ($dimensions as $value) {
            $key = FinanceYeDomains::normalize($value);
            $group = $context['yeDomains']->get($key);
            if ($key === '' || $group === null || $group->team === null) continue;
            $known[] = $value;
            $row = ['channel' => 'credit_card', 'team' => $group->team, 'domain' => $key];
            if ($this->matchesBusinessFilters($row, $filters) && FinanceFilterSelection::rowMatches($row,
                \Illuminate\Support\Arr::only($filters, ['teams', 'regions']))) $matching[] = $value;
        }
        $supplements = fn ($sub) => $sub->select('finance_record_id')->from('finance_settlement_supplements')->whereNotNull('finance_record_id');
        // Missing domains and manual overrides still use the canonical attribution rules.
        $uncertain = (clone $query)->where(fn ($scope) => $scope->whereNull('finance_records.domain')
            ->orWhereNotIn($domain, $known)->orWhereIn('finance_records.id', $supplements));
        $scope = 'conflux-business-keys:v1:'.hash('sha256', json_encode([
            $uncertain->toSql(), $uncertain->getBindings(), \Illuminate\Support\Arr::except($filters, ['per_page', 'format']), $matching,
        ], JSON_THROW_ON_ERROR));
        $ids = app(FinanceReportCache::class)->remember($scope, ['ye'], function () use ($uncertain, $filters, $context): array {
            $ids = [];
            foreach ($uncertain->reorder()->lazyById(500, 'finance_records.id', 'id')->chunk(500) as $batch) {
                $records = new \Illuminate\Database\Eloquent\Collection($batch->all());
                foreach ($this->rows('credit_card', $filters, $records, $context, businessMatchesOnly: true) as $row) $ids[] = $row['id'];
            }
            return $ids;
        });
        return $query->where(fn ($scope) => $scope->where(fn ($knownRows) => $knownRows->whereIn($domain, $matching)
            ->whereNotIn('finance_records.id', $supplements))->orWhereIntegerInRaw('finance_records.id', $ids));
    }

    public function rowBatches(string $channel, array $filters, bool $businessMatchesOnly = false, bool $walletMatchesOnly = false): iterable
    {
        $context = $this->rowContext($channel);
        $context['conflux_report_fees'] = new \ArrayObject;
        $query = $this->query($channel, $filters)->orderByDesc('occurred_at')->orderByDesc('id');
        if (($filters['card_channel'] ?? null) === 'ye'
            && in_array($query->getConnection()->getDriverName(), ['mysql', 'mariadb'], true)) {
            // Read each keyset batch in date order instead of sorting the entire matching ledger again.
            $query->forceIndex($query->getQuery()->from === 'finance_transactions as finance_records'
                ? 'finance_tx_channel_page_idx' : 'finance_records_occurred_at_index');
        }
        $batchSize = $walletMatchesOnly ? 1000 : 500;
        $last = null;
        do {
            $page = clone $query;
            if ($last !== null) {
                $lastOccurredAt = $last->getRawOriginal('occurred_at');
                $page->where(fn ($scope) => $scope->where('occurred_at', '<', $lastOccurredAt)
                    ->orWhere(fn ($tie) => $tie->where('occurred_at', $lastOccurredAt)->where('id', '<', $last->id)));
            }
            $records = $page->limit($batchSize)->get();
            if ($records->isEmpty()) {
                break;
            }
            $last = $records->last();
            yield $this->rows($channel, $filters, $records, $context, $businessMatchesOnly, $walletMatchesOnly);
        } while ($records->count() === $batchSize);
    }

    public function rows(string $channel, array $filters, ?Collection $records = null, ?array $context = null, bool $businessMatchesOnly = false, bool $walletMatchesOnly = false): Collection
    {
        $db = $this->workbooks->database();
        $records ??= $this->query($channel, $filters)->orderByDesc('occurred_at')->orderByDesc('id')->get();
        $supplements = $db->table('finance_settlement_supplements')->whereIntegerInRaw('finance_record_id', $records->modelKeys())->get()->keyBy('finance_record_id');
        ['accountModels' => $accountModels, 'accounts' => $accounts, 'accountsById' => $accountsById,
            'storesById' => $storesById, 'domains' => $domains, 'yeDomains' => $yeDomains, 'uniqueDomains' => $uniqueDomains, 'brushStores' => $brushStores, 'locks' => $locks] =
            $context ?? $this->rowContext($channel);
        $worldpay = ($filters['card_channel'] ?? null) === 'worldpay';
        $ye = ($filters['card_channel'] ?? null) === 'ye';
        if ($businessMatchesOnly && filled($filters['team'] ?? null)) {
            // Conflux uses the settlement domain for ownership even when it has a linked order.
            $records = $records->filter(function ($record) use ($supplements, $domains, $yeDomains, $ye, $filters): bool {
                $saved = isset($supplements[$record->id])
                    ? json_decode($supplements[$record->id]->payload, true, 512, JSON_THROW_ON_ERROR) : [];
                $edited = $saved['_edited_fields'] ?? [];
                if (array_key_exists('team', $edited) || filled($saved['team'] ?? null)) {
                    return (array_key_exists('team', $edited) ? $edited['team'] : $saved['team']) === $filters['team'];
                }
                $domain = $edited['domain'] ?? (array_key_exists('domain', $saved) ? $saved['domain'] : $record->domain);
                if (blank($domain)) {
                    // A linked logistics order can supply a missing domain.
                    return true;
                }
                $domain = $ye ? FinanceYeDomains::normalize($domain) : strtolower(trim((string) $domain));
                $group = $ye ? $yeDomains->get($domain)
                    : ($domains->get($domain) ?? (str_starts_with($domain, 'www.') ? $domains->get(substr($domain, 4)) : null));

                return ($group?->team ?? ($record->payload['团队'] ?? '')) === $filters['team'];
            });
        }
        if ($records->isEmpty()) {
            return collect();
        }
        $conflux = $channel === 'credit_card' && $ye ? app(FinanceConfluxSettlement::class) : null;
        $countFailuresOnly = ! empty($filters['summary_account_counts']);
        $amountRecords = $countFailuresOnly
            ? $records->reject(fn ($record) => in_array(strtoupper((string) $record->status), self::CARD_FAILURE_STATUSES, true)) : $records;
        $ledger = $businessMatchesOnly ? null : $conflux?->entriesFor($amountRecords, $accountModels->keyBy('activity_account'));
        if ($conflux && ! empty($filters['card_wallet'])) {
            $records = $records->filter(function (FinanceRecord $record) use ($conflux, $ledger, $supplements): bool {
                $saved = isset($supplements[$record->id])
                    ? json_decode($supplements[$record->id]->payload, true, 512, JSON_THROW_ON_ERROR) : [];
                $website = FinanceCreditSettlementLayout::confluxWebsiteName(
                    $record->payload, [...$saved, ...($saved['_edited_fields'] ?? [])],
                );

                return $conflux->isWallet($website, $ledger->get($record->id, collect()));
            });
            if ($records->isEmpty()) {
                return collect();
            }
            if ($walletMatchesOnly && ! filled($filters['team'] ?? null) && empty($filters['teams']) && empty($filters['regions']) && empty($filters['subscriptions'])
                && ! filled($filters['subscription'] ?? null) && ! filled($filters['domain'] ?? null)
                && empty($filters['card_match'])) {
                return $records->map(fn ($record) => ['id' => $record->id, 'subscription' => null])->values();
            }
        }
        $owners = $businessMatchesOnly ? collect() : $db->table('finance_payment_transactions')
            ->whereIntegerInRaw('finance_record_id', $records->modelKeys())->pluck('payment_account_id', 'finance_record_id');
        $metadata = $this->logisticsMetadata($records, $channel, withCustomReference: ! empty($filters['order_view']),
            summaryOnly: ! empty($filters['summary_only']), includeOrder: $worldpay || ($ye && empty($filters['summary_only'])));
        if ($channel === 'credit_card' && ! empty($filters['summary_only']) && ! $worldpay && ! $ye) {
            $imported = $records->where('dataset', FinanceLogisticsCreditOrders::IMPORTED_DATASET);
            if ($imported->isNotEmpty()) {
                $linked = app(FinanceXuzongCreditReport::class)->linkedOrders($imported);
                foreach ($imported as $record) {
                    unset($metadata[$record->id]);
                    if ($order = $linked->get($record->id)) {
                        $metadata[$record->id] = ['order' => $order, 'logistics_order_id' => $order->id,
                            'domain' => $order->report_domain ?? '', 'subscription' => $order->subscription_type ?? '',
                            'upsell' => $order->is_add_on ?? '', 'erp_order' => $order->tongtu_order_number ?? ''];
                    }
                }
            }
        }
        if ($worldpay) {
            $metadata += $this->worldpayFashionOrderMetadata($records->reject(fn ($record) => isset($metadata[$record->id])), $domains);
        }
        $candidateOrders = $channel === 'paypal' && ! empty($filters['order_view'])
            ? app(FinancePayPalOrderCandidates::class)->suggestions($records, $metadata) : [];
        if ($candidateOrders !== [] && ! empty($filters['match_candidate_domains'])) {
            $domainsByPrefix = $storesById->filter(fn ($store) => filled($store->domain))
                ->groupBy(fn ($store) => explode('.', strtolower(trim($store->domain)), 2)[0]);
            foreach ($candidateOrders as $recordId => $candidate) {
                $sourceDomain = strtolower(trim((string) ($candidate->source_shop_domain ?? '')));
                $store = $storesById->get($candidate->assistant_domain_store_id ?? null)
                    ?? $uniqueDomains->get($sourceDomain);
                if (blank($store?->domain) && $sourceDomain === ''
                    && preg_match('/^#?(.+)-\d+$/D', $candidate->tongtu_order_number, $parts)) {
                    $matches = $domainsByPrefix->get(strtolower($parts[1]));
                    $store = $matches?->count() === 1 ? $matches->first() : null;
                }
                if (filled($store?->domain)) {
                    $metadata[$recordId] = [
                        'domain' => $store->domain,
                        'erp_order' => $candidate->tongtu_order_number,
                        'order' => $candidate,
                    ];
                }
            }
        }
        $departmentMembers = $channel === 'paypal' && ! empty($filters['order_view']) && $records->isNotEmpty()
            ? $this->operationDepartmentMembers() : collect();
        $membersById = $departmentMembers->keyBy('id');
        $membersByName = $departmentMembers->groupBy(fn ($member) => array_unique(array_filter([$member->name, $member->username])));
        $confluxFees = null;
        $reportFees = $context['conflux_report_fees'] ?? new \ArrayObject;
        $usdRates = app(FinanceCreditUsdRates::class);
        $confluxOrders = $conflux ? $amountRecords : ($channel === 'credit_card' && empty($filters['card_channel']) && empty($filters['summary_only'])
            ? $records->filter(fn ($record) => ($record->payload['_card_channel'] ?? null) === 'ye') : collect());
        $confluxOrderIds = $confluxOrders->pluck('id')->flip();
        $creditUsdRates = $businessMatchesOnly || $walletMatchesOnly ? [] : $usdRates->forOrders($confluxOrders);
        $rows = $records->map(function ($record) use ($channel, $filters, $supplements, $accounts, $owners, $accountsById, $domains, $yeDomains, $uniqueDomains, $storesById, $brushStores, $locks, $metadata, $candidateOrders, $membersById, $membersByName, $conflux, $ledger, &$confluxFees, $reportFees, $usdRates, $confluxOrderIds, $creditUsdRates, $worldpay, $ye, $businessMatchesOnly, $walletMatchesOnly): ?array {
            $owner = $accountsById->get($owners->get($record->id));
            $p = $record->payload;
            $definition = FinanceCatalog::dataset($record->dataset);
            $headers = $definition['headers'];
            $value = static fn ($key) => $p[$headers[$definition[$key]]] ?? '';
            $reportTimezone = $filters['timezone'] ?? $p['_report_timezone'] ?? 'Asia/Shanghai';
            $occurredAt = $record->occurred_at;
            $date = $occurredAt->setTimezone($reportTimezone);
            $beijingDate = $reportTimezone === 'Asia/Shanghai' ? $date : $occurredAt->setTimezone('Asia/Shanghai');
            $row = ['id' => $record->id, 'channel' => $channel, 'source' => $record->dataset,
                'account_key' => $owner?->activity_account ?? $record->account,
                'account' => $owner?->account_name ?? $accounts->get($record->account, $record->account),
                'reference' => $record->reference, 'date' => isset($p['_manual_import_month']) ? '' : $date->format('Y-m-d H:i:s'), 'timezone' => $reportTimezone,
                'month' => $p['_manual_import_month'] ?? $date->format('Y-m'), 'status' => $record->status, 'currency' => $record->currency,
                'payment_method' => $p['支付方式'] ?? '',
                'gross' => $this->number($channel === 'paypal' ? ($p[$headers[7]] ?? null) : ($p['交易金额'] ?? null)),
                'locked' => in_array($beijingDate->format('Y-m'), $locks, true),
                'domain' => $record->domain ?? '', 'subscription' => $p['订阅类型'] ?? '', 'upsell' => $p['是否加购'] ?? '',
                'erp_order' => $p['通途订单'] ?? '', 'note' => $p['备注'] ?? '',
            ];
            foreach ($metadata[$record->id] ?? [] as $field => $value) {
                if (in_array($field, ['order', 'payment_reference_type'], true)) {
                    continue;
                }
                if ($field === 'logistics_order_id' && ! $worldpay && empty($filters['logistics_costs'])) {
                    continue;
                }
                if (blank($row[$field] ?? null) || ($channel === 'paypal' && isset($metadata[$record->id]['order'])
                    && in_array($field, ['domain', 'payment_method', 'erp_order'], true))) {
                    $row[$field] = $value;
                }
            }
            $paymentType = null;
            if ($channel === 'paypal') {
                $business = $metadata[$record->id] ?? [];
                $paymentType = $business['payment_reference_type'] ?? null;
                $orderUpsell = $business['upsell'] ?? '';
                $row['upsell'] = self::isUpsell($orderUpsell) ? '已加购'
                    : (isset($business['order']) ? $orderUpsell : ($orderUpsell ?: $row['upsell']));
                if ($paymentType === LogisticsOrderPaymentReference::TYPE_PRIMARY) {
                    $row['subscription'] = $business['subscription'];
                } elseif ($paymentType === LogisticsOrderPaymentReference::TYPE_UPSELL) {
                    $row['upsell'] = '已加购';
                } elseif (self::isUpsell($business['upsell'] ?? '')) {
                    // An order-level tag does not identify the payment's subscription type.
                    $row['subscription'] = $p['订阅类型'] ?? '';
                }
            }
            $aliases = ['usd_rate' => '汇率', 'fee' => $channel === 'paypal' ? '手续费' : '交易手续费', 'logistics' => '物流-元', 'purchase' => '采购成本-元',
                'per_order_fee' => '单笔费用', 'hold' => $channel === 'paypal' ? '冻结金额' : '保证金',
                'release' => $channel === 'paypal' ? '返还冻结' : '保证金返还', 'ethoca_refund' => 'ethoca预警退款',
                'ethoca_fee' => '拒付预警ethoca', 'rdr_refund' => '拒付RDR金额', 'rdr_fee' => '拒付RDR+CDRN费用'];
            $settlementOnly = ! empty($filters['summary_settlement_only']);
            $row += array_fill_keys(array_keys(self::MONEY), null);
            foreach ($settlementOnly ? array_intersect_key(self::MONEY, ['usd_rate' => true, 'converted_usd' => true]) : self::MONEY as $field => $label) {
                $row[$field] = $this->number(filled($p[$aliases[$field] ?? $label] ?? null) ? $p[$aliases[$field] ?? $label] : ($p[$label] ?? null));
            }
            if ($channel === 'paypal' && $row['fee'] === null) {
                $fee = $this->number($p[$headers[8]] ?? null);
                $row['fee'] = $fee === null ? null : bcmul($fee, '-1', 8);
            }
            $saved = isset($supplements[$record->id]) ? json_decode($supplements[$record->id]->payload, true, 512, JSON_THROW_ON_ERROR) : [];
            $row = [...$row, ...$saved];
            if ($channel !== 'paypal') {
                $row['subscription'] = self::isUpsell($row['upsell']) ? '加购' : self::subscriptionLabel($row['subscription']);
            }
            $row['usd_rate'] = $record->currency === 'USD' ? '1' : $row['usd_rate'];
            if (isset($saved['_edited_fields']['usd_rate'])) {
                $row['usd_rate'] = $saved['_edited_fields']['usd_rate'];
            }
            if ($channel === 'paypal') {
                if (empty($filters['summary_only'])) {
                    foreach (array_slice($headers, 0, 15) as $index => $header) {
                        $row['paypal_'.$index] = match ($index) {
                            0 => $date->toDateString(),
                            1 => $date->format('H:i:s'),
                            2 => $reportTimezone,
                            4 => FinancePayPalEventTypes::label((string) ($p[$header] ?? '')),
                            12 => filled($saved['paypal_12'] ?? null) ? $saved['paypal_12'] : ($p[$header] ?? ''),
                            default => $p[$header] ?? '',
                        };
                    }
                }
                $net = $this->number($p[$headers[9]] ?? null);
                if ($row['converted_usd'] === null && $net !== null && $row['usd_rate'] !== null) {
                    $row['converted_usd'] = bcmul($net, $row['usd_rate'], 8);
                }
                if ($row['converted_usd'] !== null && $net !== null && bccomp($net, '0', 8) !== 0 && $record->currency !== 'USD') {
                    $row['usd_rate'] = bcdiv($row['converted_usd'], $net, 8);
                }
            }
            $success = self::isSuccessfulTransaction($record->status);
            $failed = in_array(strtoupper((string) $record->status), self::TRANSACTION_STATUS_CODES['failed'], true);
            $row['success'] = $success;
            $row['failed'] = $failed;
            $isConflux = $conflux !== null || ($p['_card_channel'] ?? null) === 'ye';
            // The source-dollar column is distinct from the manually reconciled settlement.
            $row['source_settlement_usd'] = $channel === 'credit_card' && strtoupper(trim((string) $record->status)) === 'SUCCESS'
                && (! $isConflux || $record->currency === 'USD')
                ? $row['gross'] : null;
            $row['status'] = match (strtoupper((string) $record->status)) {
                'S', 'SUCCESS', 'COMPLETED' => '已完成', 'P', 'PENDING' => '待处理',
                'D', 'FAIL', 'FAILED', 'FAILURE', 'DECLINED' => '已失败', 'V', 'VOIDED' => '已撤销',
                default => FinanceCatalog::simplified((string) $record->status),
            };
            $row['settlement'] = $success && $row['gross'] !== null && $row['usd_rate'] !== null ? bcmul($row['gross'], $row['usd_rate'], 8) : null;
            $importedSettlement = $this->number($p[$channel === 'paypal' ? '结算金额-美元' : '结算金额'] ?? null);
            if ($success && $importedSettlement !== null) {
                $row['settlement'] = $importedSettlement;
            }
            $row['currency_warning'] = $channel === 'credit_card' && $record->currency !== 'USD'
                ? '交易币种为 '.$record->currency.'，请核对美元结算金额。' : '';
            if ($channel === 'credit_card' && array_key_exists('settlement', $saved)) {
                $row['settlement'] = $saved['settlement'];
            }
            if ($channel === 'paypal' && ! array_key_exists('fee', $saved) && $row['fee'] !== null) {
                $row['fee'] = $row['usd_rate'] === null ? null : bcmul($row['fee'], $row['usd_rate'], 8);
            }
            $matchedOrder = $metadata[$record->id]['order'] ?? null;
            $order = $ye ? null : $matchedOrder;
            if ($worldpay && $order !== null && filled($metadata[$record->id]['domain'])) {
                $row['domain'] = $saved['domain'] ?? $metadata[$record->id]['domain'];
            }
            $websiteStore = null;
            if ($worldpay && blank($row['domain']) && ! array_key_exists('domain', $saved)
                && ! array_key_exists('domain', $saved['_edited_fields'] ?? [])) {
                $url = trim((string) ($p['交易网址'] ?? ''));
                if ($url !== '') {
                    $host = parse_url(str_contains($url, '://') ? $url : 'https://'.ltrim($url, '/'), PHP_URL_HOST);
                    $websiteStore = $uniqueDomains->get(strtolower((string) $host));
                    $row['domain'] = $websiteStore?->domain ?? $row['domain'];
                }
            }
            $domain = strtolower(trim((string) ($saved['_edited_fields']['domain'] ?? $row['domain'])));
            if ($isConflux) {
                $domain = FinanceYeDomains::normalize($domain);
                $row['domain'] = $domain;
            }
            $orderStore = $storesById->get($order->assistant_domain_store_id ?? null);
            $group = $websiteStore ?? ($orderStore?->domain === $domain ? $orderStore : $domains->get($domain));
            if ($isConflux) {
                $group = $yeDomains->get($domain);
            }
            $ownership = $this->resolveOrderOwner($order, $orderStore, $group, $p);
            $ownerName = $worldpay && ! $ownership['usesOrderAssignment']
                ? (isset($order->owner_history_id)
                    ? ($order->historical_owner_name ?? '')
                    : ($order->assigned_owner_name ?? $order->operator_name ?? ''))
                : $ownership['ownerName'];
            $team = $worldpay && blank($ownership['team']) ? ($group?->team ?? $p['团队'] ?? '') : $ownership['team'];
            $row['owner'] = filled($saved['owner'] ?? null) ? $saved['owner'] : $ownerName;
            $row['team'] = filled($saved['team'] ?? null) ? $saved['team'] : $team;
            $row = [...$row, ...($saved['_edited_fields'] ?? [])];
            if ($isConflux) $row['domain'] = $domain;
            if ($conflux && (! $this->matchesBusinessFilters($row, $filters) || ! FinanceFilterSelection::rowMatches($row, $filters))) {
                return null;
            }
            if ($businessMatchesOnly) {
                if (! empty($filters['region_options_only'])) {
                    $region = self::operationRegion((string) $row['team']);
                    if ($channel === 'paypal') {
                        $brushGroup = $group ?? (blank($row['domain']) ? $brushStores->get(trim((string) ($p['自定义编号'] ?? ''))) : null);
                        $region = $row['subscription'] === '刷单' || str_contains((string) $row['owner'], '刷单') || $this->brushOrderOwner($brushGroup) !== null
                            ? '刷单' : self::operationRegion($this->departmentForOrderOwner($order, $ownership, (string) $row['owner'], $membersById, $membersByName));
                    } elseif ($worldpay && $row['failed'] && ! array_key_exists('team', $saved['_edited_fields'] ?? [])) $region = '';
                    return ['id' => $row['id'], 'region' => $region];
                }
                return array_intersect_key($row, ['id' => true, 'subscription' => true]);
            }
            if ($channel === 'paypal') {
                $manualUpsell = $saved['_edited_fields']['upsell'] ?? $saved['upsell'] ?? null;
                $isUpsellPayment = $manualUpsell !== null ? self::isUpsell($manualUpsell)
                    : ($paymentType === LogisticsOrderPaymentReference::TYPE_UPSELL
                        || ($paymentType === null && self::isUpsell($p['是否加购'] ?? '')));
                $row['subscription'] = $isUpsellPayment ? '加购' : self::subscriptionLabel($row['subscription']);
                $domainGroup = $group;
                if (blank($row['domain'])) {
                    $domainGroup = $brushStores->get(trim((string) ($p['自定义编号'] ?? '')));
                    $row['domain'] = $domainGroup?->domain ?? $row['domain'];
                }
                if (($brushOwner = $this->brushOrderOwner($domainGroup)) !== null) {
                    $row['subscription'] = $row['team'] = '刷单';
                    $row['owner'] = $brushOwner;
                }
            }
            $row['locked'] = $row['locked'] || in_array($row['month'], $locks, true);
            if (! empty($filters['summary_account_counts']) && $row['failed'] && ! $row['success']) {
                // Failed orders contribute counts, never settlement amounts, on
                // the default account overview. Retain the same filter dimensions
                // without calculating their ledger fees or detail columns.
                $manual = [...$saved, ...($saved['_edited_fields'] ?? [])];
                if ($channel === 'credit_card') {
                    if (array_key_exists('owner', $manual)) $row['owner'] = $manual['owner'];
                    elseif ($ye) $row['owner'] = filled($p['使用人'] ?? null) ? $p['使用人']
                        : (filled($p['使用人匹配'] ?? null) ? $p['使用人匹配'] : $row['owner']);
                    if ($worldpay) $row['team'] = '';
                }
                $row['settlement'] = null;
                return $row;
            }
            if (! empty($filters['order_view'])) {
                $row['operation_department'] = $this->departmentForOrderOwner(
                    $order, $ownership, (string) $row['owner'], $membersById, $membersByName,
                );
                foreach (array_slice($headers, 15, null, true) as $index => $header) {
                    if (filled($p[$header] ?? null)) {
                        $row['paypal_'.$index] = $header === '物品标题'
                            ? FinanceProductNames::display((string) $p[$header]) : $p[$header];
                    }
                }
                $row['paypal_18'] ??= FinanceProductNames::display($metadata[$record->id]['order']->tongtu_product_name ?? '');
                $row['source_added_date'] = $p['新增日期'] ?? '';
                $row['business_order_id'] = $metadata[$record->id]['logistics_order_id'] ?? null;
                $row['candidate_order'] = $candidateOrders[$record->id]->tongtu_order_number ?? null;
                $row['candidate_domain_matched'] = isset($candidateOrders[$record->id], $metadata[$record->id]);
                $row['shopify_order_number'] = $metadata[$record->id]['order']->shopify_order_number ?? '';
                $row['source_account_key'] = $owner?->activity_account ?? $record->account;
                $row['source_date'] = $occurredAt;
                $keys = [...array_keys(self::MONEY), ...array_values($this->importFields('paypal')), '结算金额-美元', 'settlement'];
                $row['manual_values'] = [
                    ...array_intersect_key($p, array_flip($keys)), ...array_intersect_key($saved, array_flip($keys)),
                    ...array_intersect_key($saved['_edited_fields'] ?? [], array_flip($keys)),
                ];
                $row['editor_values'] = $saved['_edited_fields'] ?? [];
            }

            if (! $walletMatchesOnly && $confluxOrderIds->has($record->id) && $row['gross'] !== null && filled($row['currency']) && ! isset($p['_manual_import_month'])) {
                $tradeDate = $beijingDate->toDateString();
                $row['source_settlement_usd'] = $saved['_edited_fields']['source_settlement_usd'] ?? $saved['source_settlement_usd']
                    ?? ($ye ? $this->number($p['结算-美元'] ?? null) : null)
                    ?? $usdRates->convert($creditUsdRates, $row['currency'], $tradeDate, $row['gross']);
            }
            if ($channel === 'credit_card' && filled($filters['card_channel'] ?? null)) {
                $manual = [...$saved, ...($saved['_edited_fields'] ?? [])];
                $row['card_layout'] = FinanceCreditSettlementLayout::values(
                    $filters['card_channel'], $row, $p, $manual, $record->source_timezone ?: 'Asia/Shanghai',
                    summaryOnly: ! empty($filters['summary_only']),
                    settlementOnly: $settlementOnly,
                );
                if ($worldpay && ! array_key_exists('owner', $manual)) {
                    $row['card_layout']['owner'] = $row['owner'];
                }
                if ($worldpay && $order !== null) {
                    $builder = trim((string) ($group->site_builder ?? ''));
                    $product = trim((string) ($order->tongtu_product_name ?? ''));
                    foreach (['store_platform' => strcasecmp($builder, 'xshoppy') === 0 ? '索引' : $builder,
                        'product_name' => FinanceProductNames::worldpayShortName($product)] as $field => $value) {
                        if (filled($value) && blank($row['card_layout'][$field]) && ! array_key_exists($field, $manual)) {
                            $row['card_layout'][$field] = $value;
                        }
                    }
                }
                if ($worldpay || $conflux !== null) {
                    $row['card_layout']['operation_region'] = self::operationRegion((string) $row['team']);
                }
                if ($worldpay && $row['failed'] && ! array_key_exists('team', $saved['_edited_fields'] ?? [])) {
                    $row['team'] = '';
                    $row['card_layout']['team'] = '';
                    $row['card_layout']['operation_region'] = '';
                }
                if (isset($tradeDate)) {
                    $row['card_layout']['source_settlement_usd'] = $row['source_settlement_usd'];
                    $row['card_layout']['calendar_date'] = $tradeDate;
                }
                $entries = $conflux ? $ledger->get($record->id, collect()) : null;
                $wallet = $conflux?->isWallet($row['card_layout']['website_name'] ?? null, $entries);
                if (! empty($filters['card_wallet']) && $conflux && ! $wallet) {
                    return null;
                }
                if ($walletMatchesOnly) {
                    return array_intersect_key($row, ['id' => true, 'account_key' => true, 'team' => true, 'domain' => true, 'subscription' => true])
                        + ['ledger_wallet' => $wallet, 'ledger_matched' => $ledger->has($record->id)];
                }
                if ($ledger?->has($record->id)) {
                    $fees = ! empty($filters['card_wallet'])
                        ? $conflux->feesFor(collect([$entries]), $reportFees)
                        : ($confluxFees ??= $conflux->feesFor($ledger, $reportFees));
                    $details = $conflux->details($entries, $fees);
                    $existingFees = array_intersect_key(array_filter($row['card_layout'], fn ($value) => filled($value)),
                        array_flip(['hold', 'fee', 'per_order_fee', 'refund_fee', 'chargeback_fee', 'ethoca_fee', 'rdr_fee']));
                    $row['card_layout'] = array_replace($row['card_layout'], array_diff_key($details['values'], $manual, $existingFees), [
                        'ledger_dates' => $details['dates'], 'ledger_settlement_type' => $details['settlement_types'],
                        'ledger_exception_dates' => $details['exception_dates'], 'ledger_exceptions' => implode('；', $details['reasons']),
                    ]);
                    if ($details['reasons'] === [] && isset($details['values']['settlement_currency'])
                        && ! filled($row['card_layout']['payable'] ?? null)) {
                        $values = array_map($this->number(...), array_intersect_key($row['card_layout'], self::MONEY + ['settlement' => true]));
                        $values['settlement_currency'] = $details['values']['settlement_currency'];
                        $row['card_layout']['payable'] = $conflux->payable($entries, $values);
                    }
                }
                if ($conflux) {
                    if (filled($saved['_ye_settlement_type'] ?? null)) {
                        $row['card_layout']['ledger_settlement_type'] = $saved['_ye_settlement_type'];
                    }
                    $layout = $conflux->storeFees($row['card_layout'], $ledger->get($record->id, collect()), $manual);
                    // Simple bills contribute deltas; never freeze the official ledger's totals.
                    foreach ($saved['_ye_bill_deltas'] ?? [] as $field => $delta) {
                        if (array_key_exists($field, $saved['_edited_fields'] ?? [])) continue;
                        $layout[$field] = bcadd($this->number($layout[$field] ?? null) ?? '0', $delta, 8);
                        if (! array_key_exists('payable', $manual) && $this->number($layout['payable'] ?? null) !== null) {
                            if ($field === 'release') {
                                $layout['payable'] = bcadd($layout['payable'], $delta, 8);
                            } elseif (in_array($field, ['refund', 'refund_fee', 'chargeback', 'chargeback_fee',
                                'ethoca_refund', 'ethoca_fee', 'rdr_refund', 'rdr_fee'], true)) {
                                $layout['payable'] = bcsub($layout['payable'], $delta, 8);
                            }
                        }
                    }
                    $builder = trim((string) ($group->site_builder ?? ''));
                    $platform = strcasecmp($builder, 'xshoppy') === 0 ? '索引' : ($builder === '' ? null : $builder);
                    foreach (['store_platform' => $platform, 'project' => $group->project ?? null] as $field => $value) {
                        if (! array_key_exists($field, $manual) && blank($layout[$field] ?? null)) {
                            $layout[$field] = $value;
                        }
                    }
                    $row['ledger_wallet'] = $wallet;
                    $row['card_layout'] = array_replace($layout, $conflux->exceptionColumns($layout, $entries, $row['ledger_wallet']));
                    $row['ledger_matched'] = $ledger->has($record->id) || filled($saved['_ye_settlement_type'] ?? null);
                    $row['card_layout']['ledger_status'] = $row['ledger_matched'] ? '已匹配账单' : '待匹配账单';
                }
                $displayEdits = $saved['_edited_fields'] ?? [];
                if (array_key_exists('completed_at', $displayEdits)) {
                    $displayEdits['completed_at'] = FinanceCreditSettlementLayout::reportTimestamp(
                        $displayEdits['completed_at'], $record->source_timezone ?: 'Asia/Shanghai', $row['timezone'],
                    );
                }
                $row['card_layout'] = array_replace($row['card_layout'], $displayEdits);
                if (strcasecmp(trim((string) ($row['card_layout']['store_platform'] ?? '')), 'shopyy') === 0) {
                    $row['card_layout']['store_platform'] = '索引';
                }
                if (isset($row['card_layout']['project'])) {
                    $row['card_layout']['project'] = preg_replace('/项目$/u', '', trim((string) $row['card_layout']['project']));
                }
                if ($isConflux) $row['card_layout']['domain'] = $row['domain'];
                $row['card_layout']['operation_region'] = self::normaliseRegionLabel((string) ($row['card_layout']['operation_region'] ?? ''));
            }

            if (empty($filters['summary_only'])) {
                $shopPaid = $matchedOrder->paid_amount_usd ?? null;
                if ($channel === 'paypal') {
                    $row['shop_paid_usd'] = $shopPaid;
                } else {
                    $layout = $row['card_layout'] ?? [];
                    $layoutCurrency = strtoupper(trim((string) ($worldpay
                        ? ($layout['statement_currency'] ?? '') : ($layout['settlement_currency'] ?? ''))));
                    $channelAmount = ($layoutCurrency === 'USD' || (! $isConflux && $layoutCurrency === ''))
                        ? $this->number($layout['settlement'] ?? null) : null;
                    $comparisonAmount = match (true) {
                        $worldpay => $success && ($layoutCurrency === 'USD' || ($layoutCurrency === '' && $row['currency'] === 'USD'))
                            ? $channelAmount : null,
                        $ye => $this->number($saved['_edited_fields']['source_settlement_usd'] ?? $saved['source_settlement_usd'] ?? $p['结算-美元'] ?? null)
                            ?? $this->number($layout['source_settlement_usd'] ?? null) ?? $channelAmount,
                        default => $channelAmount ?? $row['source_settlement_usd'] ?? ($isConflux ? null : $row['settlement']),
                    };
                    $row['shop_difference_usd'] = $this->shopDifference($comparisonAmount, $shopPaid);
                    if (isset($row['card_layout'])) {
                        $row['card_layout']['shop_difference_usd'] = $row['shop_difference_usd'];
                    }
                }
            }

            if ($channel === 'paypal') {
                // Business edits were applied before classification. Do not undo brush-order
                // attribution when restoring manually edited monetary values after calculation.
                $row = array_replace($row, array_diff_key($saved['_edited_fields'] ?? [],
                    array_flip(['domain', 'owner', 'team', 'subscription', 'upsell'])));
            }
            if ($channel === 'paypal') {
                $row['product_name'] = $row['success']
                    ? FinanceProductNames::shortNameForOrder($order, (string) ($p['物品标题'] ?? '')) : '';
            } elseif ($ye || $worldpay) {
                if (! ($worldpay && array_key_exists('product_name', $manual))) {
                    $row['card_layout']['product_name'] = $row['success']
                        ? (filled($row['card_layout']['product_name'] ?? null) ? $row['card_layout']['product_name']
                            : FinanceProductNames::shortNameForOrder($matchedOrder)) : '';
                }
            }
            return $row;
        })->filter();
        if ($businessMatchesOnly) {
            return $rows;
        }
        $rows = $rows->map(fn ($row) => $row + ['_summary_team' => $row['team']]);
        return $rows->filter(fn ($row) => $this->matchesBusinessFilters($row, $filters)
            && FinanceFilterSelection::rowMatches($row, $filters)
            && (! filled($filters['region'] ?? null) || ($row['card_layout']['operation_region'] ?? self::operationRegion((string) $row['team'])) === $filters['region'])
            && (empty($filters['card_exceptions']) || filled($row['card_layout']['ledger_exceptions'] ?? null))
            && (empty($filters['card_wallet']) || ! empty($row['ledger_wallet']))
            && (empty($filters['card_match']) || ($row['ledger_matched'] ?? false) === ($filters['card_match'] === 'matched'))
            && match ($filters['ledger_settlement_type'] ?? '') {
                '' => true,
                'waiting' => ! ($row['ledger_matched'] ?? false),
                default => in_array($filters['ledger_settlement_type'], explode('、', $row['card_layout']['ledger_settlement_type'] ?? ''), true),
            }
            && $this->matches(array_replace($row, $row['card_layout'] ?? []), $filters['conditions'] ?? []))->values();
    }

    private function matchesBusinessFilters(array $row, array $filters): bool
    {
        return (! filled($filters['team'] ?? null) || $row['team'] === $filters['team'])
            && (! filled($filters['region'] ?? null) || ($row['channel'] ?? 'credit_card') !== 'credit_card' || self::operationRegion((string) $row['team']) === $filters['region'])
            && (! filled($filters['subscription'] ?? null) || $row['subscription'] === self::subscriptionLabel($filters['subscription']))
            && (! filled($filters['domain'] ?? null) || str_contains((string) $row['domain'], $filters['domain']));
    }

    public function matches(array $row, array $conditions, ?array $numericFields = null): bool
    {
        foreach ($conditions as $condition) {
            $actual = $row[$condition['field']] ?? null;
            $expected = $condition['value'] ?? '';
            $operator = $condition['operator'];
            $empty = $actual === null || $actual === '';
            $canCompareNumbers = $numericFields === null || in_array($condition['field'], $numericFields, true);
            $actualNumber = $canCompareNumbers ? $this->number($actual) : null;
            $expectedNumber = $canCompareNumbers ? $this->number($expected) : null;
            $numeric = $actualNumber !== null && $expectedNumber !== null;
            $comparison = $numeric ? bccomp($actualNumber, $expectedNumber, 8) : strcmp((string) $actual, $expected);
            $match = match ($operator) {
                'empty' => $empty, 'not_empty' => ! $empty,
                'contains' => mb_stripos(FinanceCatalog::simplified((string) $actual), FinanceCatalog::simplified($expected)) !== false,
                'not_equals' => ! $empty && $comparison !== 0,
                'gt' => ! $empty && $numeric && $comparison > 0, 'gte' => ! $empty && $numeric && $comparison >= 0,
                'lt' => ! $empty && $numeric && $comparison < 0, 'lte' => ! $empty && $numeric && $comparison <= 0,
                default => ! $empty && $comparison === 0,
            };
            if (! $match) {
                return false;
            }
        }

        return true;
    }

    private function resolveOrderOwner(?object $order, ?object $orderStore, ?object $group, array $payload): array
    {
        $inactiveOrderStore = in_array($orderStore->shop_status ?? null, [
            AssistantDomainStore::SHOP_STATUS_ABANDONED, AssistantDomainStore::SHOP_STATUS_STOPPED,
            'closed', 'idle', 'banned',
        ], true);
        $ownerName = $group?->assigned_owner ?? $group?->owner ?? ($payload['使用人'] ?? '');
        $ownerId = $group?->assigned_owner_user_id ?? null;
        $team = $group?->team ?? ($payload['团队'] ?? '');
        $usesLegacyOperator = false;
        $emptyBaseline = false;
        $usesOrderAssignment = $order !== null && filled($order->owner_assignment_resolved_at ?? null);
        if ($usesOrderAssignment) {
            // Logistics has already resolved this order's attribution. Read its
            // latest values, including an explicit clear, rather than resolving
            // the same history again and overwriting a later correction.
            $ownerName = $order->assigned_owner_name ?? '';
            $ownerId = $order->assigned_owner_user_id ?? null;
            $team = FinanceCatalog::teamLabel($order->group_names ?? null);
            return compact('ownerName', 'ownerId', 'team', 'inactiveOrderStore', 'usesLegacyOperator', 'emptyBaseline', 'usesOrderAssignment');
        }
        if ($order !== null) {
            if (isset($order->owner_history_id)) {
                $ownerName = $order->historical_owner_name ?? '';
                $ownerId = $order->historical_owner_user_id;
            } elseif (filled($order->assigned_owner_name ?? null)) {
                $ownerName = $order->assigned_owner_name;
                $ownerId = $order->assigned_owner_user_id ?? null;
            } elseif (property_exists($order, 'assigned_owner_name')) {
                $ownerName = $orderStore?->assigned_owner ?? '';
                $ownerId = $orderStore?->assigned_owner_user_id ?? null;
            }
            if ($inactiveOrderStore && ! isset($order->owner_history_id) && blank($ownerName)) {
                $ownerName = trim((string) ($order->operator_name ?? ''));
            }
            $emptyBaseline = blank($ownerName) && $ownerId === null
                && ($order->historical_owner_event ?? null) === AssistantDomainStoreOwnerHistory::EVENT_BASELINE;
            if ($emptyBaseline && filled($order->assigned_owner_name ?? null)) {
                $ownerName = $order->assigned_owner_name;
                $ownerId = $order->assigned_owner_user_id ?? null;
            }
            $legacyOperator = trim((string) ($order->operator_name ?? ''));
            // An empty initial record can coexist with the older order and store operator fields.
            if (blank($ownerName) && $ownerId === null && $legacyOperator !== ''
                && $legacyOperator === trim((string) ($orderStore->owner ?? ''))
                && (! isset($order->owner_history_id)
                    || $order->historical_owner_event === AssistantDomainStoreOwnerHistory::EVENT_BASELINE)) {
                $ownerName = $legacyOperator;
                $usesLegacyOperator = true;
            }
            if ($emptyBaseline && blank($ownerName) && $ownerId === null) {
                // The initial history row can precede the first recorded owner.
                $ownerName = $order->initial_owner_name ?? '';
                $ownerId = $order->initial_owner_user_id ?? null;
            }
            if ($emptyBaseline && blank($ownerName) && $ownerId === null) {
                $ownerName = $orderStore?->owner ?: ($group?->owner ?? '');
            }
            if (property_exists($order, 'group_names') && (! $emptyBaseline || filled($order->group_names))) {
                $team = FinanceCatalog::teamLabel($order->group_names);
            }
        }

        return compact('ownerName', 'ownerId', 'team', 'inactiveOrderStore', 'usesLegacyOperator', 'emptyBaseline', 'usesOrderAssignment');
    }

    private function departmentForOrderOwner(?object $order, array $ownership, string $owner, Collection $membersById, Collection $membersByName): string
    {
        ['ownerName' => $ownerName, 'ownerId' => $ownerId, 'inactiveOrderStore' => $inactiveOrderStore, 'usesLegacyOperator' => $usesLegacyOperator] = $ownership;
        $displayedOwner = trim($owner);
        $displayedOwnerId = $displayedOwner !== '' && $displayedOwner === trim((string) $ownerName) ? $ownerId : null;
        $nameMatches = $membersByName->get($displayedOwner);
        $member = $displayedOwnerId !== null
            ? $membersById->get($displayedOwnerId)
            : ($nameMatches?->count() === 1 ? $nameMatches->first() : null);
        $department = $member?->operation_department ?? '';
        if ($department === '' && ! empty($ownership['usesOrderAssignment'])) {
            // A logistics team is meaningful even when the order has no named
            // owner, or that owner no longer has a current department record.
            $department = $ownership['team'];
        }
        if ($member === null && ($inactiveOrderStore || $usesLegacyOperator) && $displayedOwner !== '') {
            // Keep the recorded team when it belongs to the operator shown on the settlement.
            $snapshotOwner = trim((string) (($order->assigned_owner_name ?? null) ?: ($order->operator_name ?? '')));
            if ($displayedOwner === $snapshotOwner
                || ($displayedOwnerId !== null && (int) $displayedOwnerId === (int) ($order->assigned_owner_user_id ?? 0))) {
                $department = FinanceCatalog::teamLabel($order->group_names ?? null);
            }
        }
        if ($department === '' && $ownership['emptyBaseline'] && $displayedOwner === trim((string) $ownerName)) {
            $department = $ownership['team'];
        }

        return $department;
    }

    public static function operationRegion(string $department): string
    {
        // Subscription describes the business, including in legacy department names.
        $department = trim(str_replace(['订阅', '訂閱'], '', $department));
        if ($department === '刷单') {
            return $department;
        }

        // City names may appear anywhere in a department or its hierarchy label.
        $cities = '厦门|深圳|郑州|西安|北京|上海|天津|重庆|杭州|广州|南京|苏州|成都|武汉|长沙|合肥|福州|泉州|漳州|宁波|温州|金华|义乌|绍兴|嘉兴|无锡|常州|南通|东莞|佛山|珠海|中山|惠州|济南|青岛|烟台|大连|沈阳|长春|哈尔滨|石家庄|太原|南昌|南宁|海口|贵阳|昆明|兰州|西宁|银川|乌鲁木齐|呼和浩特|拉萨|香港|澳门|台北';
        preg_match_all('/'.$cities.'/u', $department, $matches);
        $regions = $matches[0];
        // Retain support for other explicitly named cities, such as 杭州市运营部.
        foreach (preg_split('/[、,，\/／>＞|｜·—\s()（）]+/u', $department, -1, PREG_SPLIT_NO_EMPTY) as $name) {
            if (preg_match('/'.$cities.'/u', $name)) {
                continue;
            }
            $name = preg_replace('/^(?:(?:订阅|独立站|跨境|电商|运营|业务|事业部|总部)[-：:]*)+/u', '', $name);
            if (preg_match('/^(\p{Han}{2,8}?)市(?=$|运营|团队|分公司|分部|[一二三四五六七八九十0-9]+部)/u', $name, $city)) {
                $regions[] = $city[1];
            }
        }
        $regions = array_values(array_unique($regions));

        if ($regions === []) {
            // Non-geographic departments use their maintained team name, so
            // newly added teams do not require another hard-coded alias.
            foreach (preg_split('/[、,，\/／>＞|｜]+/u', $department, -1, PREG_SPLIT_NO_EMPTY) as $name) {
                $name = trim($name);
                $name = preg_replace('/(?:运营部门|运营部|事业部|部门|团队|总部|分公司|分部|组|部)+$/u', '', $name);
                $name = trim($name);
                if (strcasecmp($name, 'TK') === 0) $name = '王总';
                if ($name !== '' && ! in_array($name, ['未分组', '未分配', '未归属', '未匹配', '未知', '无', '—', '-'], true)) {
                    $regions[] = $name;
                }
            }
            $regions = array_values(array_unique($regions));
        }

        return count($regions) === 1 ? $regions[0] : '';
    }

    public static function normaliseRegionLabel(string $region): string
    {
        return str_contains($region, '订阅') || str_contains($region, '訂閱') ? self::operationRegion($region) : $region;
    }

    public function regionOptions(string $report = 'paypal-settlement'): Collection
    {
        $channel = $report === 'paypal-settlement' ? 'paypal' : 'credit_card';
        $cacheChannels = $report === 'xuzong-credit' ? ['xuzong1', 'xuzong2'] : [FinanceCreditSettlementLayout::REPORT_CHANNELS[$report] ?? $channel];
        return collect(app(FinanceReportCache::class)->remember('active-region-options:v3:'.$report, $cacheChannels, function () use ($report, $channel): array {
            $regions = [];
            if ($report === 'xuzong-credit') {
                $reportService = app(FinanceXuzongCreditReport::class);
                foreach (app(FinanceLogisticsCreditOrders::class)->query(xuzongReport: true)->reorder('id')->lazyById(300)->chunk(300) as $batch) {
                    $records = new \Illuminate\Database\Eloquent\Collection($batch->all());
                    foreach ($reportService->regionsForRecords($records) as $region) if (filled($region)) $regions[$region] = true;
                }
            } else {
                $filters = ['card_channel' => FinanceCreditSettlementLayout::REPORT_CHANNELS[$report] ?? null, 'region_options_only' => true, 'order_view' => $channel === 'paypal', '_legacy_source' => true];
                $query = $this->query($channel, $filters);
                $context = $this->rowContext($channel);
                if ($filters['card_channel'] === 'ye') {
                    // Attribution uses distinct domain/team dimensions; no ledger calculation is needed.
                    $dimensions = (clone $query)->reorder()->leftJoin('finance_settlement_supplements as region_supp', 'region_supp.finance_record_id', '=', 'finance_records.id')
                        ->distinct()->get(['finance_records.domain', 'finance_records.payload->团队 as source_team',
                            'region_supp.payload->domain as saved_domain', 'region_supp.payload->team as saved_team',
                            'region_supp.payload->_edited_fields->domain as edited_domain', 'region_supp.payload->_edited_fields->team as edited_team']);
                    foreach ($dimensions as $dimension) {
                        $domain = FinanceYeDomains::normalize($dimension->edited_domain ?? $dimension->saved_domain ?? $dimension->domain);
                        $group = $context['yeDomains']->get($domain);
                        $team = $dimension->edited_team ?? (filled($dimension->saved_team) ? $dimension->saved_team : ($group?->team ?? $dimension->source_team ?? ''));
                        if (($region = self::operationRegion((string) $team)) !== '') $regions[$region] = true;
                    }
                    $query->where(fn ($scope) => $scope->whereNull('finance_records.domain')->orWhere('finance_records.domain', ''));
                }
                foreach ($query->reorder('finance_records.id')->lazyById(500)->chunk(500) as $batch) {
                    $records = new \Illuminate\Database\Eloquent\Collection($batch->all());
                    foreach ($this->rows($channel, $filters, $records, $context, businessMatchesOnly: true) as $row) {
                        if (filled($row['region'])) $regions[$row['region']] = true;
                    }
                }
            }
            $values = array_keys($regions);
            sort($values, SORT_STRING);
            return $values;
        }))->map(fn ($region) => self::normaliseRegionLabel((string) $region))
            ->filter(fn ($region) => $region !== '')->unique()->sort()->values();
    }

    private function brushOrderOwner(?object $group): ?string
    {
        if (str_contains((string) $group?->owner, '刷单')) {
            return $group->owner;
        }

        return str_contains((string) $group?->team, '刷单') ? '刷单' : null;
    }

    public function liveOrderAttributionResolver(): \Closure
    {
        $groups = $this->workbooks->domainGroups(withAssignedOwner: true);
        $stores = $groups->keyBy('id');
        $domains = $groups->groupBy('domain')->filter(fn ($matches) => $matches->count() === 1)->map(fn ($matches) => $matches->first());
        $members = $this->operationDepartmentMembers();
        $membersById = $members->keyBy('id');
        $membersByName = $members->groupBy(fn ($member) => array_unique([$member->name, $member->username]));
        $departmentNames = $this->operationDepartments()->pluck('name')->unique();
        $departmentKey = static fn (string $name): string => preg_replace('/(?:运营部门|运营部|总部|部门|团队)$/u', '', trim($name));
        $departmentAliases = $departmentNames->groupBy($departmentKey)
            ->filter(fn ($names) => $names->count() === 1)->map(fn ($names) => $names->first());
        $resolveDepartment = static function (string $name) use ($departmentNames, $departmentKey, $departmentAliases): string {
            if ($name === '刷单' || $departmentNames->containsStrict($name)) {
                return $name;
            }

            return $departmentAliases->get($departmentKey($name), '');
        };

        return function (FinanceRecord $record, ?object $order) use ($stores, $domains, $membersById, $membersByName, $resolveDepartment): array {
            $domain = strtolower(trim((string) $record->domain));
            $orderStore = $stores->get($order->assistant_domain_store_id ?? null);
            $group = $orderStore?->domain === $domain ? $orderStore : $domains->get($domain);
            if (($brushOwner = $this->brushOrderOwner($group)) !== null) {
                return ['owner' => $brushOwner, 'department' => '刷单'];
            }
            $ownership = $this->resolveOrderOwner($order, $orderStore, $group, $record->payload);
            $owner = (string) $ownership['ownerName'];
            $department = str_contains($owner, '刷单') ? '刷单'
                : $this->departmentForOrderOwner($order, $ownership, $owner, $membersById, $membersByName);
            $department = $resolveDepartment($department)
                ?: $resolveDepartment($ownership['team'])
                ?: $resolveDepartment($group?->team ?? '')
                ?: trim((string) ($group?->team ?? ''));

            return [
                // The report's usage label can come from the store profile even when its formal owner was cleared.
                'owner' => filled($owner) ? $owner : ($group?->owner ?? ''),
                'department' => $department,
            ];
        };
    }

    /** Credit order IDs already refer to logistics orders, so no payment-reference matching is needed. */
    public function liveCreditReportOrders(Collection $ids): Collection
    {
        if ($ids->isEmpty()) {
            return collect();
        }

        $db = $this->workbooks->database();
        $schema = $db->getSchemaBuilder();
        if (! $schema->hasTable('logistics_orders')) {
            return collect();
        }
        $columns = $schema->getColumnListing('logistics_orders');
        $selected = array_intersect(['id', 'transaction_id', 'payment_gateway_order_id', 'bill_number', 'buyer_email', 'order_created_at', 'tongtu_order_number', 'shopify_payload', 'paid_amount_usd',
            'assistant_domain_store_id', 'assigned_owner_name', 'assigned_owner_user_id', 'owner_assignment_resolved_at', 'operator_name', 'group_names', 'subscription_type', 'is_add_on', 'tongtu_product_name'], $columns);
        $query = $db->table('logistics_orders')->whereIntegerInRaw('logistics_orders.id', $ids->all())
            ->select(array_map(fn ($column) => 'logistics_orders.'.$column, $selected));
        $domain = in_array('source_shop_domain', $columns, true) ? "NULLIF(logistics_orders.source_shop_domain, '')" : 'NULL';
        if (in_array('assistant_domain_store_id', $selected, true) && $schema->hasTable('assistant_domain_stores')) {
            $query->leftJoin('assistant_domain_stores as report_store', 'report_store.id', '=', 'logistics_orders.assistant_domain_store_id');
            $domain = "COALESCE(NULLIF(report_store.domain, ''), {$domain})";
        }
        $query->selectRaw($domain.' as report_domain');
        $this->joinOrderOwnerHistory($query, $selected);

        return $query->get()->keyBy('id');
    }

    private function joinOrderOwnerHistory(\Illuminate\Database\Query\Builder $orderQuery, array $selected, string $orderTable = 'logistics_orders', string $timeColumn = 'order_created_at', bool $includeBeforeHistory = true): void
    {
        $db = $orderQuery->getConnection();
        if (in_array($timeColumn, $selected, true)
            && in_array('assistant_domain_store_id', $selected, true)
            && $db->getSchemaBuilder()->hasTable('assistant_domain_store_owner_histories')
        ) {
            $orderTime = $orderTable.'.'.$timeColumn;
            if ($timeColumn === 'order_created_at_utc' && in_array('order_created_at', $selected, true)) {
                // Legacy fashion orders saved their creation time in Beijing time only.
                $legacyTime = $orderTable.'.order_created_at';
                $legacyUtc = $db->getDriverName() === 'sqlite'
                    ? "datetime({$legacyTime}, '-8 hours')"
                    : "DATE_SUB({$legacyTime}, INTERVAL 8 HOUR)";
                $orderTime = $db->raw("COALESCE({$orderTime}, {$legacyUtc})");
            }
            $historyId = $db->table('assistant_domain_store_owner_histories')
                ->select('id')
                ->whereColumn('assistant_domain_store_id', $orderTable.'.assistant_domain_store_id')
                ->whereNotNull($orderTime)
                ->where(function ($query) use ($db, $orderTable, $orderTime, $includeBeforeHistory): void {
                    $query->whereColumn('effective_from', '<=', $orderTime);
                    if (! $includeBeforeHistory) {
                        return;
                    }
                    // The first recorded owner also covers orders placed before the first boundary.
                    $firstEffectiveFrom = $db->table('assistant_domain_store_owner_histories')
                        ->selectRaw('MIN(effective_from)')
                        ->whereColumn('assistant_domain_store_id', $orderTable.'.assistant_domain_store_id');
                    $query->orWhere('effective_from', '=', $firstEffectiveFrom);
                })
                ->where(fn ($query) => $query->whereNull('effective_to')
                    ->orWhereColumn('effective_to', '>', $orderTime))
                ->orderByDesc('effective_from')->orderByDesc('id')->limit(1);
            $initialOwnerId = $db->table('assistant_domain_store_owner_histories as next_history')
                ->select('next_history.id')
                ->whereColumn('next_history.assistant_domain_store_id', 'owner_history.assistant_domain_store_id')
                ->whereColumn('next_history.effective_from', 'owner_history.effective_to')
                ->where('owner_history.event', AssistantDomainStoreOwnerHistory::EVENT_BASELINE)
                ->whereNull('owner_history.owner_user_id')
                ->where(fn ($query) => $query->whereNull('owner_history.owner_name_snapshot')
                    ->orWhere('owner_history.owner_name_snapshot', ''))
                ->where(fn ($query) => $query->whereNull('next_history.effective_to')
                    ->orWhereColumn('next_history.effective_to', '>', 'next_history.effective_from'))
                ->orderByDesc('next_history.id')->limit(1);
            $orderQuery->leftJoin('assistant_domain_store_owner_histories as owner_history', fn ($join) =>
                $join->where('owner_history.id', '=', $historyId))
                ->leftJoin('assistant_domain_store_owner_histories as initial_owner', fn ($join) =>
                    $join->where('initial_owner.id', '=', $initialOwnerId))
                ->addSelect('owner_history.id as owner_history_id', 'owner_history.owner_name_snapshot as historical_owner_name',
                    'owner_history.owner_user_id as historical_owner_user_id', 'owner_history.event as historical_owner_event',
                    'initial_owner.owner_name_snapshot as initial_owner_name', 'initial_owner.owner_user_id as initial_owner_user_id');
        }
    }

    public function operationDepartments(): Collection
    {
        if (! $this->workbooks->database()->getSchemaBuilder()->hasTable(config('admin.database.roles_table'))) {
            return collect();
        }

        return app(AssistantStoreOwnerService::class)->storeOwnershipSelectableOperationDepartments();
    }

    private function operationDepartmentMembers(): Collection
    {
        $schema = $this->workbooks->database()->getSchemaBuilder();
        $user = new AdminUser;
        if (! $schema->hasTable($user->getTable()) || ! $schema->hasTable(config('admin.database.role_users_table'))) {
            return collect();
        }

        $departmentIds = $this->operationDepartments()->pluck('id')->all();
        if ($departmentIds === []) {
            return collect();
        }

        $scope = fn ($query) => $query->whereIn(config('admin.database.roles_table').'.id', $departmentIds);

        return AdminUser::query()->withWhereHas('departments', $scope)->get(['id', 'name', 'username'])
            ->map(function (AdminUser $member) {
                $departments = $member->departments->sortBy('id');
                $department = $departments->first(fn ($department) => (bool) $department->pivot->is_primary)
                    ?? $departments->first();
                $member->operation_department = $department?->name ?? '';

                return $member;
            });
    }

    /** Enrich settlements from a linked logistics order or a unique payment reference. */
    private function worldpayFashionOrderMetadata(Collection $records, Collection $domains): array
    {
        $db = $this->workbooks->database();
        if ($records->isEmpty() || ! $db->getSchemaBuilder()->hasTable('fashion_logistics_orders')) {
            return [];
        }
        $stores = $domains->keyBy('id');
        $table = 'fashion_logistics_orders';
        $selected = ['id', 'assistant_domain_store_id', 'source_domain', 'transaction_id', 'currency', 'total_amount',
            'order_created_at_utc', 'order_created_at'];
        $query = $db->table($table)->select(array_map(fn ($field) => $table.'.'.$field, $selected));
        $this->joinOrderOwnerHistory($query, $selected, $table, 'order_created_at_utc', includeBeforeHistory: false);
        $orders = $records->pluck('reference')->filter()->unique()->chunk(500)
            ->flatMap(fn ($references) => (clone $query)->whereIn($table.'.transaction_id', $references->values()->all())->get())
            ->groupBy('transaction_id');
        $orderIds = $orders->filter(fn ($matches) => $matches->count() === 1)->map(fn ($matches) => $matches->first()->id);
        $products = $db->getSchemaBuilder()->hasTable('fashion_logistics_order_items')
            ? $orderIds->chunk(500)->flatMap(fn ($ids) => $db->table('fashion_logistics_order_items')
                ->whereIntegerInRaw('fashion_logistics_order_id', $ids->values()->all())
                ->orderBy('id')->get(['fashion_logistics_order_id', 'product_name', 'total']))->groupBy('fashion_logistics_order_id')
            : collect();
        $metadata = [];
        foreach ($records as $record) {
            $matches = $orders->get($record->reference);
            if ($matches?->count() !== 1) {
                continue;
            }
            $order = $matches->first();
            $items = $products->get($order->id, collect());
            $order->tongtu_product_name = $items->pluck('product_name')->filter()->unique()->implode("\n");
            $order->paid_amount_usd = strtoupper(trim((string) $order->currency)) === 'USD' && $items->isNotEmpty()
                && $items->every(fn ($item) => $this->number($item->total) !== null)
                ? $items->reduce(fn ($sum, $item) => bcadd($sum, $this->number($item->total), 4), '0') : null;
            $metadata[$record->id] = [
                'order' => $order,
                'domain' => $stores->get($order->assistant_domain_store_id)?->domain ?: ($order->source_domain ?? ''),
            ];
        }
        return $metadata;
    }

    public function logisticsMetadata(Collection $records, string $channel, bool $matchOnly = false, bool $withCustomReference = false, bool $summaryOnly = false, bool $includeOrder = false): array
    {
        $db = $this->workbooks->database();
        if ($records->isEmpty() || ! $db->getSchemaBuilder()->hasTable('logistics_orders')) {
            return [];
        }
        $columns = $db->getSchemaBuilder()->getColumnListing('logistics_orders');
        $referenceFields = array_values(array_intersect(
            $channel === 'paypal' ? ['bill_number', 'transaction_id', 'payment_gateway_order_id'] : ['bill_number', 'transaction_id', 'payment_gateway_order_id', 'shopify_order_number'],
            $columns
        ));
        $hasPaymentReferences = ($channel === 'paypal' || $includeOrder)
            && $db->getSchemaBuilder()->hasTable('logistics_order_payment_references');
        if ($referenceFields === [] && ! $hasPaymentReferences) {
            return [];
        }
        $summaryFields = ['assistant_domain_store_id', 'source_shop_domain', 'subscription_type', 'is_add_on', 'tongtu_order_number',
            'order_created_at', 'payment_method', 'assigned_owner_name', 'assigned_owner_user_id', 'owner_assignment_resolved_at', 'operator_name', 'group_names'];
        $detailFields = [
            'shopify_order_number', 'shopify_order_id', 'store_name', 'subscription_status', 'subscription_origin_order_id',
            'tongtu_sku', 'tongtu_product_name', 'sale_quantity', 'sale_product_weight', 'payment_gateway',
            ...array_keys(FinancePayPalOrderExport::COLUMNS), 'created_at', 'buyer_name', 'buyer_email', 'destination',
        ];
        if ($includeOrder) {
            $detailFields[] = 'paid_amount_usd';
        }
        $selected = $matchOnly ? ['id', ...$referenceFields] : array_values(array_unique(array_intersect(
            ['id', ...$referenceFields, ...$summaryFields, ...($summaryOnly ? [] : $detailFields)], $columns,
        )));
        $referencesByRecord = $records->mapWithKeys(function ($record) use ($channel): array {
            $payload = $record->payload;

            return [$record->id => $channel === 'paypal'
                ? [$record->reference, trim((string) ($payload['帳單號碼'] ?? ''))]
                : [$record->reference, $payload['商户订单号'] ?? '', $payload['Shopify订单号'] ?? '']];
        });
        $references = $referencesByRecord->collapse()->filter()->unique()->all();
        $customReferences = collect();
        if ($channel === 'paypal' && $withCustomReference && ! $matchOnly
            && in_array('transaction_id', $columns, true) && in_array('paid_amount_usd', $columns, true)) {
            $checkoutLabels = array_column(array_filter(FinancePayPalEventTypes::TYPES, fn ($type) => $type[1] === '结账付款'), 0);
            $customReferences = $records->filter(fn ($record) => $record->currency === 'USD'
                && in_array(FinancePayPalEventTypes::label((string) $record->raw_type), $checkoutLabels, true)
                && in_array(strtoupper((string) $record->status), ['S', 'SUCCESS', 'COMPLETED', 'PAID', '已付款', '已完成', '成功'], true))
                ->mapWithKeys(fn ($record) => [$record->id => trim((string) ($record->payload['自定义编号'] ?? ''))])
                ->filter(fn ($reference) => $reference !== '');
            if ($customReferences->isNotEmpty()) {
                $selected = array_values(array_unique([...$selected, 'paid_amount_usd']));
            }
        }
        $paymentReferences = collect();
        $paymentTypes = [];
        $paymentReferenceColumns = [];
        if ($hasPaymentReferences) {
            $paymentReferenceColumns = ['reference_number', 'logistics_order_id'];
            if (! $matchOnly && $db->getSchemaBuilder()->hasColumn('logistics_order_payment_references', 'reference_type')) {
                $paymentReferenceColumns[] = 'reference_type';
            }
            $paymentReferences = $db->table('logistics_order_payment_references')->whereIn('reference_number', $references)->get($paymentReferenceColumns);
        }
        $linkedIds = $paymentReferences->pluck('logistics_order_id')->unique();
        // Resolve IDs through each reference index before loading the wider order rows.
        foreach (array_chunk($references, 500) as $batch) {
            $matches = null;
            foreach ($referenceFields as $field) {
                $lookup = $db->table('logistics_orders')->select('id')->whereIn($field, $batch);
                $matches = $matches ? $matches->union($lookup) : $lookup;
            }
            if ($matches !== null) {
                $linkedIds = $linkedIds->merge($matches->pluck('id'));
            }
        }
        foreach ($customReferences->unique()->chunk(500) as $batch) {
            $linkedIds = $linkedIds->merge($db->table('logistics_orders')->whereIn('transaction_id', $batch->values())->pluck('id'));
        }
        $linkedIds = $linkedIds->unique();
        if ($linkedIds->isEmpty()) return [];
        $orderQuery = $db->table('logistics_orders')->whereIntegerInRaw('logistics_orders.id', $linkedIds->all())
            ->select(array_map(fn ($column) => 'logistics_orders.'.$column, $selected));
        if ($channel === 'paypal' || $includeOrder) {
            $this->joinOrderOwnerHistory($orderQuery, $selected, includeBeforeHistory: $channel === 'paypal');
        }
        $orders = $orderQuery->get()->keyBy('id');
        $stores = ! $matchOnly && $db->getSchemaBuilder()->hasTable('assistant_domain_stores')
            ? $db->table('assistant_domain_stores')->whereIntegerInRaw('id', $orders->pluck('assistant_domain_store_id')->filter()->unique()->all())
                ->pluck('domain', 'id') : collect();
        $index = [];
        $customIndex = [];
        $customValues = $customReferences->flip();
        foreach ($orders as $order) {
            if (isset($customValues[$order->transaction_id ?? ''])) {
                $customIndex[$order->transaction_id][$order->id] = $order;
            }
            foreach ($referenceFields as $field) {
                if (filled($order->$field)) {
                    $index[(string) $order->$field][$order->id] = $order;
                }
            }
        }
        foreach ($paymentReferences as $reference) {
            if ($order = $orders->get($reference->logistics_order_id)) {
                $index[$reference->reference_number][$order->id] = $order;
                if (isset($reference->reference_type)) {
                    $paymentTypes[$reference->reference_number][$order->id] = $reference->reference_type;
                }
            }
        }
        $customOrderIds = collect($customIndex)->filter(fn ($orders) => count($orders) === 1)
            ->flatMap(fn ($orders) => array_keys($orders))->all();
        $ordersWithPrimaryReference = $customOrderIds !== [] && in_array('reference_type', $paymentReferenceColumns, true)
            ? $db->table('logistics_order_payment_references')->whereIntegerInRaw('logistics_order_id', $customOrderIds)
                ->where('reference_type', LogisticsOrderPaymentReference::TYPE_PRIMARY)->pluck('logistics_order_id')->flip()
            : collect();
        $result = [];
        foreach ($records as $record) {
            $candidates = [];
            foreach (array_filter($referencesByRecord[$record->id], fn ($value) => trim((string) $value) !== '') as $reference) {
                foreach ($index[(string) $reference] ?? [] as $id => $order) {
                    $candidates[$id] = $order;
                }
            }
            $matchedCustomReference = false;
            if ($candidates === [] && $customReferences->has($record->id)) {
                $customCandidates = $customIndex[$customReferences->get($record->id)] ?? [];
                if (count($customCandidates) === 1) {
                    $candidate = reset($customCandidates);
                    $gross = $this->number($record->payload[FinanceCatalog::dataset('paypal-orders')['headers'][7]] ?? null);
                    $paid = $this->number($candidate->paid_amount_usd);
                    if (blank($candidate->bill_number ?? null) && ! $ordersWithPrimaryReference->has($candidate->id)
                        && $gross !== null && $paid !== null
                        && bccomp($gross, '0', 4) > 0 && bccomp($gross, $paid, 4) === 0) {
                        $candidates = $customCandidates;
                        $matchedCustomReference = true;
                    }
                }
            }
            if (count($candidates) !== 1) {
                continue;
            }
            $order = reset($candidates);
            if ($matchOnly) {
                $result[$record->id] = ['logistics_order_id' => $order->id];
                continue;
            }
            $result[$record->id] = ['logistics_order_id' => $order->id, 'domain' => $stores->get($order->assistant_domain_store_id ?? null) ?: ($order->source_shop_domain ?? ''),
                'payment_method' => $order->payment_method ?? '',
                'subscription' => $order->subscription_type ?? '', 'upsell' => $order->is_add_on ?? '', 'erp_order' => $order->tongtu_order_number ?? ''];
            if ($channel === 'paypal' || $includeOrder) {
                $result[$record->id]['order'] = $order;
            }
            if ($channel === 'paypal') {
                $result[$record->id]['payment_reference_type'] = $paymentTypes[$record->reference][$order->id]
                    ?? ($matchedCustomReference || (string) ($order->bill_number ?? '') === $record->reference
                        ? LogisticsOrderPaymentReference::TYPE_PRIMARY : null);
            }
        }

        return $result;
    }

    public function logisticsPaymentReferences(object $order): array
    {
        $db = $this->workbooks->database();
        $references = collect([$order->bill_number ?? '', $order->transaction_id ?? '', $order->payment_gateway_order_id ?? '']);
        if ($db->getSchemaBuilder()->hasTable('logistics_order_payment_references')) {
            $references = $references->merge($db->table('logistics_order_payment_references')
                ->where('logistics_order_id', $order->id)->pluck('reference_number'));
        }

        return $references->filter(fn ($reference) => filled($reference))->flip()->all();
    }

    /** Resolve costs to a uniquely matched primary PayPal payment. */
    public function paypalCostPayments(array $orderNumbers, array $filters): Collection
    {
        $db = $this->workbooks->database();
        $schema = $db->getSchemaBuilder();
        if (! $schema->hasColumns('logistics_orders', ['tongtu_order_number', 'bill_number'])) {
            return collect();
        }
        $orders = $db->table('logistics_orders')->whereIn('tongtu_order_number', $orderNumbers)
            ->get(['id', 'tongtu_order_number', 'bill_number']);
        $references = $orders->pluck('bill_number');
        if ($schema->hasColumns('logistics_order_payment_references', ['reference_type', 'reference_number', 'logistics_order_id'])) {
            $references = $references->merge($db->table('logistics_order_payment_references')
                ->whereIn('logistics_order_id', $orders->pluck('id'))
                ->where('reference_type', LogisticsOrderPaymentReference::TYPE_PRIMARY)->pluck('reference_number'));
        }
        $payments = $this->query('paypal', $filters)->whereIn('reference', $references->filter()->unique()->values())
            ->orderBy('id')->lockForUpdate()->get();
        $metadata = $this->logisticsMetadata($payments, 'paypal');

        return $payments->filter(fn ($payment) => in_array(strtoupper((string) $payment->status),
            ['S', 'SUCCESS', 'COMPLETED', 'PAID', '已付款', '已完成', '成功'], true)
            && ($metadata[$payment->id]['payment_reference_type'] ?? null) === LogisticsOrderPaymentReference::TYPE_PRIMARY)
            ->groupBy(fn ($payment) => $metadata[$payment->id]['erp_order']);
    }

    /** Match API transaction/invoice references without any legacy account binding. */
    public function paypalOrderMatchIndex(): \Illuminate\Database\Query\Builder
    {
        $db = $this->workbooks->database();
        $schema = $db->getSchemaBuilder();
        $references = $db->table('finance_records')->where('dataset', 'paypal-orders')
            ->whereNotNull('reference')->where('reference', '!=', '')
            ->selectRaw('id as record_id, reference as match_reference');
        $bill = app(FinanceSourceStorage::class)->active('record') ? 'source_bill' : 'payload->帳單號碼';
        $references->union($db->table('finance_records')->where('dataset', 'paypal-orders')
            ->whereNotNull($bill)->where($bill, '!=', '')
            ->select('id as record_id', $bill.' as match_reference'));
        $matches = null;
        foreach (array_intersect(['bill_number', 'transaction_id', 'payment_gateway_order_id'], $schema->getColumnListing('logistics_orders')) as $field) {
            $branch = $db->query()->fromSub(clone $references, 'refs')
                ->join('logistics_orders as source_order', 'source_order.'.$field, '=', 'refs.match_reference')
                ->select('refs.record_id', 'source_order.id as order_id');
            $matches = $matches ? $matches->unionAll($branch) : $branch;
        }
        if ($schema->hasTable('logistics_order_payment_references')) {
            $branch = $db->query()->fromSub(clone $references, 'refs')
                ->join('logistics_order_payment_references as source_ref', 'source_ref.reference_number', '=', 'refs.match_reference')
                ->join('logistics_orders as source_order', 'source_order.id', '=', 'source_ref.logistics_order_id')
                ->select('refs.record_id', 'source_order.id as order_id');
            $matches = $matches ? $matches->unionAll($branch) : $branch;
        }
        $matches ??= $db->table('finance_records')->selectRaw('id as record_id, 0 as order_id')->whereRaw('1 = 0');

        return $db->query()->fromSub($matches, 'matches')->select('record_id')
            ->selectRaw('MIN(order_id) as order_id')->groupBy('record_id')->havingRaw('COUNT(DISTINCT order_id) = 1');
    }

    public function paypalOrderMatches(): \Illuminate\Database\Query\Builder
    {
        $db = $this->workbooks->database();
        $schema = $db->getSchemaBuilder();
        $fields = array_intersect(['bill_number', 'transaction_id', 'payment_gateway_order_id'], $schema->getColumnListing('logistics_orders'));
        $hasReferences = $schema->hasTable('logistics_order_payment_references');
        return $db->table('logistics_orders as logistics')->where(function ($match) use ($fields, $hasReferences): void {
            $match->whereRaw('1 = 0');
            foreach ($fields as $field) {
                $match->orWhere(function ($reference) use ($field): void {
                    $reference->where('logistics.'.$field, '!=', '')->where(function ($values) use ($field): void {
                        $values->whereColumn('logistics.'.$field, 'finance_records.reference')
                            ->orWhereColumn('logistics.'.$field, 'finance_records.payload->帳單號碼');
                    });
                });
            }
            if ($hasReferences) {
                $match->orWhereExists(function ($references): void {
                    $references->selectRaw('1')->from('logistics_order_payment_references as payment_reference')
                        ->whereColumn('payment_reference.logistics_order_id', 'logistics.id')
                        ->where('payment_reference.reference_number', '!=', '')
                        ->where(function ($values): void {
                            $values->whereColumn('payment_reference.reference_number', 'finance_records.reference')
                                ->orWhereColumn('payment_reference.reference_number', 'finance_records.payload->帳單號碼');
                        });
                });
            }
        });
    }

    public static function isSuccessfulTransaction(mixed $status): bool
    {
        return in_array(strtoupper((string) $status), self::TRANSACTION_STATUS_CODES['success'], true);
    }

    public static function transactionStatusCategory(mixed $status): string
    {
        $status = strtoupper(trim((string) $status));
        foreach (self::TRANSACTION_STATUS_CODES as $category => $codes) {
            if (in_array($status, $codes, true)) {
                return $category;
            }
        }

        return $status;
    }

    public static function subscriptionLabel(mixed $value): string
    {
        $label = str_replace('订购复购', '订阅复购', FinanceCatalog::simplified(trim((string) $value)));

        return $label === '订阅首次购买' ? '订阅' : preg_replace('/^订阅复购\s*(\d+)\s*次$/u', '订阅复购$1次', $label);
    }

    public static function isUpsell(mixed $value): bool
    {
        return in_array(strtolower(FinanceCatalog::simplified(trim((string) $value))), ['1', 'true', 'yes', '是', '加购', '已加购'], true);
    }

    public function subscriptionOptions(Collection $rows, bool $includeSourceOptions = true): Collection
    {
        if (! $includeSourceOptions) {
            return $rows->pluck('subscription')->map(self::subscriptionLabel(...))
                ->filter(fn ($value) => $value !== '')->unique()->sort()->values();
        }
        $db = $this->workbooks->database();
        $key = 'finance:subscription-options:v2:'.hash('sha256', $db->getName().'|'.$db->getDatabaseName())
            .':'.app(FinanceSummaryDataVersion::class)->cacheRevision(['paypal', 'credit_card']);
        $default = config('cache.default');
        // Report builds can run inside a transaction. Keep this cache outside its database locks.
        $cache = Cache::store(config("cache.stores.{$default}.driver") === 'database' ? 'file' : $default);
        $options = $cache->remember($key, 60, function () use ($db): array {
            $datasets = ['paypal-orders', 'xuzong2-orders', 'xuzong2-details', 'xuzong1-details'];
            $types = FinanceRecord::query()->whereIn('dataset', $datasets)
                ->distinct()->get(['payload->订阅类型 as subscription', 'payload->是否加购 as upsell']);
            $supplements = $db->table('finance_settlement_supplements')
                ->distinct()->get(['payload->subscription as subscription', 'payload->upsell as upsell']);
            $columns = array_intersect(['subscription_type', 'is_add_on'], $db->getSchemaBuilder()->getColumnListing('logistics_orders'));
            $logistics = $columns === [] ? collect() : $db->table('logistics_orders')->distinct()->get(array_values($columns));
            $upsells = $types->pluck('upsell')->concat($supplements->pluck('upsell'))
                ->concat($logistics->pluck('is_add_on'));

            return $types->pluck('subscription')->concat($supplements->pluck('subscription'))->concat($logistics->pluck('subscription_type'))
                ->concat($upsells->contains(self::isUpsell(...)) ? ['加购'] : [])->all();
        });

        return $rows->pluck('subscription')->concat($options)
            ->map(self::subscriptionLabel(...))->filter(fn ($value) => $value !== '')->unique()->sort()->values();
    }

    public function shopDifference(mixed $channelAmount, mixed $shopPaid): ?string
    {
        $channelAmount = $this->number($channelAmount);
        $shopPaid = $this->number($shopPaid);

        return $channelAmount !== null && $shopPaid !== null ? bcsub($channelAmount, $shopPaid, 2) : null;
    }

    public function number(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        $text = str_replace(',', '', trim((string) ($value ?? '')));

        return preg_match('/^-?\d{1,18}(?:\.\d{1,8})?$/', $text) ? $text : null;
    }

    public function moneyFields(string $channel): array
    {
        $keys = $channel === 'paypal' ? ['converted_usd', 'usd_rate', 'fee', 'hold', 'dispute_hold', 'frozen_refund', 'refund_top_up', 'refund', 'refund_fee', 'dispute_refund', 'dispute_fee', 'fee_return', 'dispute_release', 'release', 'logistics', 'purchase']
            : ['usd_rate', 'fee', 'hold', 'per_order_fee', 'refund', 'refund_fee', 'chargeback', 'chargeback_fee', 'ethoca_refund', 'ethoca_fee', 'rdr_refund', 'rdr_fee', 'release', 'logistics', 'purchase'];

        $fields = array_intersect_key(self::MONEY, array_flip($keys));
        if ($channel === 'paypal') {
            $fields = [...$fields, 'usd_rate' => '汇率', 'logistics' => '物流-元', 'purchase' => '采购成本-元'];
        }

        return $fields;
    }

    public function summaryRows(string $channel, array $filters, bool $transactions = false): Collection
    {
        return collect(iterator_to_array($this->summaryRowStream($channel, $filters, $transactions), false));
    }

    public function summaryRowStream(string $channel, array $filters, bool $transactions = false): iterable
    {
        $filters['summary_only'] = true;
        $fields = self::MONEY + array_fill_keys(['id', 'logistics_order_id', 'channel', 'account', 'account_key',
            'owner', 'team', 'subscription', 'payment_method', 'success', 'failed', 'settlement'], true);
        // Both summary and transaction consumers need the same grouping fields.
        $fields += self::CONDITION_FIELDS + array_fill_keys(['currency', 'month'], true);
        $fields['_summary_team'] = true;
        $fields['_summary_settlement_currency'] = true;
        $fields['_summary_xuzong_detail'] = $fields['_summary_payable'] = $fields['_summary_amount_usd'] = true;
        if (! empty($filters['summary_shared_source'])) {
            $fields += array_fill_keys(['_summary_shared_version', '_summary_native_values', '_summary_native_currency'], true);
        }
        // Keep the original date order for grouping and for assigning costs to the first successful payment.
        $query = $this->query($channel, $filters)->orderByDesc('occurred_at')->orderByDesc('id');
        $paypalOrders = $channel === 'paypal' ? app(FinancePayPalSettlementOrders::class) : null;
        if ($channel === 'credit_card' && empty($filters['card_channel'])) {
            $query->select('finance_records.*');
            $accounts = FinancePaymentAccount::query()->where('account_type', 'credit_card')->get();
            foreach (['worldpay', 'ye'] as $platform) {
                $match = FinanceRecord::query();
                FinanceCreditSettlementLayout::filter($match, $platform, $accounts);
                $predicate = substr($match->getQuery()->getGrammar()->compileWheres($match->getQuery()), strlen('where '));
                $query->selectRaw('CASE WHEN '.$predicate.' THEN 1 ELSE 0 END as matches_'.$platform, $match->getBindings());
            }
        }
        // A full-month summary should not repeat matching and sorting every
        // 500 rows. Bound decoded payload memory on smaller PHP workers.
        $memory = ini_parse_quantity((string) ini_get('memory_limit'));
        $batchSize = ($memory <= 0 || $memory >= 256 * 1024 ** 2)
            ? max(500, min(2000, (int) config('finance.summaries.source_batch_size', 2000))) : 500;
        $context = null;
        $last = null;
        try {
            do {
                $page = clone $query;
                if ($last !== null) {
                    $page->where(fn ($scope) => $scope->where('occurred_at', '<', $last->getRawOriginal('occurred_at'))
                        ->orWhere(fn ($tie) => $tie->where('occurred_at', $last->getRawOriginal('occurred_at'))->where('id', '<', $last->id)));
                }
                $records = $page->limit($batchSize)->get();
                if ($records->isEmpty()) {
                    break;
                }
                $last = $records->last();
                $records->each(fn (FinanceRecord $record) => $record->withCachedReportCasts());
                $paypalAmounts = [];
                $sourceRows = [];
                $reusePayPalRows = $paypalOrders !== null
                    && ! collect(\Illuminate\Support\Arr::only($filters, ['account', 'team', 'subscription', 'domain', 'conditions']))->contains(fn ($value) => filled($value));
                if ($paypalOrders !== null) {
                    $capture = $reusePayPalRows ? function (Collection $payments) use (&$sourceRows, $fields, $filters): void {
                        foreach ($payments as $id => $payment) {
                            if (! empty($filters['logistics_costs']) && isset($payment['business_order_id'])) $payment['logistics_order_id'] = $payment['business_order_id'];
                            if (! empty($filters['summary_native_settlement'])) $payment['_summary_settlement_currency'] = 'USD';
                            $sourceRows[$id] = array_intersect_key($payment, $fields) + ['payment_channel' => 'paypal'];
                        }
                    } : null;
                    foreach ($paypalOrders->exportRows($filters, matchCandidateDomains: false, recordIds: $records->pluck('id')->all(), onSourceRows: $capture) as $detail) {
                        $paypalAmounts[$detail['id']] = array_intersect_key($detail, self::MONEY + ['settlement' => true]);
                    }
                }
                $unresolved = $reusePayPalRows ? $records->reject(fn ($record) => isset($sourceRows[$record->id])) : $records;
                if ($unresolved->isNotEmpty()) $context ??= $this->rowContext($channel) + ['conflux_report_fees' => new FinanceStatementFeeCache];
                $resolved = $sourceRows;
                foreach ($unresolved->groupBy(fn ($record) => $filters['card_channel'] ?? match (true) {
                    (bool) $record->matches_worldpay => 'worldpay',
                    (bool) $record->matches_ye => 'ye',
                    default => '',
                }) as $platform => $group) {
                    $scope = filled($platform) ? [...$filters, 'card_channel' => $platform] : $filters;
                    $resolved += $this->summaryDetailRows($channel, $scope, $group, $context, $fields);
                    foreach ($group as $record) {
                        if (isset($resolved[$record->id])) {
                            $resolved[$record->id]['payment_channel'] = $channel === 'paypal' ? 'paypal' : ($platform ?: (
                                in_array($record->dataset, ['xuzong1-details', FinanceCatalog::XUZONG_REPORT_IMPORTS['xuzong1-details']], true)
                                    ? 'xuzong1' : 'xuzong2'
                            ));
                        }
                    }
                }
                foreach ($records as $record) {
                    if (isset($resolved[$record->id])) {
                        if (isset($paypalAmounts[$record->id])) {
                            $resolved[$record->id] = array_replace($resolved[$record->id], $paypalAmounts[$record->id]);
                        }
                        yield $resolved[$record->id] + ($channel === 'credit_card' ? ['_summary_credit_version' => self::CREDIT_SUMMARY_VERSION] : [])
                            + (! empty($filters['summary_shared_source']) ? ['_summary_shared_version' => 1] : []) + ['_summary_usd_version' => 1,
                            '_summary_settlement_currency_version' => ! empty($filters['summary_native_settlement']) ? 1 : 0]
                            + (! empty($filters['summary_projection'])
                            ? ['_summary_source_account' => $record->account] : []);
                    }
                }
            } while ($records->count() === $batchSize);
        } finally {
            $paypalOrders?->releaseExportGraph();
        }
        // The final source batch and its bill cache are no longer needed while
        // reading unmatched fees. Do not retain them across two large scans.
        unset($records, $resolved, $sourceRows, $paypalAmounts, $unresolved, $group, $context, $last);
        if ($channel === 'credit_card' && ! empty($filters['include_unmatched_fees'])
            && (empty($filters['summary_payment_channels']) || in_array('ye', $filters['summary_payment_channels'], true))) {
            $accounts = FinancePaymentAccount::query()->where('account_type', 'credit_card')->get()->keyBy('id');
            $conflux = app(FinanceConfluxSettlement::class);
            $rates = app(FinanceCreditUsdRates::class);
            $statements = $conflux->unmatchedRows([...$filters, 'card_channel' => 'ye', 'conflux_report_fees' => new FinanceStatementFeeCache]);
            foreach (\Illuminate\Support\LazyCollection::make(fn () => $statements)->chunk(500) as $batch) {
                $orders = $batch->map(fn ($row) => (object) [
                    'currency' => strtoupper(trim((string) ($row['card_layout']['settlement_currency'] ?? ''))),
                    'occurred_at' => CarbonImmutable::parse($row['settlement_date'], 'Asia/Shanghai'), 'payload' => [],
                ])->collect();
                $exchange = $rates->forOrders($orders);
                foreach ($batch as $key => $statement) {
                    $account = $accounts->get($statement['payment_account_id']);
                    if (! $account || $orders[$key]->currency === '') {
                        continue;
                    }
                    $amounts = array_fill_keys(array_keys(self::MONEY), null);
                    foreach (['fee', 'per_order_fee', 'refund', 'refund_fee', 'chargeback', 'chargeback_fee', 'ethoca_refund', 'ethoca_fee', 'rdr_refund', 'rdr_fee'] as $field) {
                        $amount = $this->number($statement['card_layout'][$field] ?? null);
                        if ($amount !== null) {
                            $amounts[$field] = ! empty($filters['summary_native_settlement']) ? $amount
                                : $this->number($rates->convert($exchange, $orders[$key]->currency, $statement['settlement_date'], $amount));
                        }
                    }
                    if (count(array_filter($amounts, fn ($amount) => $amount !== null)) === 0) {
                        continue;
                    }
                    yield $amounts + [
                        'id' => -$statement['entry_id'], 'channel' => 'credit_card', 'payment_channel' => 'ye',
                        'account' => $account->account_name, 'account_key' => $account->activity_account,
                        '_summary_source_account' => $account->activity_account, '_summary_team' => '',
                        '_summary_credit_version' => self::CREDIT_SUMMARY_VERSION,
                        ...(! empty($filters['summary_shared_source']) ? ['_summary_shared_version' => 1,
                            '_summary_native_currency' => $orders[$key]->currency,
                            '_summary_native_values' => collect(['fee', 'per_order_fee', 'refund', 'refund_fee', 'chargeback', 'chargeback_fee', 'ethoca_refund', 'ethoca_fee', 'rdr_refund', 'rdr_fee'])
                                ->mapWithKeys(fn ($field) => [$field => $this->number($statement['card_layout'][$field] ?? null)])->all()] : []),
                        'owner' => '', 'team' => '', 'subscription' => '', 'payment_method' => '',
                        'currency' => $orders[$key]->currency,
                        '_summary_settlement_currency' => ! empty($filters['summary_native_settlement']) ? $orders[$key]->currency : 'USD',
                        '_summary_settlement_currency_version' => ! empty($filters['summary_native_settlement']) ? 1 : 0,
                        'month' => substr($statement['settlement_date'], 0, 7),
                        'gross' => null, 'settlement' => null, 'success' => false, 'failed' => false,
                        'reference' => $statement['card_layout']['reference'], 'statement_only' => true,
                    ];
                }
            }
        }
    }

    private function summaryDetailRows(string $channel, array $filters, Collection $records, array $context, array $fields): array
    {
        $xuzong = $channel === 'credit_card' ? $records->where('dataset', FinanceLogisticsCreditOrders::IMPORTED_DATASET) : collect();
        $sourceRows = [];
        if ($xuzong->isNotEmpty()) {
            $sourceRows = app(FinanceXuzongCreditReport::class)->summaryRows($xuzong, $filters['timezone'] ?? 'Asia/Shanghai');
            $sourceRows = array_map(fn ($row) => array_intersect_key($row, $fields), $sourceRows);
            $records = $records->where('dataset', '!=', FinanceLogisticsCreditOrders::IMPORTED_DATASET);
            if ($records->isEmpty()) return $sourceRows;
        }
        $details = $this->rows($channel, $filters, $records, $context)->keyBy('id');
        if (! empty($filters['summary_account_counts'])) {
            $failed = $details->filter(fn ($row) => $row['failed'] && ! $row['success'])->map(function ($row) {
                if ($row['account_key'] === FinanceWorldpayImport::SOURCE_ACCOUNT) $row['account'] = 'Worldpay';
                return $row;
            });
            $details = $details->reject(fn ($row) => $row['failed'] && ! $row['success']);
        } else $failed = collect();
        $platform = $filters['card_channel'] ?? null;
        if (! in_array($platform, ['ye', 'worldpay'], true)) {
            if ($channel === 'credit_card') {
                $sources = $records->keyBy('id');
                $fields['_summary_amount_usd'] = true;
                $details = $details->map(function (array $row) use ($sources): array {
                    $payload = $sources[$row['id']]->payload;
                    $row['_summary_amount_usd'] = $this->number($payload['结算-美元'] ?? null)
                        ?? ($row['currency'] === 'USD' ? $row['gross'] : null)
                        ?? ($row['gross'] !== null && $row['usd_rate'] !== null
                            ? bcmul($row['gross'], $row['usd_rate'], 8) : null)
                        ?? $row['settlement'];
                    return $row;
                });
            }
            return $details->map(function ($row) use ($fields, $filters) {
                if (! empty($filters['summary_native_settlement'])) {
                    $row['_summary_settlement_currency'] = 'USD';
                }
                return array_intersect_key($row, $fields);
            })->union($failed->map(fn ($row) => array_intersect_key($row, $fields)))->all() + $sourceRows;
        }
        $currencyField = $platform === 'worldpay' ? 'statement_currency' : 'settlement_currency';
        $currencies = $details->map(fn ($row) => strtoupper(trim((string) ($row['card_layout'][$currencyField] ?? ''))));
        $orders = $records->filter(fn ($record) => filled($currencies[$record->id] ?? null) && $currencies[$record->id] !== 'USD')
            ->map(fn ($record) => (object) ['currency' => $currencies[$record->id], 'occurred_at' => $record->occurred_at, 'payload' => []]);
        $usdRates = app(FinanceCreditUsdRates::class);
        $rates = $usdRates->forOrders($orders);
        $dates = $records->mapWithKeys(fn ($record) => [$record->id => $record->occurred_at->setTimezone('Asia/Shanghai')->toDateString()]);
        $moneyFields = ! empty($filters['summary_settlement_only']) ? ['settlement' => true] : self::MONEY + ['settlement' => true];
        return $details->map(function (array $row) use ($fields, $currencies, $usdRates, $rates, $dates, $moneyFields, $platform, $filters): array {
            $layout = $row['card_layout'];
            $currency = $currencies[$row['id']];
            $nativeValues = [];
            foreach (array_intersect_key($layout, $moneyFields) as $field => $value) {
                $amount = $this->number($value);
                $nativeValues[$field] = $amount;
                if (empty($filters['summary_native_settlement']) && $amount !== null && $currency !== ''
                    && $currency !== 'USD' && ! in_array($field, ['logistics', 'purchase'], true)) {
                    $amount = $this->number($usdRates->convert($rates, $currency, $dates[$row['id']], $amount));
                }
                $row[$field] = $amount;
            }
            if ($platform === 'ye' && $row['settlement'] === null) {
                $row['settlement'] = $this->number($layout['source_settlement_usd'] ?? null);
            }
            if ($platform === 'ye' && ($nativeValues['settlement'] ?? null) === null) {
                $nativeValues['settlement'] = $this->number($layout['source_settlement_usd'] ?? null);
            }
            if (! empty($filters['summary_shared_source'])) {
                $row['_summary_native_currency'] = $currency !== '' ? $currency : (strtoupper(trim((string) ($row['currency'] ?? ''))) ?: 'USD');
                $row['_summary_native_values'] = array_filter($nativeValues, fn ($amount, $field) => $amount !== ($row[$field] ?? null), ARRAY_FILTER_USE_BOTH);
            }
            if ($row['account_key'] === FinanceWorldpayImport::SOURCE_ACCOUNT) {
                $row['account'] = 'Worldpay';
            }
            $row['_summary_settlement_currency'] = ! empty($filters['summary_native_settlement'])
                ? ($currency !== '' ? $currency : (strtoupper(trim((string) ($row['currency'] ?? ''))) ?: 'USD'))
                : 'USD';
            $row = array_replace($row, array_intersect_key($layout, array_flip(['domain', 'owner', 'team', 'payment_method'])));
            return array_intersect_key($row, $fields);
        })->union($failed->map(fn ($row) => array_intersect_key($row, $fields)))->all() + $sourceRows;
    }

    public function totals(iterable $rows, string $layer): array
    {
        if (! $rows instanceof Collection && in_array($layer, ['business', 'classification', 'project_classification', 'payment_method'], true)) {
            $groups = [];
            foreach (\Illuminate\Support\LazyCollection::make(fn () => $rows)->chunk(500) as $batch) {
                foreach ($this->totals(collect($batch->all()), $layer) as $group) {
                    $key = json_encode([$group['name'], $group['channel'], $group['scope'] ?? null, $group['category'] ?? null]);
                    if (! isset($groups[$key])) {
                        $groups[$key] = $group;
                        continue;
                    }
                    foreach (['count', 'success_count', 'failed_count'] as $field) {
                        $groups[$key][$field] += $group[$field];
                    }
                    foreach (['settlement', ...array_keys(self::MONEY)] as $field) {
                        if ($group[$field] !== null) {
                            $groups[$key][$field] = bcadd($groups[$key][$field] ?? '0', $group[$field], 8);
                        }
                    }
                }
            }
            $result = array_values($groups);
            usort($result, fn ($a, $b) => [
                $layer === 'business' && $a['scope'] !== 'Shopify', ($a['category'] ?? '') !== '总计' && empty($a['is_total']),
            ] <=> [
                $layer === 'business' && $b['scope'] !== 'Shopify', ($b['category'] ?? '') !== '总计' && empty($b['is_total']),
            ]);

            return $result;
        }
        if ($layer === 'business') {
            $classifiedRows = $rows->map(function ($row) {
                $isFake = $row['channel'] === 'paypal' && str_contains(($row['team'] ?? '').' '.($row['owner'] ?? ''), '刷单');
                $subscription = $isFake ? '刷单' : ($row['subscription'] ?? '');

                return ($row['subscription'] ?? null) === $subscription ? $row : [...$row, 'subscription' => $subscription];
            });
            $groups = [];
            foreach ([['Shopify', 'project_classification'], ['通道', 'classification']] as [$scope, $classification]) {
                $scopeRows = $scope === 'Shopify'
                    ? $classifiedRows->filter(fn ($row) => self::isShopifySummaryChannel($row['payment_channel'] ?? $row['channel']))
                    : $classifiedRows;
                foreach ($this->totals($scopeRows, $classification) as $group) {
                    [$channelName, $category] = explode(' / ', $group['name'], 2);
                    $isTotal = $group['is_total'] ?? false;
                    $group['scope'] = $scope === '通道' ? $channelName : $scope;
                    $group['category'] = $category;
                    $group['name'] = $channelName.($isTotal ? '' : ' / '.$category);
                    $group['is_total'] = $isTotal && $scope === 'Shopify';
                    $groups[] = $group;
                }
            }

            return $groups;
        }
        if (in_array($layer, ['classification', 'project_classification', 'payment_method'], true)) {
            if ($layer === 'project_classification') {
                $rows = $rows->filter(fn ($row) => self::isShopifySummaryChannel($row['payment_channel'] ?? $row['channel']));
            }
            $baseLayer = $layer === 'project_classification' ? 'project' : 'channel';
            $totals = $this->totals($rows, $baseLayer);
            foreach ($totals as &$total) {
                $total['name'] .= ' / 总计';
                $total['is_total'] = true;
            }
            unset($total);
            $classified = $rows->filter(fn ($row) => filled($layer === 'payment_method' ? ($row['payment_method'] ?? '') : $row['subscription']));
            $details = $classified->groupBy(fn ($row) => json_encode([
                $layer === 'project_classification' ? 'combined' : $row['channel'],
                $layer === 'payment_method' ? ($row['payment_method'] ?? '') : self::subscriptionLabel($row['subscription']),
            ]))->map(function ($items) use ($layer) {
                $first = $items->first();
                $group = $this->totals($items, $layer === 'project_classification' ? 'project' : 'channel')[0];
                $category = $layer === 'payment_method' ? ($first['payment_method'] ?: '未识别支付方式')
                    : (self::subscriptionLabel($first['subscription']) ?: '未分类');
                $group['name'] .= ' / '.$category;

                return $group;
            })->values()->all();

            return [...$totals, ...$details];
        }
        $groups = [];
        $amountFields = ['settlement', ...array_keys(self::MONEY)];
        $emptyAmounts = array_replace(array_fill_keys($amountFields, '0'), ['logistics' => null, 'purchase' => null]);
        foreach ($rows as $row) {
            if ($layer === 'project' && ! self::isShopifySummaryChannel($row['payment_channel'] ?? $row['channel'])) {
                continue;
            }
            $name = match ($layer) {
                'project' => 'Shopify',
                'channel' => match ($row['channel']) { 'credit_card' => '信用卡', 'xuzong' => '徐总信用卡', default => self::REPORT_CHANNELS[$row['channel']] ?? '信用卡' },
                'team' => $row['team'] ?: '未分组',
                'subscription' => $row['subscription'] ?: '未分类',
                'detail' => $row['account'].' / '.($row['team'] ?: '未分组').' / '.($row['subscription'] ?: '未分类'),
                default => $row['account'],
            };
            $channel = $layer === 'project' ? 'combined' : $row['channel'];
            $key = json_encode([$name, $channel]);
            $groups[$key] ??= ['name' => $name, 'channel' => $channel, 'count' => 0, 'success_count' => 0, 'failed_count' => 0] + $emptyAmounts;
            if (! empty($row['_cost_adjustment'])) {
                foreach (array_intersect_key($row, ['purchase' => true, 'logistics' => true]) as $field => $value) {
                    $groups[$key][$field] = bcadd($groups[$key][$field] ?? '0', $value, 8);
                }
                continue;
            }
            $groups[$key]['count']++;
            $groups[$key]['success_count'] += $row['success'] ? 1 : 0;
            $groups[$key]['failed_count'] += $row['failed'] ? 1 : 0;
            foreach ($amountFields as $field) {
                if ($field === 'settlement' && $row['failed']) {
                    continue;
                }
                // Workbook SUM ignores empty cells; retain blanks in detail, sum known values here.
                $amount = $field === 'refund' ? self::refundIncludingSplit($row) : $row[$field];
                if ($amount !== null) {
                    $groups[$key][$field] = bcadd($groups[$key][$field] ?? '0', $amount, 8);
                }
            }
        }

        return array_values($groups);
    }

    public const SHOPIFY_SUMMARY_CHANNELS = ['paypal', 'xuzong1', 'xuzong2', 'xuzong', 'credit_card'];

    public static function isShopifySummaryChannel(string $channel): bool
    {
        return in_array($channel, self::SHOPIFY_SUMMARY_CHANNELS, true);
    }

    public static function refundIncludingSplit(array $row): ?string
    {
        if (array_key_exists('_summary_refund', $row)) return $row['_summary_refund'];
        $refund = $row['refund'] ?? null;
        if ($row['channel'] === 'paypal') {
            foreach (['frozen_refund' => 'refund', 'refund_top_up' => 'refund_fee'] as $field => $legacy) {
                // A legacy amount may already cover this component.
                if (isset($row[$field]) && bccomp($row[$field], '0', 8) !== 0
                    && bccomp($row[$legacy] ?? '0', '0', 8) === 0) {
                    $refund = bcadd($refund ?? '0', $row[$field], 8);
                }
            }
        }

        return $refund;
    }

    public function save(FinanceRecord $record, array $values, int $actor): void
    {
        $db = $this->workbooks->database();
        $db->transaction(function () use ($db, $record, $values, $actor): void {
            app(FinanceAccountingService::class)->guardUnlocked($record->occurred_at->setTimezone('Asia/Shanghai')->format('Y-m'));
            $existing = $db->table('finance_settlement_supplements')->where('finance_record_id', $record->id)->first();
            $data = $existing ? json_decode($existing->payload, true, 512, JSON_THROW_ON_ERROR) : [];
            if (! array_key_exists('_edited_fields', $values)) {
                $values = array_diff_key($values, $data['_edited_fields'] ?? []);
            }
            if (filled($data['_edited_fields']['month'] ?? null)) {
                app(FinanceAccountingService::class)->guardUnlocked($data['_edited_fields']['month']);
            }
            foreach ($values as $key => $value) {
                if ($value === null && (isset(self::MONEY[$key]) || in_array($key, FinanceCreditSettlementLayout::numericFields('ye'), true)
                    || in_array($key, FinanceCreditSettlementLayout::numericFields('worldpay'), true))) {
                    unset($data[$key]);
                    unset($values[$key]);
                }
            }
            $db->table('finance_settlement_supplements')->updateOrInsert(['finance_record_id' => $record->id], [
                'payload' => json_encode([...$data, ...$values], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                'updated_by' => $actor, 'created_at' => $existing?->created_at ?? now(), 'updated_at' => now(),
            ]);
        });
    }
}
