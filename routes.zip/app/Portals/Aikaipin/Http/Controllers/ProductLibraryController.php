<?php

namespace App\Portals\Aikaipin\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use App\Models\AikaipinPlacementEvaluation;
use App\Models\AikaipinPlacementEvaluationRecord;
use App\Models\AikaipinProduct;
use App\Models\AikaipinProductPage;
use App\Models\AikaipinProductUploadSession;
use App\Models\AikaipinSelectionProposal;
use App\Models\AikaipinSelectionProposalImage;
use App\Models\AikaipinSelectionProposalTag;
use App\Models\OperationAiProductReferenceVideo;
use App\Portal\Http\Controllers\PortalEntryController;
use App\Portals\Aikaipin\AikaipinHistoricalVideoImporter;
use App\Portals\Aikaipin\AikaipinPortalAuthorizationService;
use App\Portals\Aikaipin\AikaipinProductLibraryStorageService;
use App\Portals\Aikaipin\AikaipinSelectionProposalStorageService;
use App\Portals\Operation\ShopifyProductCsvImporter;
use App\Services\AiProductListingPushService;
use App\Support\BrowserCompatibleVideoService;
use App\Support\PrivateVideoResponse;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Intervention\Image\Drivers\Gd\Driver as GdDriver;
use Intervention\Image\ImageManager;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class ProductLibraryController extends Controller
{
    private const PRODUCT_CATEGORY_OPTIONS_CACHE_KEY = 'aikaipin:product-library:category-options:v1';
    private const REFERENCE_FILE_MAX_KILOBYTES = 262144;

    public function __construct(
        private readonly PortalEntryController $portalEntries,
        private readonly AikaipinPortalAuthorizationService $authorization,
        private readonly AikaipinProductLibraryStorageService $storage,
        private readonly AikaipinSelectionProposalStorageService $selectionProposalStorage,
        private readonly ShopifyProductCsvImporter $shopifyCsvImporter,
        private readonly AiProductListingPushService $listingPush,
        private readonly BrowserCompatibleVideoService $browserCompatibleVideo,
        private readonly PrivateVideoResponse $privateVideoResponse,
        private readonly AikaipinHistoricalVideoImporter $historicalVideoImporter,
    ) {}

    public function index(Request $request): Response|View
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $canManageProductLibrary = $this->authorization->canManageProductLibrary($context['user']);
        $filters = $this->productFilters($request);

        return view('portals.aikaipin.product-library.index', [
            ...$context,
            'products' => $this->productQuery($context['user'], $canManageProductLibrary, $filters)
                ->paginate(15)
                ->withQueryString(),
            'filters' => $filters,
            'categories' => $this->productCategoryOptions(),
            'canManageProductLibrary' => $canManageProductLibrary,
            'operationVisibilitySource' => $this->authorization->operationVisibilitySource(),
            'quickAuthorizationDepartments' => $this->authorization->quickAuthorizationDepartments(),
        ]);
    }

    public function initializePackageUpload(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        $data = $request->validate([
            'client_fingerprint' => ['required', 'string', 'size:64'],
            'original_name' => ['required', 'string', 'max:255'],
            'mime_type' => ['nullable', 'string', 'max:191'],
            // The shared chunk endpoint also receives material videos, whose
            // documented single-file limit is 300 MB. The final save action
            // still applies the stricter reference/package limits.
            'total_size' => ['required', 'integer', 'min:1', 'max:314572800'],
            'total_chunks' => ['required', 'integer', 'min:1'],
        ]);
        $expectedChunks = (int) ceil((int) $data['total_size'] / AikaipinProductLibraryStorageService::PACKAGE_CHUNK_SIZE);

        if ((int) $data['total_chunks'] !== $expectedChunks) {
            throw ValidationException::withMessages([
                'total_chunks' => __('aikaipin.messages.package_upload_invalid_message'),
            ]);
        }

        $session = AikaipinProductUploadSession::query()
            ->where('user_id', $context['user']->getKey())
            ->where('client_fingerprint', $data['client_fingerprint'])
            ->first();

        $completedUploadIsMissing = $session !== null
            && $session->status === AikaipinProductUploadSession::STATUS_COMPLETED
            && (! $session->assembled_path
                || ! Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($session->assembled_path)
                || (int) Storage::disk(AikaipinProductLibraryStorageService::DISK)->size($session->assembled_path) !== (int) $session->total_size);

        if ($session !== null && ($session->status === AikaipinProductUploadSession::STATUS_CONSUMED
            || $completedUploadIsMissing
            || $session->expires_at?->isPast()
            || (int) $session->total_size !== (int) $data['total_size']
            || (int) $session->total_chunks !== (int) $data['total_chunks']
            || $session->original_name !== $data['original_name'])) {
            $this->deleteUploadSession($session);
            $session = null;
        }

        if ($session === null) {
            $uploadToken = (string) Str::uuid();
            $session = AikaipinProductUploadSession::create([
                'upload_token' => $uploadToken,
                'user_id' => (int) $context['user']->getKey(),
                'client_fingerprint' => $data['client_fingerprint'],
                'original_name' => $data['original_name'],
                'mime_type' => $data['mime_type'] ?: null,
                'total_size' => (int) $data['total_size'],
                'total_chunks' => (int) $data['total_chunks'],
                'disk' => AikaipinProductLibraryStorageService::DISK,
                'temporary_directory' => $this->storage->newTemporaryDirectory($uploadToken),
                'status' => AikaipinProductUploadSession::STATUS_UPLOADING,
                'expires_at' => now()->addDay(),
            ]);
        }

        return response()->json($this->packageSessionPayload($session));
    }

    public function storePackageUploadPart(Request $request, string $uploadToken, int $chunkIndex): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        $session = $this->uploadSessionForUser($context['user'], $uploadToken);
        $data = $request->validate([
            'chunk' => ['required', 'file'],
        ]);

        if ($session->status !== AikaipinProductUploadSession::STATUS_UPLOADING
            || $session->expires_at?->isPast()
            || $chunkIndex < 0
            || $chunkIndex >= (int) $session->total_chunks) {
            throw ValidationException::withMessages([
                'chunk' => __('aikaipin.messages.package_upload_invalid_message'),
            ]);
        }

        /** @var UploadedFile $chunk */
        $chunk = $data['chunk'];
        $remaining = (int) $session->total_size - ($chunkIndex * AikaipinProductLibraryStorageService::PACKAGE_CHUNK_SIZE);
        $expectedSize = min(AikaipinProductLibraryStorageService::PACKAGE_CHUNK_SIZE, $remaining);

        if ($chunk->getSize() !== $expectedSize) {
            throw ValidationException::withMessages([
                'chunk' => __('aikaipin.messages.package_upload_invalid_message'),
            ]);
        }

        $this->storage->storeUploadPart($session, $chunkIndex, $chunk);
        $session->forceFill([
            'received_size' => (int) $session->parts()->sum('size'),
            'expires_at' => now()->addDay(),
        ])->save();

        return response()->json($this->packageSessionPayload($session->refresh()));
    }

    public function completePackageUpload(Request $request, string $uploadToken): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        $session = $this->uploadSessionForUser($context['user'], $uploadToken);

        if ($session->status === AikaipinProductUploadSession::STATUS_COMPLETED && $session->assembled_path) {
            return response()->json($this->packageSessionPayload($session));
        }

        $parts = $session->parts()->orderBy('chunk_index')->get();
        $expectedIndexes = range(0, (int) $session->total_chunks - 1);
        if ($session->status !== AikaipinProductUploadSession::STATUS_UPLOADING
            || $session->expires_at?->isPast()
            || $parts->count() !== (int) $session->total_chunks
            || $parts->pluck('chunk_index')->map(static fn ($index): int => (int) $index)->all() !== $expectedIndexes) {
            throw ValidationException::withMessages([
                'package_upload_token' => __('aikaipin.messages.package_upload_incomplete_message'),
            ]);
        }

        try {
            $assembled = $this->storage->assembleUpload($session, $parts);
        } catch (\Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => __('aikaipin.messages.package_upload_assembly_failed_message'),
            ], 422);
        }

        $session->forceFill([
            'assembled_path' => $assembled['path'],
            'received_size' => $assembled['size'],
            'status' => AikaipinProductUploadSession::STATUS_COMPLETED,
            'expires_at' => now()->addDay(),
        ])->save();

        return response()->json($this->packageSessionPayload($session));
    }

    public function storeProduct(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        // Keep older cached upload forms compatible while the new multi-CSV UI
        // is rolling out.
        if (! $request->hasFile('shopify_csvs') && $request->hasFile('shopify_csv')) {
            $request->files->set('shopify_csvs', [$request->file('shopify_csv')]);
            $request->merge([
                'shopify_landing_page_urls' => [(string) $request->input('landing_page_url', '')],
            ]);
        }

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'source_platform' => ['required', 'in:shopify,shopline'],
            'product_type' => ['required', 'in:general,xiaohei'],
            'is_published' => ['required', 'boolean'],
            'landing_page_url' => ['nullable', 'url', 'max:2048'],
            'skus' => ['nullable', 'array'],
            'skus.*' => ['nullable', 'string', 'max:191', 'distinct'],
            'categories' => ['nullable', 'array'],
            'categories.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'images' => ['nullable', 'array', 'max:3'],
            'images.*' => ['file', 'image', 'max:20480'],
            'reference_file' => ['nullable', 'file', 'extensions:html,htm', 'max:'.self::REFERENCE_FILE_MAX_KILOBYTES],
            'reference_upload_token' => ['nullable', 'uuid'],
            'material_videos' => ['nullable', 'array'],
            'material_videos.*' => ['nullable', 'array', 'max:20'],
            'material_videos.*.*' => ['file', 'mimes:mp4,mov,avi,webm,mkv,m4v', 'max:307200'],
            'material_video_upload_tokens' => ['nullable', 'array:flow,traffic,remix'],
            'material_video_upload_tokens.*' => ['nullable', 'array', 'max:20'],
            'material_video_upload_tokens.*.*' => ['uuid', 'distinct'],
            'shopify_csvs' => ['required', 'array', 'min:1', 'max:10'],
            'shopify_csvs.*' => ['required', 'file', 'mimes:csv,txt', 'max:20480'],
            'shopify_landing_page_urls' => ['required', 'array', 'min:1', 'max:10'],
            'shopify_landing_page_urls.*' => ['required', 'url', 'max:2048'],
            'package_upload_token' => ['nullable', 'uuid'],
            'authorized_department_ids' => ['nullable', 'array'],
            'authorized_department_ids.*' => ['integer', 'distinct'],
        ], [
            'shopify_csvs.required' => '请选择至少一个 Shopify 商品 CSV 文件。',
            'shopify_csvs.*.mimes' => 'Shopify 商品文件只支持 CSV 格式。',
            'shopify_csvs.*.max' => '单个 Shopify 商品 CSV 文件不能超过 20 MB。',
            'shopify_landing_page_urls.*.required' => '每个 CSV 文件都必须填写对应的落地页链接。',
            'reference_file.max' => '参考页面文件不能超过 256 MB。',
        ]);
        $departmentIds = collect($data['authorized_department_ids'] ?? [])->map(static fn ($id): int => (int) $id)->unique()->values()->all();
        $skuValues = $this->normalizeProductValues($data['skus'] ?? []);
        $categories = $this->normalizeProductValues($data['categories'] ?? []);
        $shopifyFiles = array_values($data['shopify_csvs'] ?? []);
        $shopifyLandingUrls = array_values($data['shopify_landing_page_urls'] ?? []);
        if (count($shopifyFiles) !== count($shopifyLandingUrls)) {
            throw ValidationException::withMessages([
                'shopify_landing_page_urls' => 'CSV 文件数量与落地页链接数量不一致，请重新选择文件。',
            ]);
        }
        $shopifyImports = [];
        foreach ($shopifyFiles as $index => $shopifyFile) {
            /** @var UploadedFile $shopifyFile */
            try {
                $shopifyImports[] = [
                    'payload' => $this->shopifyCsvImporter->parse($shopifyFile->getRealPath()),
                    'source_name' => $shopifyFile->getClientOriginalName(),
                    'landing_page_url' => trim((string) $shopifyLandingUrls[$index]),
                ];
            } catch (\Throwable $exception) {
                throw ValidationException::withMessages([
                    'shopify_csvs.'.($index) => $shopifyFile->getClientOriginalName().'：'.$exception->getMessage(),
                ]);
            }
        }

        $availableDepartments = collect($this->authorization->quickAuthorizationDepartments())->keyBy('id');
        if (collect($departmentIds)->diff($availableDepartments->keys())->isNotEmpty()) {
            throw ValidationException::withMessages([
                'authorized_department_ids' => __('aikaipin.messages.product_authorization_invalid_message'),
            ]);
        }

        $createdPaths = [];
        $completedMaterialSessions = [];
        $product = null;

        try {
            $connection = config('admin.database.connection') ?: config('database.default');
            $product = DB::connection($connection)->transaction(function () use ($context, $data, $categories, $departmentIds, $skuValues, $shopifyImports, &$createdPaths, &$completedMaterialSessions): AikaipinProduct {
                $session = null;
                $referenceSession = null;
                if (filled($data['package_upload_token'] ?? null)) {
                    $session = $this->uploadSessionForUser($context['user'], (string) $data['package_upload_token'], true);
                    if ($session->status !== AikaipinProductUploadSession::STATUS_COMPLETED
                        || ! $session->assembled_path
                        || ! Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($session->assembled_path)
                        || (int) $session->total_size > 256 * 1024 * 1024) {
                        throw ValidationException::withMessages([
                            'package_upload_token' => __('aikaipin.messages.package_upload_incomplete_message'),
                        ]);
                    }
                }
                if (filled($data['reference_upload_token'] ?? null)) {
                    $referenceSession = $this->uploadSessionForUser($context['user'], (string) $data['reference_upload_token'], true);
                    $extension = strtolower(pathinfo((string) $referenceSession->original_name, PATHINFO_EXTENSION));
                    if ($referenceSession->status !== AikaipinProductUploadSession::STATUS_COMPLETED
                        || ! $referenceSession->assembled_path
                        || ! Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($referenceSession->assembled_path)
                        || (int) $referenceSession->total_size > self::REFERENCE_FILE_MAX_KILOBYTES * 1024
                        || ! in_array($extension, ['html', 'htm'], true)) {
                        throw ValidationException::withMessages([
                            'reference_upload_token' => '参考页面文件上传不完整或格式不正确，请重新上传。',
                        ]);
                    }
                }

                $product = AikaipinProduct::create([
                    'product_code' => $this->temporaryProductCode(),
                    'name' => trim((string) $data['name']),
                    'sku' => $this->joinProductValues($skuValues),
                    'categories' => $categories === [] ? null : $categories,
                    'source_platform' => $data['source_platform'],
                    'product_type' => $data['product_type'],
                    'is_published' => (bool) $data['is_published'],
                    'landing_page_url' => $shopifyImports[0]['landing_page_url'] ?? (($data['landing_page_url'] ?? null) ?: null),
                    'visible_department_ids' => $departmentIds === [] ? null : $departmentIds,
                    'created_by' => (int) $context['user']->getKey(),
                    'created_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ]);

                $images = [];

                foreach (array_values($data['images'] ?? []) as $image) {
                    /** @var UploadedFile $image */
                    $imagePayload = $this->storage->storeUploadedFile($image, 'images');
                    $createdPaths[] = $imagePayload['path'];
                    $images[] = $this->productFilePayload($imagePayload);
                }

                $referenceFile = null;
                if ($referenceSession !== null) {
                    $referencePayload = $this->storage->copyStoredFile($referenceSession->assembled_path, 'references', $referenceSession->original_name, $referenceSession->mime_type);
                    $createdPaths[] = $referencePayload['path'];
                    $referenceFile = $this->productFilePayload($referencePayload);
                } elseif (($data['reference_file'] ?? null) instanceof UploadedFile) {
                    /** @var UploadedFile $referenceFile */
                    $referenceFile = $data['reference_file'];
                    $referencePayload = $this->storage->storeUploadedFile($referenceFile, 'references');
                    $createdPaths[] = $referencePayload['path'];
                    $referenceFile = $this->productFilePayload($referencePayload);
                }

                $packageFile = null;
                if ($session !== null) {
                    $packagePayload = $this->storage->copyStoredFile($session->assembled_path, 'packages', $session->original_name, $session->mime_type);
                    $createdPaths[] = $packagePayload['path'];
                    $packageFile = $this->productFilePayload($packagePayload);
                }
                if ($referenceSession !== null) {
                    $referenceSession->forceFill([
                        'status' => AikaipinProductUploadSession::STATUS_CONSUMED,
                        'expires_at' => now()->addHour(),
                    ])->save();
                }

                $product->forceFill([
                    'product_code' => $this->productCodeForId((int) $product->getKey()),
                    'images' => $images === [] ? null : $images,
                    'reference_file' => $referenceFile,
                    'package_file' => $packageFile,
                ])->save();

                foreach ($shopifyImports as $shopifyImport) {
                    $shopifyPayload = (array) $shopifyImport['payload'];
                    $shopifySourceName = (string) $shopifyImport['source_name'];
                    $product = $this->shopifyCsvImporter->supplement(
                        $product,
                        $shopifyPayload,
                        $shopifySourceName,
                        $shopifySourceName,
                        trim((string) ($shopifyPayload['title'] ?? '')),
                        $context['user'],
                        (string) $shopifyImport['landing_page_url'],
                    );
                }

                $materialVideos = (array) ($data['material_videos'] ?? []);
                $chunkedMaterialVideos = $this->materialVideoFilesFromUploadTokens(
                    (array) ($data['material_video_upload_tokens'] ?? []),
                    $context['user'],
                    $completedMaterialSessions,
                );
                foreach ($chunkedMaterialVideos as $type => $files) {
                    $materialVideos[$type] = [...(array) ($materialVideos[$type] ?? []), ...$files];
                }
                $this->storeMaterialVideos($product, $materialVideos, $context['user'], $createdPaths);

                if ($session !== null) {
                    $session->forceFill([
                        'status' => AikaipinProductUploadSession::STATUS_CONSUMED,
                        'expires_at' => now()->addHour(),
                    ])->save();
                }

                return $product;
            });
        } catch (ValidationException $exception) {
            foreach (array_unique($createdPaths) as $path) {
                $this->storage->deleteFile($path);
            }
            throw $exception;
        } catch (\Throwable $exception) {
            foreach ($createdPaths as $path) {
                $this->storage->deleteFile($path);
            }
            report($exception);

            return response()->json([
                'message' => __('aikaipin.messages.product_save_failed_message'),
            ], 500);
        }

        $completedSession = filled($data['package_upload_token'] ?? null)
            ? AikaipinProductUploadSession::query()->where('upload_token', $data['package_upload_token'])->first()
            : null;
        if ($completedSession !== null) {
            try {
                $this->deleteUploadSession($completedSession);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        $completedReferenceSession = filled($data['reference_upload_token'] ?? null)
            ? AikaipinProductUploadSession::query()->where('upload_token', $data['reference_upload_token'])->first()
            : null;
        if ($completedReferenceSession !== null) {
            try {
                $this->deleteUploadSession($completedReferenceSession);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        $this->deleteCompletedUploadSessions($completedMaterialSessions);
        $videoImport = $this->importReferenceVideosToTable($product);
        Cache::forget(self::PRODUCT_CATEGORY_OPTIONS_CACHE_KEY);
        if ($product?->is_published) {
            $this->listingPush->notifyDepartmentManagers($product, $context['user']);
        }

        return response()->json([
            'message' => $this->productSaveMessage(__('aikaipin.messages.product_created_message'), $videoImport),
            'redirect_url' => route('aikaipin.product-library.index'),
            'product_id' => $product?->getKey(),
            'video_import' => $videoImport,
        ], 201);
    }

    public function editProduct(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        return response()->json($this->productEditPayload($product));
    }

    public function viewProduct(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewProduct($context['user'], $product), 403);

        return response()->json([
            'id' => (int) $product->getKey(),
            'product_code' => (string) $product->product_code,
            'name' => (string) $product->name,
            'reference_url' => $product->referenceFilePayload()
                ? route('aikaipin.product-library.reference-preview', ['product' => $product]) : null,
            'material_videos' => $this->materialVideoPayloads($product),
        ]);
    }

    public function previewShopifyImport(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }
        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        $data = $request->validate([
            'shopify_csv' => ['required', 'file', 'mimes:csv,txt', 'max:20480'],
            'page_name' => ['nullable', 'string', 'max:255'],
            'landing_page_url' => ['required', 'url', 'max:2048'],
        ], [
            'shopify_csv.required' => '请选择 Shopify 导出的 CSV 商品文件。',
            'shopify_csv.mimes' => '只支持 CSV 文件。',
            'shopify_csv.max' => 'CSV 文件不能超过 20 MB。',
        ]);
        /** @var UploadedFile $file */
        $file = $data['shopify_csv'];

        try {
            $payload = $this->shopifyCsvImporter->parse($file->getRealPath());
        } catch (\Throwable $exception) {
            return response()->json(['message' => $exception->getMessage()], 422);
        }

        $existingSkus = collect($product->skuValues())->map(fn (string $sku): string => mb_strtolower($sku))->flip();
        $matchedSkus = collect($payload['variants'] ?? [])->pluck('sku')
            ->filter(fn (mixed $sku): bool => $existingSkus->has(mb_strtolower(trim((string) $sku))))
            ->values()->all();
        if ($matchedSkus === []) {
            return response()->json([
                'message' => 'CSV 中没有任何 SKU 与当前产品匹配，请确认选择了正确的产品和文件。',
            ], 422);
        }

        $token = (string) Str::uuid();
        Cache::put($this->shopifyImportCacheKey($token), [
            'user_id' => (int) $context['user']->getKey(),
            'product_id' => (int) $product->getKey(),
            'file_name' => $file->getClientOriginalName(),
            'page_name' => trim((string) ($data['page_name'] ?? '')),
            'landing_page_url' => trim((string) $data['landing_page_url']),
            'payload' => $payload,
        ], now()->addMinutes(20));

        return response()->json([
            'preview_token' => $token,
            'product' => ['id' => (int) $product->getKey(), 'code' => $product->product_code, 'name' => $product->name],
            'shopify' => $this->shopifyImportPayload($payload),
            'matched_skus' => $matchedSkus,
        ]);
    }

    public function importShopifyCsv(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }
        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        $data = $request->validate([
            'preview_token' => ['required', 'uuid'],
            'page_name' => ['nullable', 'string', 'max:255'],
            'landing_page_url' => ['required', 'url', 'max:2048'],
        ]);
        $preview = Cache::pull($this->shopifyImportCacheKey($data['preview_token']));
        if (! is_array($preview)
            || (int) ($preview['user_id'] ?? 0) !== (int) $context['user']->getKey()
            || (int) ($preview['product_id'] ?? 0) !== (int) $product->getKey()) {
            return response()->json(['message' => '预览已过期，请重新选择 CSV 文件。'], 422);
        }

        $updated = $this->shopifyCsvImporter->supplement(
            $product,
            (array) ($preview['payload'] ?? []),
            (string) ($preview['file_name'] ?? 'products.csv'),
            (string) ($preview['file_name'] ?? 'products.csv'),
            trim((string) ($data['page_name'] ?? $preview['page_name'] ?? '')),
            $context['user'],
            trim((string) ($data['landing_page_url'] ?? $preview['landing_page_url'] ?? '')),
        );
        $productPage = $updated->productPages->first();
        $shopify = $this->shopifyImportPayload($productPage?->shopifyData() ?? $updated->shopifyData());

        return response()->json([
            'message' => "产品页资料新增成功，当前共有 {$updated->productPages->count()} 份；本次包含 {$shopify['variant_count']} 个规格、{$shopify['image_count']} 张图片。",
            'redirect_url' => route('aikaipin.product-library.index'),
            'shopify_data' => $shopify,
            'product_page_id' => $productPage?->getKey(),
            'product_page_count' => $updated->productPages->count(),
        ]);
    }

    public function updateProductPage(Request $request, AikaipinProduct $product, AikaipinProductPage $page): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        abort_unless((int) $page->aikaipin_product_id === (int) $product->getKey(), 404);

        $data = $request->validate([
            'landing_page_url' => ['nullable', 'url', 'max:2048'],
        ]);
        $landingPageUrl = trim((string) ($data['landing_page_url'] ?? '')) ?: null;

        $page->forceFill(['landing_page_url' => $landingPageUrl])->save();

        return response()->json([
            'message' => '产品页落地页链接已保存。',
            'product_page' => [
                'id' => (int) $page->getKey(),
                'landing_page_url' => $page->landing_page_url,
            ],
        ]);
    }

    public function destroyProductPage(Request $request, AikaipinProduct $product, AikaipinProductPage $page): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        abort_unless((int) $page->aikaipin_product_id === (int) $product->getKey(), 404);

        DB::connection($product->getConnectionName())->transaction(function () use ($product, $page): void {
            $page->delete();

            $replacement = $product->productPages()->first();
            if ($replacement instanceof AikaipinProductPage) {
                $product->productPages()->update(['is_default' => false]);
                $replacement->forceFill(['is_default' => true])->save();
                $product->forceFill(['shopify_data' => $replacement->shopifyData()])->save();
            } else {
                $product->forceFill(['shopify_data' => null])->save();
            }
        });

        $product->refresh()->load('productPages');
        $payload = $this->productEditPayload($product);

        return response()->json([
            'message' => '产品 CSV 及其对应的产品页资料已删除。',
            'product_page_count' => $product->productPages->count(),
            'product_pages' => $payload['product_pages'],
            'shopify_data' => $payload['shopify_data'],
        ]);
    }

    public function updateProduct(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'source_platform' => ['required', 'in:shopify,shopline'],
            'product_type' => ['required', 'in:general,xiaohei'],
            'is_published' => ['required', 'boolean'],
            'landing_page_url' => ['nullable', 'url', 'max:2048'],
            'skus' => ['nullable', 'array'],
            'skus.*' => ['nullable', 'string', 'max:191', 'distinct'],
            'categories' => ['nullable', 'array'],
            'categories.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'images' => ['nullable', 'array'],
            'images.*' => ['file', 'image', 'max:20480'],
            'remove_image_indexes' => ['nullable', 'array'],
            'remove_image_indexes.*' => ['integer', 'min:0', 'distinct'],
            'reference_file' => ['nullable', 'file', 'extensions:html,htm', 'max:'.self::REFERENCE_FILE_MAX_KILOBYTES],
            'reference_upload_token' => ['nullable', 'uuid'],
            'material_videos' => ['nullable', 'array'],
            'material_videos.*' => ['nullable', 'array', 'max:20'],
            'material_videos.*.*' => ['file', 'mimes:mp4,mov,avi,webm,mkv,m4v', 'max:307200'],
            'material_video_upload_tokens' => ['nullable', 'array:flow,traffic,remix'],
            'material_video_upload_tokens.*' => ['nullable', 'array', 'max:20'],
            'material_video_upload_tokens.*.*' => ['uuid', 'distinct'],
            'remove_material_video_ids' => ['nullable', 'array', 'max:200'],
            'remove_material_video_ids.*' => ['integer', 'min:1', 'distinct'],
            'remove_history_video_indexes' => ['nullable', 'array', 'max:500'],
            'remove_history_video_indexes.*' => ['integer', 'min:0', 'distinct'],
            'package_upload_token' => ['nullable', 'uuid'],
            'authorized_department_ids' => ['nullable', 'array'],
            'authorized_department_ids.*' => ['integer', 'distinct'],
        ], [
            'reference_file.max' => '参考页面文件不能超过 256 MB。',
        ]);
        $departmentIds = collect($data['authorized_department_ids'] ?? [])->map(static fn ($id): int => (int) $id)->unique()->values()->all();
        $skuValues = $this->normalizeProductValues($data['skus'] ?? []);
        $categories = $this->normalizeProductValues($data['categories'] ?? []);
        $removedImageIndexes = collect($data['remove_image_indexes'] ?? [])->map(static fn ($id): int => (int) $id)->unique()->sort()->values()->all();
        $removedMaterialVideoIds = collect($data['remove_material_video_ids'] ?? [])->map(static fn ($id): int => (int) $id)->unique()->values()->all();
        $removedHistoryVideoIndexes = collect($data['remove_history_video_indexes'] ?? [])->map(static fn ($index): int => (int) $index)->unique()->sort()->values()->all();

        $availableDepartments = collect($this->authorization->quickAuthorizationDepartments())->keyBy('id');
        if (collect($departmentIds)->diff($availableDepartments->keys())->isNotEmpty()) {
            throw ValidationException::withMessages([
                'authorized_department_ids' => __('aikaipin.messages.product_authorization_invalid_message'),
            ]);
        }

        $existingImages = $product->imageFiles();
        if (collect($removedImageIndexes)->contains(static fn (int $index): bool => ! array_key_exists($index, $existingImages))) {
            throw ValidationException::withMessages([
                'remove_image_indexes' => __('aikaipin.messages.product_image_invalid_message'),
            ]);
        }
        if ($removedHistoryVideoIndexes !== []) {
            $visibleHistoryIndexes = collect($this->historicalReferenceVideoPayloads($product))
                ->pluck('history_index')
                ->map(static fn ($index): int => (int) $index);
            if (collect($removedHistoryVideoIndexes)->diff($visibleHistoryIndexes)->isNotEmpty()) {
                throw ValidationException::withMessages([
                    'remove_history_video_indexes' => '存在无效的历史视频，请刷新页面后重试。',
                ]);
            }
        }

        $remainingImageCount = count($existingImages) - count($removedImageIndexes);
        $newImages = array_values($data['images'] ?? []);
        if ($remainingImageCount + count($newImages) > 3) {
            throw ValidationException::withMessages([
                'images' => __('aikaipin.messages.image_limit_message'),
            ]);
        }

        $createdPaths = [];
        $obsoletePaths = [];
        $completedSession = null;
        $completedReferenceSession = null;
        $completedMaterialSessions = [];
        $referenceReplaced = false;

        try {
            $connection = config('admin.database.connection') ?: config('database.default');
            DB::connection($connection)->transaction(function () use ($context, $product, $data, $categories, $departmentIds, $skuValues, $removedImageIndexes, $removedMaterialVideoIds, $newImages, &$createdPaths, &$obsoletePaths, &$completedSession, &$completedReferenceSession, &$completedMaterialSessions, &$referenceReplaced): void {
                $images = $product->imageFiles();
                foreach (array_reverse($removedImageIndexes) as $index) {
                    $removedFile = $images[$index] ?? null;
                    if ($removedFile !== null) {
                        $obsoletePaths[] = $removedFile['path'];
                        unset($images[$index]);
                    }
                }
                $images = array_values($images);

                foreach ($newImages as $image) {
                    /** @var UploadedFile $image */
                    $imagePayload = $this->storage->storeUploadedFile($image, 'images');
                    $createdPaths[] = $imagePayload['path'];
                    $images[] = $this->productFilePayload($imagePayload);
                }

                $referenceFile = $product->referenceFilePayload();
                if ($data['reference_upload_token'] ?? null) {
                    $referenceSession = $this->uploadSessionForUser($context['user'], (string) $data['reference_upload_token'], true);
                    $extension = strtolower(pathinfo((string) $referenceSession->original_name, PATHINFO_EXTENSION));
                    if ($referenceSession->status !== AikaipinProductUploadSession::STATUS_COMPLETED
                        || ! $referenceSession->assembled_path
                        || ! Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($referenceSession->assembled_path)
                        || (int) $referenceSession->total_size > self::REFERENCE_FILE_MAX_KILOBYTES * 1024
                        || ! in_array($extension, ['html', 'htm'], true)) {
                        throw ValidationException::withMessages([
                            'reference_upload_token' => '参考页面文件上传不完整或格式不正确，请重新上传。',
                        ]);
                    }
                    $referencePayload = $this->storage->copyStoredFile($referenceSession->assembled_path, 'references', $referenceSession->original_name, $referenceSession->mime_type);
                    $createdPaths[] = $referencePayload['path'];
                    if ($referenceFile !== null) {
                        array_push($obsoletePaths, ...$this->referenceFilePaths($referenceFile['path']));
                    }
                    $referenceFile = $this->productFilePayload($referencePayload);
                    $referenceReplaced = true;
                    $referenceSession->forceFill([
                        'status' => AikaipinProductUploadSession::STATUS_CONSUMED,
                        'expires_at' => now()->addHour(),
                    ])->save();
                    $completedReferenceSession = $referenceSession;
                } elseif (($data['reference_file'] ?? null) instanceof UploadedFile) {
                    /** @var UploadedFile $uploadedReferenceFile */
                    $uploadedReferenceFile = $data['reference_file'];
                    $referencePayload = $this->storage->storeUploadedFile($uploadedReferenceFile, 'references');
                    $createdPaths[] = $referencePayload['path'];
                    if ($referenceFile !== null) {
                        array_push($obsoletePaths, ...$this->referenceFilePaths($referenceFile['path']));
                    }
                    $referenceFile = $this->productFilePayload($referencePayload);
                    $referenceReplaced = true;
                }

                if ($referenceReplaced) {
                    $historicalVideos = OperationAiProductReferenceVideo::query()
                        ->where('aikaipin_product_id', $product->getKey())
                        ->where('source_kind', OperationAiProductReferenceVideo::SOURCE_HISTORICAL_HTML)
                        ->lockForUpdate()
                        ->get();
                    foreach ($historicalVideos as $historicalVideo) {
                        $obsoletePaths[] = $historicalVideo->path;
                        $historicalVideo->delete();
                    }
                }

                $packageFile = $product->packageFilePayload();
                if ($data['package_upload_token'] ?? null) {
                    $session = $this->uploadSessionForUser($context['user'], (string) $data['package_upload_token'], true);
                    if ($session->status !== AikaipinProductUploadSession::STATUS_COMPLETED
                        || ! $session->assembled_path
                        || ! Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($session->assembled_path)
                        || (int) $session->total_size > 256 * 1024 * 1024) {
                        throw ValidationException::withMessages([
                            'package_upload_token' => __('aikaipin.messages.package_upload_incomplete_message'),
                        ]);
                    }

                    $packagePayload = $this->storage->copyStoredFile($session->assembled_path, 'packages', $session->original_name, $session->mime_type);
                    $createdPaths[] = $packagePayload['path'];
                    if ($packageFile !== null) {
                        $obsoletePaths[] = $packageFile['path'];
                    }
                    $packageFile = $this->productFilePayload($packagePayload);
                    $session->forceFill([
                        'status' => AikaipinProductUploadSession::STATUS_CONSUMED,
                        'expires_at' => now()->addHour(),
                    ])->save();
                    $completedSession = $session;
                }

                $product->forceFill([
                    'name' => trim((string) $data['name']),
                    'sku' => $this->joinProductValues($skuValues),
                    'categories' => $categories === [] ? null : $categories,
                    'source_platform' => $data['source_platform'],
                    'product_type' => $data['product_type'],
                    'is_published' => (bool) $data['is_published'],
                    'landing_page_url' => $data['landing_page_url'] ?: null,
                    'images' => $images === [] ? null : $images,
                    'reference_file' => $referenceFile,
                    'package_file' => $packageFile,
                    'visible_department_ids' => $departmentIds === [] ? null : $departmentIds,
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ])->save();

                // Store newly selected files before deleting existing rows so the
                // filename sequence never reuses a number that was already shown.
                $materialVideos = (array) ($data['material_videos'] ?? []);
                $chunkedMaterialVideos = $this->materialVideoFilesFromUploadTokens(
                    (array) ($data['material_video_upload_tokens'] ?? []),
                    $context['user'],
                    $completedMaterialSessions,
                );
                foreach ($chunkedMaterialVideos as $type => $files) {
                    $materialVideos[$type] = [...(array) ($materialVideos[$type] ?? []), ...$files];
                }
                $this->storeMaterialVideos($product, $materialVideos, $context['user'], $createdPaths);

                if ($removedMaterialVideoIds !== []) {
                    $removedVideos = OperationAiProductReferenceVideo::query()
                        ->where('aikaipin_product_id', $product->getKey())
                        ->whereIn('id', $removedMaterialVideoIds)
                        ->lockForUpdate()
                        ->get();
                    if ($removedVideos->count() !== count($removedMaterialVideoIds)) {
                        throw ValidationException::withMessages([
                            'remove_material_video_ids' => '存在无效的素材视频，请刷新页面后重试。',
                        ]);
                    }
                    foreach ($removedVideos as $removedVideo) {
                        $obsoletePaths[] = $removedVideo->path;
                        $removedVideo->delete();
                    }
                }

            });
        } catch (ValidationException $exception) {
            foreach (array_unique($createdPaths) as $path) {
                $this->storage->deleteFile($path);
            }
            throw $exception;
        } catch (\Throwable $exception) {
            foreach ($createdPaths as $path) {
                $this->storage->deleteFile($path);
            }
            report($exception);

            return response()->json([
                'message' => __('aikaipin.messages.product_save_failed_message'),
            ], 500);
        }

        $createdPathLookup = array_fill_keys(array_unique($createdPaths), true);
        foreach (array_unique($obsoletePaths) as $path) {
            // A replacement must never delete the file that was just stored.
            // The UUID directory below makes a collision practically
            // impossible; this guard also protects data created by older code.
            if (isset($createdPathLookup[$path])) {
                continue;
            }
            try {
                $this->storage->deleteFile($path);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        if ($removedHistoryVideoIndexes !== []
            && ! ($data['reference_upload_token'] ?? null)
            && ! (($data['reference_file'] ?? null) instanceof UploadedFile)) {
            try {
                $this->hideHistoricalReferenceVideos($product, $removedHistoryVideoIndexes);
            } catch (\Throwable $exception) {
                report($exception);

                return response()->json([
                    'message' => '产品已保存，但历史 HTML 视频隐藏失败，请刷新后重试。',
                ], 500);
            }
        }
        if ($completedSession !== null) {
            try {
                $this->deleteUploadSession($completedSession);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        if ($completedReferenceSession !== null) {
            try {
                $this->deleteUploadSession($completedReferenceSession);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        $this->deleteCompletedUploadSessions($completedMaterialSessions);
        $videoImport = $this->importReferenceVideosToTable($product);
        Cache::forget(self::PRODUCT_CATEGORY_OPTIONS_CACHE_KEY);

        return response()->json([
            'message' => $this->productSaveMessage(__('aikaipin.messages.product_updated_message'), $videoImport),
            'redirect_url' => route('aikaipin.product-library.index'),
            'product_id' => $product->getKey(),
            'video_import' => $videoImport,
        ]);
    }

    public function destroyProduct(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        $data = $request->validate([
            'confirm_linked_evaluations' => ['nullable', 'boolean'],
        ]);
        $linkedEvaluations = AikaipinPlacementEvaluation::query()
            ->where('product_id', $product->getKey())
            ->orderBy('id')
            ->get(['id', 'evaluation_code']);

        if ($linkedEvaluations->isNotEmpty() && ! ($data['confirm_linked_evaluations'] ?? false)) {
            return response()->json([
                'code' => 'product_has_linked_placement_evaluations',
                'message' => __('aikaipin.messages.product_delete_linked_message', [
                    'count' => $linkedEvaluations->count(),
                ]),
                'linked_evaluations' => $linkedEvaluations->map(static fn (AikaipinPlacementEvaluation $evaluation): array => [
                    'id' => (int) $evaluation->getKey(),
                    'code' => (string) $evaluation->evaluation_code,
                ])->values()->all(),
            ], 409);
        }

        $filePaths = collect($product->imageFiles())
            ->concat([$product->referenceFilePayload(), $product->packageFilePayload()])
            ->filter()
            ->pluck('path')
            ->filter()
            ->unique()
            ->values()
            ->all();
        $connection = config('admin.database.connection') ?: config('database.default');

        try {
            DB::connection($connection)->transaction(function () use ($context, $product): void {
                AikaipinPlacementEvaluation::query()
                    ->where('product_id', $product->getKey())
                    ->update([
                        'product_id' => null,
                        'updated_by' => (int) $context['user']->getKey(),
                        'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                        'updated_at' => now(),
                    ]);
                $product->delete();
            });
        } catch (\Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => __('aikaipin.messages.product_delete_failed_message'),
            ], 500);
        }

        foreach ($filePaths as $path) {
            try {
                $this->storage->deleteFile($path);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }
        Cache::forget(self::PRODUCT_CATEGORY_OPTIONS_CACHE_KEY);

        return response()->json([
            'message' => __('aikaipin.messages.product_deleted_message'),
            'redirect_url' => route('aikaipin.product-library.index'),
        ]);
    }

    public function updateVisibility(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        $data = $request->validate([
            'action' => ['required', 'in:enable,cancel'],
            'product_ids' => ['required', 'array', 'min:1'],
            'product_ids.*' => ['integer', 'distinct'],
        ]);
        $productIds = collect($data['product_ids'])->map(static fn ($id): int => (int) $id)->unique()->values()->all();
        $products = AikaipinProduct::query()->whereKey($productIds)->get();
        if ($products->count() !== count($productIds)) {
            throw ValidationException::withMessages([
                'product_ids' => __('aikaipin.messages.product_selection_invalid_message'),
            ]);
        }

        $departmentIds = collect($this->authorization->quickAuthorizationDepartments())->pluck('id')->map(static fn ($id): int => (int) $id)->all();
        foreach ($products as $product) {
            $currentDepartmentIds = $product->visibleDepartmentIds();

            if ($data['action'] === 'enable') {
                $updatedDepartmentIds = collect([...$currentDepartmentIds, ...$departmentIds])
                    ->map(static fn ($id): int => (int) $id)
                    ->filter(static fn (int $id): bool => $id > 0)
                    ->unique()
                    ->values()
                    ->all();
            } else {
                $updatedDepartmentIds = collect($currentDepartmentIds)
                    ->reject(static fn (int $id): bool => in_array($id, $departmentIds, true))
                    ->values()
                    ->all();
            }

            $product->forceFill([
                'visible_department_ids' => $updatedDepartmentIds === [] ? null : $updatedDepartmentIds,
            ])->save();
        }

        return response()->json([
            'message' => $data['action'] === 'enable'
                ? __('aikaipin.messages.visibility_enabled_message', ['count' => count($productIds)])
                : __('aikaipin.messages.visibility_cancelled_message', ['count' => count($productIds)]),
        ]);
    }

    public function updatePublication(Request $request, AikaipinProduct $product): RedirectResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) return $context;
        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);

        $data = $request->validate(['is_published' => ['required', 'boolean']]);
        $published = (bool) $data['is_published'];
        $product->forceFill([
            'is_published' => $published,
            'updated_by' => $context['user']->getKey(),
            'updated_by_name' => $context['user']->name ?: $context['user']->username,
        ])->save();
        if ($published) {
            $this->listingPush->notifyDepartmentManagers($product, $context['user']);
        }

        return back()->with('success', $published ? '商品已上架，订阅运营系统现在可以查看。' : '商品已下架，订阅运营系统将不再显示。');
    }

    public function showProductImage(Request $request, AikaipinProduct $product, int $imageIndex): Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewProduct($context['user'], $product), 403);

        $file = $product->imageFiles()[$imageIndex] ?? null;
        abort_unless($file !== null, 404);

        if ($request->boolean('thumb')) {
            try {
                $cacheKey = $file['sha256'] ?: sha1($file['path'].'|'.$file['size'].'|'.($product->updated_at?->getTimestamp() ?? 0));
                $thumbnailPath = 'aikaipin/product-thumbnails/'.$product->getKey().'/'.$imageIndex.'-'.$cacheKey.'.webp';
                $thumbnailDisk = Storage::disk('local');
                if (! $thumbnailDisk->exists($thumbnailPath)) {
                    $source = Storage::disk($file['disk'])->get($file['path']);
                    $image = (new ImageManager(new GdDriver()))->read($source);
                    $image->scaleDown(width: 180, height: 180);
                    $thumbnailDisk->put($thumbnailPath, (string) $image->toWebp(78));
                }

                return response($thumbnailDisk->get($thumbnailPath), 200, [
                    'Content-Type' => 'image/webp',
                    'Cache-Control' => 'private, max-age=604800, immutable',
                    'ETag' => '"'.$cacheKey.'"',
                    'X-Content-Type-Options' => 'nosniff',
                ]);
            } catch (Throwable $exception) {
                report($exception);
            }
        }

        $response = $this->serveProductFile($file, false);
        $response->headers->set('Cache-Control', 'private, max-age=86400');

        return $response;
    }

    public function showProductReferencePreview(Request $request, AikaipinProduct $product): Response|View
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewProduct($context['user'], $product), 403);
        $this->referencePreviewFile($product);

        $viewData = [
            'product' => $product,
            'contentUrl' => route('aikaipin.product-library.reference-preview.content', ['product' => $product, 'embedded' => 1]),
            'libraryUrl' => route('aikaipin.product-library.index'),
        ];
        if ($this->authorization->canManageProductLibrary($context['user'])) {
            $viewData['referenceEditable'] = true;
            $viewData['referenceContentUpdateUrl'] = route('aikaipin.product-library.reference-preview.content.update', $product);
        }

        return view('portals.aikaipin.product-library.reference-preview', $viewData);
    }

    public function uploadReferenceVideo(Request $request, AikaipinProduct $product): JsonResponse|RedirectResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) return $context;
        abort_unless($this->canViewProduct($context['user'], $product), 403);
        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        $data = $request->validate([
            'type' => ['required', Rule::in(['flow', 'traffic', 'remix'])],
            'video' => ['required', 'file', 'mimes:mp4,mov,avi,webm,mkv,m4v', 'max:307200'],
        ], [
            'video.required' => '请选择需要上传的视频。',
            'video.mimes' => '仅支持 MP4、MOV、AVI、WEBM、MKV、M4V 视频。',
            'video.max' => '单个视频不能超过 300MB。',
        ]);

        $file = $request->file('video');
        $date = now('Asia/Shanghai');
        $historicalCount = $this->historicalReferenceVideoCount($product);
        $this->normalizeReferenceVideos($product, $historicalCount);
        $latestSequence = (int) OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())->max('sequence');
        $sequence = max($historicalCount, $latestSequence) + 1;
        $latestFileNumber = OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())
            ->get(['file_name', 'sequence'])
            ->reduce(fn (int $carry, OperationAiProductReferenceVideo $video): int => max(
                $carry,
                OperationAiProductReferenceVideo::fileNumber($video->file_name, (int) $video->sequence),
            ), $historicalCount);
        $fileNumber = $latestFileNumber + 1;
        $extension = strtolower($file->getClientOriginalExtension() ?: $file->extension() ?: 'mp4');
        $typeCode = OperationAiProductReferenceVideo::fileTypeCode($data['type']);
        $fileName = $this->referenceProductCode($product).'-'.$typeCode.'-'.$date->format('ymd').'-'.str_pad((string) $fileNumber, 3, '0', STR_PAD_LEFT).'.'.$extension;
        $path = $file->storeAs('aikaipin/reference-videos/'.$product->getKey(), $fileName, 'local');
        $this->browserCompatibleVideo->normalize(Storage::disk('local')->path($path));

        try {
            OperationAiProductReferenceVideo::query()->create([
                'aikaipin_product_id' => $product->getKey(), 'type' => $data['type'],
                'sequence' => $sequence, 'file_date' => $date->toDateString(), 'disk' => 'local',
                'path' => $path, 'file_name' => $fileName, 'original_name' => $file->getClientOriginalName(),
                'mime_type' => mime_content_type(Storage::disk('local')->path($path)) ?: $file->getMimeType(),
                'size' => Storage::disk('local')->size($path), 'department_code' => 'AI',
                'source_kind' => OperationAiProductReferenceVideo::SOURCE_UPLOAD,
                'uploaded_by' => $context['user']->getKey(),
                'uploaded_by_name' => $context['user']->name ?: $context['user']->username,
            ]);
        } catch (Throwable $exception) {
            Storage::disk('local')->delete($path);
            throw $exception;
        }

        if ($request->expectsJson()) {
            return response()->json([
                'message' => '视频上传成功。',
                'file_name' => $fileName,
            ]);
        }

        return redirect()
            ->route('aikaipin.product-library.reference-preview', ['product' => $product])
            ->with('success', '视频上传成功，文件名：'.$fileName);
    }

    public function previewReferenceVideo(Request $request, AikaipinProduct $product, OperationAiProductReferenceVideo $video): Response
    {
        if (! $request->hasValidSignature() && ! $request->hasValidRelativeSignature()) {
            $context = $this->pageContext($request);
            if ($context instanceof Response) return $context;
            abort_unless($this->canViewProduct($context['user'], $product), 403);
        }
        $this->assertReferenceVideo($product, $video);
        $absolutePath = Storage::disk($video->disk)->path($video->path);
        if ($this->browserCompatibleVideo->normalize($absolutePath) === BrowserCompatibleVideoService::TRANSCODED) {
            $video->forceFill([
                'mime_type' => mime_content_type($absolutePath) ?: 'video/mp4',
                'size' => filesize($absolutePath) ?: $video->size,
            ])->save();
        }

        return $this->privateVideoResponse->inline(
            (string) $video->disk,
            (string) $video->path,
            (string) $video->file_name,
            $video->mime_type,
            $request,
        );
    }

    public function downloadReferenceVideo(Request $request, AikaipinProduct $product, OperationAiProductReferenceVideo $video): Response
    {
        if (! $request->hasValidSignature() && ! $request->hasValidRelativeSignature()) {
            $context = $this->pageContext($request);
            if ($context instanceof Response) return $context;
            abort_unless($this->canViewProduct($context['user'], $product), 403);
        }
        $this->assertReferenceVideo($product, $video);

        return Storage::disk($video->disk)->download($video->path, $video->file_name);
    }

    public function showProductReferencePreviewContent(Request $request, AikaipinProduct $product): Response
    {
        if (! $request->boolean('embedded')) {
            return redirect()->route('aikaipin.product-library.reference-preview', ['product' => $product]);
        }
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewProduct($context['user'], $product), 403);
        $file = $this->referencePreviewFile($product);
        $editsPath = $file['path'].'.erp-edits.json';
        $referenceEdits = Storage::disk($file['disk'])->exists($editsPath)
            ? (json_decode(Storage::disk($file['disk'])->get($editsPath), true) ?: []) : [];
        $hiddenVideosPath = $file['path'].'.erp-hidden-videos.json';
        $referenceHiddenVideos = Storage::disk($file['disk'])->exists($hiddenVideosPath)
            ? (json_decode(Storage::disk($file['disk'])->get($hiddenVideosPath), true) ?: []) : [];
        $layoutPath = $file['path'].'.erp-layout.json';
        $referenceLayouts = Storage::disk($file['disk'])->exists($layoutPath)
            ? (json_decode(Storage::disk($file['disk'])->get($layoutPath), true) ?: []) : [];
        $historicalCount = $this->historicalReferenceVideoCount($product);
        $historicalPreviewIndex = $request->query('history_video');
        $historicalPreviewIndex = is_numeric($historicalPreviewIndex) && (int) $historicalPreviewIndex >= 0
            ? (int) $historicalPreviewIndex
            : null;
        $videos = $this->normalizeReferenceVideos($product, $historicalCount)->map(fn ($video): array => [
            'id' => (int) $video->getKey(),
            'type' => $video->type,
            'name' => $video->file_name,
            'size' => number_format($video->size / 1048576, 2).' MB',
            'preview_url' => URL::temporarySignedRoute('aikaipin.product-library.reference-videos.preview', now()->addHours(12), [$product, $video], false),
            'download_url' => URL::temporarySignedRoute('aikaipin.product-library.reference-videos.download', now()->addHours(12), [$product, $video], false),
        ])->values();
        $injection = view('portals.operation.ai-product-library.reference-video-injection', [
            'videos' => $videos,
            'historicalProductCode' => trim((string) preg_replace('/[^A-Za-z0-9_-]+/', '-', (string) $product->product_code), '-_') ?: 'product-'.$product->getKey(),
            'historicalFallbackDate' => $product->created_at?->copy()->timezone('Asia/Shanghai')->format('ymd') ?: now('Asia/Shanghai')->format('ymd'),
            'referenceEdits' => $referenceEdits,
            'referenceHiddenVideos' => $referenceHiddenVideos,
            'referenceLayouts' => $referenceLayouts,
            'historicalPreviewIndex' => $historicalPreviewIndex,
        ])->render();
        return response()->stream(function () use ($file, $injection): void {
            $stream = Storage::disk($file['disk'])->readStream($file['path']);
            abort_unless(is_resource($stream), 404);
            try {
                while (! feof($stream)) {
                    echo fread($stream, 1024 * 1024);
                    if (function_exists('ob_flush')) @ob_flush();
                    flush();
                }
                echo $injection;
            } finally {
                fclose($stream);
            }
        }, 200, [
            'Content-Type' => 'text/html; charset=UTF-8',
            'Content-Disposition' => 'inline; filename="preview.html"',
            'Cache-Control' => 'private, no-store, max-age=0',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
            'Referrer-Policy' => 'no-referrer',
            'Permissions-Policy' => 'camera=(), geolocation=(), microphone=(), payment=(), usb=()',
            'X-Robots-Tag' => 'noindex, nofollow, noarchive',
            'Content-Security-Policy' => "sandbox allow-scripts allow-modals allow-downloads; default-src 'none'; base-uri 'none'; object-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' https:; style-src 'unsafe-inline' https:; img-src data: blob: https:; font-src data: https:; media-src data: blob: https: http:; connect-src https: http:; frame-src https:; worker-src blob:; form-action 'none'; frame-ancestors 'self'",
        ]);
    }

    public function updateProductReferencePreviewContent(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) return $context;
        abort_unless($this->authorization->canManageProductLibrary($context['user']), 403);
        abort_unless($this->canViewProduct($context['user'], $product), 403);
        $data = $request->validate([
            'patches' => ['present', 'array', 'max:5000'],
            'patches.*.index' => ['required', 'integer', 'min:0'],
            'patches.*.value' => ['nullable', 'string', 'max:20000'],
            'video_layout' => ['sometimes', 'array', 'max:200'],
            'video_layout.*.id' => ['required', 'integer', 'min:1', 'distinct'],
            'video_layout.*.type' => ['required', Rule::in([OperationAiProductReferenceVideo::TYPE_FLOW, OperationAiProductReferenceVideo::TYPE_TRAFFIC, OperationAiProductReferenceVideo::TYPE_REMIX])],
            'element_layout' => ['sometimes', 'array', 'max:2000'],
            'element_layout.*.key' => ['required', 'string', 'max:80', 'distinct'],
            'element_layout.*.x' => ['required', 'numeric', 'between:-5000,5000'],
            'element_layout.*.y' => ['required', 'numeric', 'between:-5000,5000'],
            'deleted_video_ids' => ['sometimes', 'array', 'max:200'],
            'deleted_video_ids.*' => ['integer', 'min:1'],
            'deleted_history_video_indexes' => ['sometimes', 'array', 'max:500'],
            'deleted_history_video_indexes.*' => ['integer', 'min:0'],
        ]);
        $file = $this->referencePreviewFile($product);
        $disk = Storage::disk($file['disk']);
        $disk->put($file['path'].'.erp-edits.json', json_encode($data['patches'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $hiddenVideoIndexes = array_values(array_unique(array_map('intval', $data['deleted_history_video_indexes'] ?? [])));
        sort($hiddenVideoIndexes);
        $disk->put($file['path'].'.erp-hidden-videos.json', json_encode($hiddenVideoIndexes));
        $elementLayout = collect($data['element_layout'] ?? [])->map(fn (array $item): array => [
            'key' => (string) $item['key'],
            'x' => round((float) $item['x'], 1),
            'y' => round((float) $item['y'], 1),
        ])->values()->all();
        $disk->put($file['path'].'.erp-layout.json', json_encode($elementLayout, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $videos = OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())
            ->whereIn('id', array_values(array_unique(array_map('intval', $data['deleted_video_ids'] ?? []))))
            ->get();
        foreach ($videos as $video) {
            Storage::disk($video->disk)->delete($video->path);
            $video->delete();
        }
        $layout = collect($data['video_layout'] ?? []);
        if ($layout->isNotEmpty()) {
            $layoutVideos = OperationAiProductReferenceVideo::query()
                ->where('aikaipin_product_id', $product->getKey())
                ->whereIn('id', $layout->pluck('id')->map(fn ($id) => (int) $id))
                ->get()->keyBy('id');
            $temporaryBase = (int) OperationAiProductReferenceVideo::query()
                ->where('aikaipin_product_id', $product->getKey())->max('sequence') + $layout->count() + 1000;
            DB::transaction(function () use ($layout, $layoutVideos, $temporaryBase): void {
                foreach ($layout->values() as $index => $item) {
                    $video = $layoutVideos->get((int) $item['id']);
                    if ($video) $video->update(['type' => $item['type'], 'sequence' => $temporaryBase + $index]);
                }
            }, 3);
            $this->normalizeReferenceVideos($product, $this->historicalReferenceVideoCount($product));
        }
        $product->forceFill([
            'updated_by' => $context['user']->getKey(),
            'updated_by_name' => $context['user']->name ?: $context['user']->username,
        ])->save();

        return response()->json(['message' => '参考页内容已保存。']);
    }

    public function showProductFile(Request $request, AikaipinProduct $product, string $kind): Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewProduct($context['user'], $product), 403);
        abort_unless(in_array($kind, ['reference', 'package'], true), 404);

        if ($kind === 'reference') {
            return redirect()->route('aikaipin.product-library.reference-preview', ['product' => $product]);
        }

        $file = $product->packageFilePayload();
        abort_unless($file !== null, 404);

        return $this->serveProductFile($file, true);
    }

    /** @return array{disk:string,path:string,original_name:string,mime_type:?string,size:int,sha256:?string} */
    private function referencePreviewFile(AikaipinProduct $product): array
    {
        $file = $product->referenceFilePayload();
        abort_unless($file !== null, 404);

        $disk = (string) $file['disk'];
        $path = ltrim(str_replace('\\', '/', trim((string) $file['path'])), '/');
        $extension = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));

        abort_unless(
            $disk === AikaipinProductLibraryStorageService::DISK
                && $path !== ''
                && ! in_array('..', explode('/', $path), true)
                && in_array($extension, ['html', 'htm'], true),
            404,
        );
        abort_unless(Storage::disk($disk)->exists($path), 404);

        $file['path'] = $path;

        return $file;
    }

    private function referenceVideos(AikaipinProduct $product): Collection
    {
        return OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())
            ->orderByRaw("CASE type WHEN 'flow' THEN 1 WHEN 'traffic' THEN 2 WHEN 'remix' THEN 3 ELSE 4 END")
            ->orderBy('sequence')->orderBy('id')->get();
    }

    private function historicalReferenceVideoCount(AikaipinProduct $product): int
    {
        return OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())
            ->where('source_kind', OperationAiProductReferenceVideo::SOURCE_HISTORICAL_HTML)
            ->count();
    }

    private function normalizeReferenceVideos(AikaipinProduct $product, int $historicalCount): Collection
    {
        DB::transaction(function () use ($product, $historicalCount): void {
            $productCode = $this->referenceProductCode($product);
            $videos = OperationAiProductReferenceVideo::query()
                ->where('aikaipin_product_id', $product->getKey())
                ->where(function (Builder $query): void {
                    $query->where(function (Builder $systemQuery): void {
                        $systemQuery->where('source_kind', OperationAiProductReferenceVideo::SOURCE_UPLOAD)
                            ->where(function (Builder $departmentQuery): void {
                                $departmentQuery->whereNull('department_code')
                                    ->orWhere('department_code', 'AI');
                            });
                    })->orWhere(function (Builder $legacyQuery): void {
                        $legacyQuery->whereNull('source_kind')
                            ->where(function (Builder $departmentQuery): void {
                                $departmentQuery->whereNull('department_code')
                                    ->orWhere('department_code', 'AI');
                            });
                    });
                })
                ->orderByRaw("CASE type WHEN 'flow' THEN 1 WHEN 'traffic' THEN 2 WHEN 'remix' THEN 3 ELSE 4 END")
                ->orderBy('sequence')->orderBy('id')->lockForUpdate()->get()->values();
            if ($videos->isEmpty()) return;

            $temporaryBase = (int) OperationAiProductReferenceVideo::query()
                ->where('aikaipin_product_id', $product->getKey())
                ->max('sequence') + $videos->count() + $historicalCount + 1000;
            $renames = [];
            foreach ($videos as $index => $video) {
                $sequence = $historicalCount + $index + 1;
                $fileNumber = OperationAiProductReferenceVideo::fileNumber($video->file_name, (int) $video->sequence);
                $extension = strtolower(pathinfo($video->file_name, PATHINFO_EXTENSION) ?: pathinfo($video->path, PATHINFO_EXTENSION) ?: 'mp4');
                $date = $video->file_date?->format('ymd') ?: $video->created_at?->copy()->timezone('Asia/Shanghai')->format('ymd') ?: now('Asia/Shanghai')->format('ymd');
                $typeCode = OperationAiProductReferenceVideo::fileTypeCode((string) $video->type);
                $fileName = $productCode.'-'.$typeCode.'-'.$date.'-'.str_pad((string) $fileNumber, 3, '0', STR_PAD_LEFT).'.'.$extension;
                $directory = trim(str_replace('\\', '/', dirname($video->path)), '.');
                $path = ($directory !== '' ? $directory.'/' : '').$fileName;
                $temporaryPath = ($directory !== '' ? $directory.'/' : '').'.renumber-'.$video->getKey().'-'.Str::uuid().'.'.$extension;
                $renames[] = compact('video', 'sequence', 'fileName', 'path', 'temporaryPath');
                $video->update(['sequence' => $temporaryBase + $index]);
            }

            foreach ($renames as &$rename) {
                $video = $rename['video'];
                if ($rename['path'] !== $video->path && Storage::disk($video->disk)->exists($video->path)) {
                    Storage::disk($video->disk)->move($video->path, $rename['temporaryPath']);
                    $rename['moved'] = true;
                }
            }
            unset($rename);
            foreach ($renames as $rename) {
                $video = $rename['video'];
                if (! empty($rename['moved'])) Storage::disk($video->disk)->move($rename['temporaryPath'], $rename['path']);
                $video->update(['sequence' => $rename['sequence'], 'file_name' => $rename['fileName'], 'path' => $rename['path']]);
            }
        }, 3);

        return $this->referenceVideos($product);
    }

    private function referenceProductCode(AikaipinProduct $product): string
    {
        return trim((string) preg_replace('/[^A-Za-z0-9_-]+/', '-', (string) $product->product_code), '-_') ?: 'product-'.$product->getKey();
    }

    private function assertReferenceVideo(AikaipinProduct $product, OperationAiProductReferenceVideo $video): void
    {
        abort_unless((int) $video->aikaipin_product_id === (int) $product->getKey(), 404);
        abort_unless(Storage::disk($video->disk)->exists($video->path), 404);
    }

    /** @param array{disk:string,path:string,original_name:string,mime_type:?string,size:int,sha256:?string} $file */
    private function serveProductFile(array $file, bool $download): Response
    {
        $disk = (string) $file['disk'];
        abort_unless($disk === AikaipinProductLibraryStorageService::DISK && Storage::disk($disk)->exists($file['path']), 404);

        $headers = ['Content-Type' => $file['mime_type'] ?: 'application/octet-stream'];

        return $download
            ? response()->download(Storage::disk($disk)->path($file['path']), $file['original_name'], $headers)
            : response()->file(Storage::disk($disk)->path($file['path']), $headers);
    }

    public function selectionProposal(Request $request): Response|View
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $canReviewAllSelectionProposals = $this->authorization->canManageProductLibrary($context['user']);
        $filters = $this->selectionProposalFilters($request);

        return view('portals.aikaipin.selection-proposal.index', [
            ...$context,
            'proposals' => $this->selectionProposalQuery($context['user'], $canReviewAllSelectionProposals, $filters)
                ->paginate(15)
                ->withQueryString(),
            'filters' => $filters,
            'canReviewAllSelectionProposals' => $canReviewAllSelectionProposals,
        ]);
    }

    public function storeSelectionProposal(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $data = $request->validate([
            'product_name' => ['required', 'string', 'max:255'],
            'specifications' => ['nullable', 'array'],
            'specifications.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'attributes' => ['nullable', 'array'],
            'attributes.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'link_1688' => ['nullable', 'url', 'max:2048'],
            'competitor_url' => ['nullable', 'url', 'max:2048'],
            'remark' => ['nullable', 'string', 'max:2000'],
            'images' => ['required', 'array', 'min:1', 'max:3'],
            'images.*' => ['file', 'image', 'max:20480'],
        ]);
        $specifications = $this->selectionProposalTagValues($data['specifications'] ?? []);
        $attributes = $this->selectionProposalTagValues($data['attributes'] ?? []);
        $createdPaths = [];
        $proposal = null;

        try {
            $connection = config('admin.database.connection') ?: config('database.default');
            $proposal = DB::connection($connection)->transaction(function () use ($context, $data, $specifications, $attributes, &$createdPaths): AikaipinSelectionProposal {
                $proposal = AikaipinSelectionProposal::create([
                    'proposal_code' => $this->nextSelectionProposalCode(),
                    'product_name' => trim((string) $data['product_name']),
                    'link_1688' => ($data['link_1688'] ?? null) ?: null,
                    'competitor_url' => ($data['competitor_url'] ?? null) ?: null,
                    'remark' => ($data['remark'] ?? null) ?: null,
                    'created_by' => (int) $context['user']->getKey(),
                    'created_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ]);

                $this->syncSelectionProposalTags($proposal, $specifications, $attributes);
                foreach (array_values($data['images']) as $sort => $image) {
                    /** @var UploadedFile $image */
                    $imagePayload = $this->selectionProposalStorage->storeImage($image);
                    $createdPaths[] = $imagePayload['path'];
                    $proposal->images()->create([...$imagePayload, 'disk' => AikaipinSelectionProposalStorageService::DISK, 'sort' => $sort]);
                }

                return $proposal;
            });
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (\Throwable $exception) {
            foreach ($createdPaths as $path) {
                $this->selectionProposalStorage->deleteImage($path);
            }
            report($exception);

            return response()->json([
                'message' => __('aikaipin.selection_proposal.messages.save_failed_message'),
            ], 500);
        }

        return response()->json([
            'message' => __('aikaipin.selection_proposal.messages.created_message'),
            'redirect_url' => route('aikaipin.selection-proposals.index'),
            'proposal_id' => $proposal?->getKey(),
        ], 201);
    }

    public function showSelectionProposal(Request $request, AikaipinSelectionProposal $proposal): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewSelectionProposal($context['user'], $proposal), 403);
        $proposal->load(['tags', 'images']);

        return response()->json($this->selectionProposalPayload($context['user'], $proposal));
    }

    public function updateSelectionProposal(Request $request, AikaipinSelectionProposal $proposal): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canEditSelectionProposal($context['user'], $proposal), 403);
        $data = $request->validate([
            'product_name' => ['required', 'string', 'max:255'],
            'specifications' => ['nullable', 'array'],
            'specifications.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'attributes' => ['nullable', 'array'],
            'attributes.*' => ['nullable', 'string', 'max:80', 'distinct'],
            'link_1688' => ['nullable', 'url', 'max:2048'],
            'competitor_url' => ['nullable', 'url', 'max:2048'],
            'remark' => ['nullable', 'string', 'max:2000'],
            'images' => ['nullable', 'array'],
            'images.*' => ['file', 'image', 'max:20480'],
            'remove_image_ids' => ['nullable', 'array'],
            'remove_image_ids.*' => ['integer', 'distinct'],
        ]);
        $specifications = $this->selectionProposalTagValues($data['specifications'] ?? []);
        $attributes = $this->selectionProposalTagValues($data['attributes'] ?? []);
        $removedImageIds = collect($data['remove_image_ids'] ?? [])->map(static fn ($id): int => (int) $id)->unique()->values()->all();
        $existingImages = $proposal->images()->get();
        $existingImageIds = $existingImages->pluck('id')->map(static fn ($id): int => (int) $id)->all();
        if (collect($removedImageIds)->diff($existingImageIds)->isNotEmpty()) {
            throw ValidationException::withMessages([
                'remove_image_ids' => __('aikaipin.selection_proposal.messages.image_invalid_message'),
            ]);
        }

        $newImages = array_values($data['images'] ?? []);
        $finalImageCount = $existingImages->count() - count($removedImageIds) + count($newImages);
        if ($finalImageCount < 1 || $finalImageCount > 3) {
            throw ValidationException::withMessages([
                'images' => $finalImageCount < 1
                    ? __('aikaipin.selection_proposal.messages.image_required_message')
                    : __('aikaipin.selection_proposal.messages.image_limit_message'),
            ]);
        }

        $createdPaths = [];
        $obsoleteImages = collect();

        try {
            $connection = config('admin.database.connection') ?: config('database.default');
            DB::connection($connection)->transaction(function () use ($context, $proposal, $data, $specifications, $attributes, $removedImageIds, $newImages, &$createdPaths, &$obsoleteImages): void {
                $proposal->forceFill([
                    'product_name' => trim((string) $data['product_name']),
                    'link_1688' => ($data['link_1688'] ?? null) ?: null,
                    'competitor_url' => ($data['competitor_url'] ?? null) ?: null,
                    'remark' => ($data['remark'] ?? null) ?: null,
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ])->save();
                $this->syncSelectionProposalTags($proposal, $specifications, $attributes);

                $removedImages = $proposal->images()->whereKey($removedImageIds)->get();
                if ($removedImages->isNotEmpty()) {
                    $obsoleteImages = $obsoleteImages->merge($removedImages);
                    $proposal->images()->whereKey($removedImageIds)->delete();
                }

                $sort = (int) ($proposal->images()->max('sort') ?? -1) + 1;
                foreach ($newImages as $image) {
                    /** @var UploadedFile $image */
                    $imagePayload = $this->selectionProposalStorage->storeImage($image);
                    $createdPaths[] = $imagePayload['path'];
                    $proposal->images()->create([...$imagePayload, 'disk' => AikaipinSelectionProposalStorageService::DISK, 'sort' => $sort]);
                    $sort += 1;
                }
            });
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (\Throwable $exception) {
            foreach ($createdPaths as $path) {
                $this->selectionProposalStorage->deleteImage($path);
            }
            report($exception);

            return response()->json([
                'message' => __('aikaipin.selection_proposal.messages.save_failed_message'),
            ], 500);
        }

        foreach ($obsoleteImages->unique('id') as $image) {
            try {
                $this->selectionProposalStorage->deleteImage((string) $image->path);
            } catch (\Throwable $exception) {
                report($exception);
            }
        }

        return response()->json([
            'message' => __('aikaipin.selection_proposal.messages.updated_message'),
            'redirect_url' => route('aikaipin.selection-proposals.index'),
            'proposal_id' => $proposal->getKey(),
        ]);
    }

    public function withdrawSelectionProposal(Request $request, AikaipinSelectionProposal $proposal): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canEditSelectionProposal($context['user'], $proposal), 403);
        $proposal->forceFill([
            'withdrawn_at' => now(),
            'withdrawn_by' => (int) $context['user']->getKey(),
            'withdrawn_by_name' => (string) ($context['user']->name ?: $context['user']->username),
            'updated_by' => (int) $context['user']->getKey(),
            'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
        ])->save();

        return response()->json([
            'message' => __('aikaipin.selection_proposal.messages.withdrawn_message'),
            'redirect_url' => route('aikaipin.selection-proposals.index'),
        ]);
    }

    public function showSelectionProposalImage(Request $request, AikaipinSelectionProposal $proposal, AikaipinSelectionProposalImage $image): Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless((int) $image->proposal_id === (int) $proposal->getKey(), 404);
        abort_unless($this->canViewSelectionProposal($context['user'], $proposal), 403);
        abort_unless($image->disk === AikaipinSelectionProposalStorageService::DISK && Storage::disk($image->disk)->exists($image->path), 404);

        return response()->file(Storage::disk($image->disk)->path($image->path), [
            'Content-Type' => $image->mime_type ?: 'application/octet-stream',
        ]);
    }

    public function placementEvaluation(Request $request): Response|View
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $canReviewAllPlacementEvaluations = $this->authorization->canManageProductLibrary($context['user']);
        $filters = $this->placementEvaluationFilters($request);

        $products = $this->productQuery($context['user'], $canReviewAllPlacementEvaluations, [
            'keyword' => $filters['keyword'], 'category' => '', 'source' => '', 'type' => '',
        ])->with(['placementEvaluations' => fn ($query) => $query->with('records')
            ->when(! $canReviewAllPlacementEvaluations, fn ($evaluations) => $evaluations->where('created_by', $context['user']->getKey()))
            ->latest('updated_at')])
            ->latest('updated_at')->paginate(15)->withQueryString();

        return view('portals.aikaipin.placement-evaluation.index', [
            ...$context,
            'products' => $products,
            'filters' => $filters,
            'canReviewAllPlacementEvaluations' => $canReviewAllPlacementEvaluations,
        ]);
    }

    public function showProductPlacementEvaluations(Request $request, AikaipinProduct $product): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) return $context;
        abort_unless($this->canViewProduct($context['user'], $product), 403);
        $canReviewAll = $this->authorization->canManageProductLibrary($context['user']);
        $evaluations = AikaipinPlacementEvaluation::query()->with('records')
            ->where('product_id', $product->getKey())
            ->when(! $canReviewAll, fn ($query) => $query->where('created_by', $context['user']->getKey()))
            ->latest('updated_at')->get();

        return response()->json([
            'product' => ['code' => $product->product_code, 'name' => $product->name, 'skus' => $product->skuValues()],
            'evaluations' => $evaluations->map(fn ($evaluation): array => [
                'code' => $evaluation->evaluation_code,
                'submitter' => $evaluation->created_by_name,
                'period' => $evaluation->test_started_on?->format('Y-m-d').' 至 '.$evaluation->data_ended_on?->format('Y-m-d'),
                'records' => $evaluation->records->map(fn ($record): array => [
                    'platform' => $record->platform, 'currency' => $record->currency,
                    'spend' => (string) $record->actual_spend, 'orders' => (int) $record->orders,
                    'roi' => $record->roi !== null ? (string) $record->roi : null,
                    'material_name' => $record->material_name,
                    'video_code' => $record->video_name ? pathinfo((string) $record->video_name, PATHINFO_FILENAME) : null,
                    'video_url' => $record->video_path ? route('aikaipin.placement-evaluations.records.video', [$evaluation, $record]) : null,
                ])->values(),
            ])->values(),
        ]);
    }

    public function placementEvaluationRecordVideo(Request $request, AikaipinPlacementEvaluation $evaluation, AikaipinPlacementEvaluationRecord $record): Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) return $context;
        abort_unless($this->canViewPlacementEvaluation($context['user'], $evaluation), 403);
        abort_unless((int) $record->evaluation_id === (int) $evaluation->getKey(), 404);
        abort_unless($record->video_path && Storage::disk($record->video_disk ?: 'local')->exists($record->video_path), 404);

        return response()->file(Storage::disk($record->video_disk ?: 'local')->path($record->video_path), [
            'Content-Type' => $record->video_mime_type ?: 'video/mp4',
            'Content-Disposition' => 'inline; filename="'.$record->video_name.'"',
        ]);
    }

    public function placementEvaluationProductOptions(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $keyword = trim((string) $request->query('keyword', ''));
        $canManageProductLibrary = $this->authorization->canManageProductLibrary($context['user']);
        $products = $this->productQuery($context['user'], $canManageProductLibrary, [
            'keyword' => $keyword,
            'category' => '',
            'source' => '',
            'type' => '',
        ])->limit(12)->get(['id', 'product_code', 'name']);

        return response()->json([
            'products' => $products->map(static fn (AikaipinProduct $product): array => [
                'id' => (int) $product->getKey(),
                'code' => (string) $product->product_code,
                'name' => (string) $product->name,
            ])->values()->all(),
        ]);
    }

    public function storePlacementEvaluation(Request $request): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $data = $this->validatedPlacementEvaluationData($request);
        $product = $this->placementEvaluationProduct($context['user'], (int) $data['product_id']);
        $records = $this->placementEvaluationRecords($data['records']);
        $connection = config('admin.database.connection') ?: config('database.default');

        try {
            $evaluation = DB::connection($connection)->transaction(function () use ($context, $data, $product, $records): AikaipinPlacementEvaluation {
                $evaluation = AikaipinPlacementEvaluation::create([
                    'evaluation_code' => $this->nextPlacementEvaluationCode(),
                    'product_id' => (int) $product->getKey(),
                    'product_code' => (string) $product->product_code,
                    'product_name' => (string) $product->name,
                    'test_started_on' => $data['test_started_on'],
                    'data_ended_on' => $data['data_ended_on'],
                    'remark' => ($data['remark'] ?? null) ?: null,
                    'created_by' => (int) $context['user']->getKey(),
                    'created_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ]);
                foreach ($records as $sort => $record) {
                    $evaluation->records()->create([...$record, 'sort' => $sort]);
                }

                return $evaluation;
            });
        } catch (\Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => __('aikaipin.placement_evaluation.messages.save_failed_message'),
            ], 500);
        }

        return response()->json([
            'message' => __('aikaipin.placement_evaluation.messages.created_message'),
            'redirect_url' => route('aikaipin.placement-evaluations.index'),
            'evaluation_id' => $evaluation->getKey(),
        ], 201);
    }

    public function showPlacementEvaluation(Request $request, AikaipinPlacementEvaluation $evaluation): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canViewPlacementEvaluation($context['user'], $evaluation), 403);
        $evaluation->load('records');

        return response()->json($this->placementEvaluationPayload($context['user'], $evaluation));
    }

    public function updatePlacementEvaluation(Request $request, AikaipinPlacementEvaluation $evaluation): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canEditPlacementEvaluation($context['user'], $evaluation), 403);
        $data = $this->validatedPlacementEvaluationData($request);
        $product = $this->placementEvaluationProduct($context['user'], (int) $data['product_id']);
        $records = $this->placementEvaluationRecords($data['records']);
        $connection = config('admin.database.connection') ?: config('database.default');

        try {
            DB::connection($connection)->transaction(function () use ($context, $evaluation, $data, $product, $records): void {
                $evaluation->forceFill([
                    'product_id' => (int) $product->getKey(),
                    'product_code' => (string) $product->product_code,
                    'product_name' => (string) $product->name,
                    'test_started_on' => $data['test_started_on'],
                    'data_ended_on' => $data['data_ended_on'],
                    'remark' => ($data['remark'] ?? null) ?: null,
                    'updated_by' => (int) $context['user']->getKey(),
                    'updated_by_name' => (string) ($context['user']->name ?: $context['user']->username),
                ])->save();
                $evaluation->records()->delete();
                foreach ($records as $sort => $record) {
                    $evaluation->records()->create([...$record, 'sort' => $sort]);
                }
            });
        } catch (\Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => __('aikaipin.placement_evaluation.messages.save_failed_message'),
            ], 500);
        }

        return response()->json([
            'message' => __('aikaipin.placement_evaluation.messages.updated_message'),
            'redirect_url' => route('aikaipin.placement-evaluations.index'),
            'evaluation_id' => $evaluation->getKey(),
        ]);
    }

    public function destroyPlacementEvaluation(Request $request, AikaipinPlacementEvaluation $evaluation): JsonResponse|Response
    {
        $context = $this->pageContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        abort_unless($this->canEditPlacementEvaluation($context['user'], $evaluation), 403);
        $connection = config('admin.database.connection') ?: config('database.default');

        DB::connection($connection)->transaction(function () use ($evaluation): void {
            $evaluation->records()->delete();
            $evaluation->delete();
        });

        return response()->json([
            'message' => __('aikaipin.placement_evaluation.messages.deleted_message'),
            'redirect_url' => route('aikaipin.placement-evaluations.index'),
        ]);
    }

    /**
     * @return array<string, mixed>|Response
     */
    private function pageContext(Request $request): array|Response
    {
        $context = $this->portalEntries->portalContext($request);
        if ($context instanceof Response) {
            return $context;
        }

        $this->authorization->assertPortal($context['portal']);
        $context['portal']->loadMissing('menus');

        return $context;
    }

    private function uploadSessionForUser(AdminUser $user, string $uploadToken, bool $lockForUpdate = false): AikaipinProductUploadSession
    {
        $query = AikaipinProductUploadSession::query()
            ->where('upload_token', $uploadToken)
            ->where('user_id', $user->getKey());

        if ($lockForUpdate) {
            $query->lockForUpdate();
        }

        $session = $query->first();
        if ($session === null) {
            throw ValidationException::withMessages([
                'package_upload_token' => __('aikaipin.messages.package_upload_invalid_message'),
            ]);
        }

        return $session;
    }

    /** @return array{upload_token:string,status:string,uploaded_chunks:list<int>,received_size:int,total_size:int,chunk_size:int} */
    private function packageSessionPayload(AikaipinProductUploadSession $session): array
    {
        return [
            'upload_token' => (string) $session->upload_token,
            'status' => (string) $session->status,
            'uploaded_chunks' => $session->parts()
                ->orderBy('chunk_index')
                ->pluck('chunk_index')
                ->map(static fn ($index): int => (int) $index)
                ->values()
                ->all(),
            'received_size' => (int) $session->received_size,
            'total_size' => (int) $session->total_size,
            'chunk_size' => AikaipinProductLibraryStorageService::PACKAGE_CHUNK_SIZE,
        ];
    }

    /** @return array<string, mixed> */
    private function productEditPayload(AikaipinProduct $product): array
    {
        $product->loadMissing('productPages');
        $filePayload = function (?array $file, string $kind) use ($product): ?array {
            if ($file === null) {
                return null;
            }

            return [
                'name' => (string) $file['original_name'],
                'url' => $kind === 'reference'
                    ? route('aikaipin.product-library.reference-preview', ['product' => $product])
                    : route('aikaipin.product-library.files.show', ['product' => $product, 'kind' => $kind]),
            ];
        };

        $imageFiles = $product->imageFiles();

        return [
            'id' => (int) $product->getKey(),
            'product_code' => (string) $product->product_code,
            'name' => (string) $product->name,
            'source_platform' => (string) $product->source_platform,
            'product_type' => (string) $product->product_type,
            'is_published' => (bool) $product->is_published,
            'landing_page_url' => $product->landing_page_url,
            'skus' => $product->skuValues(),
            'categories' => $product->categoryValues(),
            'authorized_department_ids' => $product->visibleDepartmentIds(),
            'images' => array_map(function (array $file, int $index) use ($product): array {
                return [
                    'index' => $index,
                    'name' => (string) $file['original_name'],
                    'url' => route('aikaipin.product-library.images.show', [
                        'product' => $product,
                        'imageIndex' => $index,
                        'v' => $product->updated_at?->getTimestamp() ?? time(),
                    ]),
                ];
            }, $imageFiles, array_keys($imageFiles)),
            'reference_file' => $filePayload($product->referenceFilePayload(), 'reference'),
            'package_file' => $filePayload($product->packageFilePayload(), 'package'),
            'shopify_data' => $product->hasShopifyData() ? $this->shopifyImportPayload($product->shopifyData()) : null,
            'product_pages' => $product->productPages->map(fn ($page): array => [
                'id' => (int) $page->getKey(),
                'name' => (string) $page->name,
                'is_default' => (bool) $page->is_default,
                'landing_page_url' => $page->landing_page_url,
                'shopify_data' => $this->shopifyImportPayload($page->shopifyData()),
            ])->values()->all(),
            'reference_url' => $product->referenceFilePayload()
                ? route('aikaipin.product-library.reference-preview', ['product' => $product]) : null,
            'material_videos' => $this->materialVideoPayloads($product),
        ];
    }

    /** @return list<array<string, mixed>> */
    private function materialVideoPayloads(AikaipinProduct $product): array
    {
        return [
            ...$this->historicalReferenceVideoPayloads($product),
            ...$this->referenceVideos($product)->map(fn (OperationAiProductReferenceVideo $video): array => [
                'id' => (int) $video->getKey(),
                'type' => (string) $video->type,
                'name' => (string) $video->file_name,
                'historical' => false,
                'size' => number_format(((int) $video->size) / 1048576, 2).' MB',
                'preview_url' => URL::temporarySignedRoute('aikaipin.product-library.reference-videos.preview', now()->addHours(12), [$product, $video], false),
            ])->all(),
        ];
    }

    /** @return array{found:int,imported:int,skipped:int,failed:int,errors:list<string>} */
    private function importReferenceVideosToTable(?AikaipinProduct $product): array
    {
        $empty = ['found' => 0, 'imported' => 0, 'skipped' => 0, 'failed' => 0, 'errors' => []];
        if ($product === null || $product->referenceFilePayload() === null) return $empty;

        try {
            return $this->historicalVideoImporter->import($product->fresh());
        } catch (Throwable $exception) {
            report($exception);

            return [...$empty, 'failed' => 1, 'errors' => [$exception->getMessage()]];
        }
    }

    /** @param array{found:int,imported:int,skipped:int,failed:int,errors:list<string>} $videoImport */
    private function productSaveMessage(string $message, array $videoImport): string
    {
        if ($videoImport['found'] === 0) return $message;
        if ($videoImport['failed'] > 0) {
            return $message.'；参考页视频已导入 '.$videoImport['imported'].' 个，失败 '.$videoImport['failed'].' 个，请检查视频地址。';
        }
        if ($videoImport['imported'] === 0 && $videoImport['skipped'] > 0) {
            return $message.'；参考页视频库已是最新。';
        }

        return $message.'；参考页视频已同步到视频库 '.$videoImport['imported'].' 个。';
    }

    /** @return list<string> */
    private function referenceFilePaths(string $path): array
    {
        return [
            $path,
            $path.'.erp-edits.json',
            $path.'.erp-hidden-videos.json',
            $path.'.erp-layout.json',
        ];
    }

    /**
     * @param array<string, list<string>> $groups
     * @param list<AikaipinProductUploadSession> $completedSessions
     * @return array<string, list<UploadedFile>>
     */
    private function materialVideoFilesFromUploadTokens(array $groups, AdminUser $user, array &$completedSessions): array
    {
        $allowedTypes = [
            OperationAiProductReferenceVideo::TYPE_FLOW,
            OperationAiProductReferenceVideo::TYPE_TRAFFIC,
            OperationAiProductReferenceVideo::TYPE_REMIX,
        ];
        $allowedExtensions = ['mp4', 'mov', 'avi', 'webm', 'mkv', 'm4v'];
        $files = [];
        $seenTokens = [];

        foreach ($allowedTypes as $type) {
            foreach ((array) ($groups[$type] ?? []) as $uploadToken) {
                $uploadToken = (string) $uploadToken;
                if (isset($seenTokens[$uploadToken])) {
                    throw ValidationException::withMessages([
                        'material_video_upload_tokens' => '同一个素材视频不能重复提交。',
                    ]);
                }
                $seenTokens[$uploadToken] = true;

                $session = $this->uploadSessionForUser($user, $uploadToken, true);
                $extension = strtolower(pathinfo((string) $session->original_name, PATHINFO_EXTENSION));
                $valid = $session->status === AikaipinProductUploadSession::STATUS_COMPLETED
                    && $session->assembled_path
                    && Storage::disk(AikaipinProductLibraryStorageService::DISK)->exists($session->assembled_path)
                    && in_array($extension, $allowedExtensions, true)
                    && (int) $session->total_size <= 300 * 1024 * 1024;
                if (! $valid) {
                    throw ValidationException::withMessages([
                        'material_video_upload_tokens' => '素材视频上传不完整、格式不正确或超过 300MB，请重新上传。',
                    ]);
                }

                $files[$type][] = new UploadedFile(
                    Storage::disk(AikaipinProductLibraryStorageService::DISK)->path($session->assembled_path),
                    (string) $session->original_name,
                    $session->mime_type ?: null,
                    UPLOAD_ERR_OK,
                    true,
                );
                $session->forceFill([
                    'status' => AikaipinProductUploadSession::STATUS_CONSUMED,
                    'expires_at' => now()->addHour(),
                ])->save();
                $completedSessions[] = $session;
            }
        }

        return $files;
    }

    /** @param array<string, mixed> $groups @param list<string> $createdPaths */
    private function storeMaterialVideos(AikaipinProduct $product, array $groups, AdminUser $user, array &$createdPaths): void
    {
        $allowedTypes = [
            OperationAiProductReferenceVideo::TYPE_FLOW,
            OperationAiProductReferenceVideo::TYPE_TRAFFIC,
            OperationAiProductReferenceVideo::TYPE_REMIX,
        ];
        $filesByType = collect($allowedTypes)->mapWithKeys(fn (string $type): array => [
            $type => array_values(array_filter((array) ($groups[$type] ?? []), fn ($file): bool => $file instanceof UploadedFile)),
        ]);
        if ($filesByType->flatten(1)->isEmpty()) return;

        $historicalCount = $product->referenceFilePayload() ? $this->historicalReferenceVideoCount($product) : 0;
        $existing = OperationAiProductReferenceVideo::query()
            ->where('aikaipin_product_id', $product->getKey())->lockForUpdate()->get();
        $sequence = max($historicalCount, (int) $existing->max('sequence'));
        $fileNumber = $existing->reduce(fn (int $carry, OperationAiProductReferenceVideo $video): int => max(
            $carry,
            OperationAiProductReferenceVideo::fileNumber($video->file_name, (int) $video->sequence),
        ), $historicalCount);
        $date = now('Asia/Shanghai');

        foreach ($allowedTypes as $type) {
            foreach ($filesByType->get($type, []) as $file) {
                ++$sequence;
                ++$fileNumber;
                $extension = strtolower($file->getClientOriginalExtension() ?: $file->extension() ?: 'mp4');
                $fileName = $this->referenceProductCode($product).'-'.OperationAiProductReferenceVideo::fileTypeCode($type).'-'.$date->format('ymd').'-'.str_pad((string) $fileNumber, 3, '0', STR_PAD_LEFT).'.'.$extension;
                // Keep the public/display filename stable while placing every
                // upload in its own storage directory. When an editor deletes
                // a video and uploads another one in the same save operation,
                // the old-file cleanup can therefore never remove the new
                // physical file by mistake.
                $directory = 'aikaipin/reference-videos/'.$product->getKey().'/'.Str::uuid();
                $this->ensureMaterialVideoDirectoryIsWritable($directory, $product);

                try {
                    $path = $file->storeAs($directory, $fileName, 'local');
                } catch (Throwable $exception) {
                    Storage::disk('local')->deleteDirectory($directory);
                    report($exception);
                    throw ValidationException::withMessages([
                        'material_videos' => '视频无法写入服务器存储目录，请联系管理员检查 storage 目录权限后重试。已上传的原视频不会被删除。',
                    ]);
                }
                if (! is_string($path) || ! Storage::disk('local')->exists($path)) {
                    Storage::disk('local')->deleteDirectory($directory);
                    throw ValidationException::withMessages([
                        'material_videos' => '素材视频保存失败，请重新选择视频后再试。',
                    ]);
                }
                $createdPaths[] = $path;
                $storedSize = (int) Storage::disk('local')->size($path);
                if ($storedSize < 1 || ($file->getSize() > 0 && $storedSize !== (int) $file->getSize())) {
                    Storage::disk('local')->delete($path);
                    throw ValidationException::withMessages([
                        'material_videos' => '素材视频上传不完整，请重新选择视频后再试。',
                    ]);
                }

                $normalization = $this->browserCompatibleVideo->normalize(Storage::disk('local')->path($path));
                if ($normalization === BrowserCompatibleVideoService::FAILED) {
                    // Conversion is only a playback enhancement. Preserve the
                    // source video and allow the product save to complete; a
                    // browser that cannot decode it can use the download link.
                    logger()->warning('AI product material video transcoding failed; original file retained.', [
                        'product_id' => $product->getKey(),
                        'path' => $path,
                    ]);
                }
                OperationAiProductReferenceVideo::query()->create([
                    'aikaipin_product_id' => $product->getKey(), 'type' => $type,
                    'sequence' => $sequence, 'file_date' => $date->toDateString(), 'disk' => 'local',
                    'path' => $path, 'file_name' => $fileName, 'original_name' => $file->getClientOriginalName(),
                    'mime_type' => mime_content_type(Storage::disk('local')->path($path)) ?: $file->getMimeType(),
                    'size' => Storage::disk('local')->size($path), 'department_code' => 'AI',
                    'source_kind' => OperationAiProductReferenceVideo::SOURCE_UPLOAD,
                    'uploaded_by' => $user->getKey(), 'uploaded_by_name' => $user->name ?: $user->username,
                ]);
            }
        }
    }

    private function ensureMaterialVideoDirectoryIsWritable(string $directory, AikaipinProduct $product): void
    {
        $disk = Storage::disk('local');

        try {
            if (! $disk->exists($directory) && ! $disk->makeDirectory($directory)) {
                throw new \RuntimeException('Unable to create the AI product material video directory.');
            }

            $absolutePath = $disk->path($directory);
            clearstatcache(true, $absolutePath);
            if (! is_dir($absolutePath) || ! is_writable($absolutePath)) {
                throw new \RuntimeException('The AI product material video directory is not writable.');
            }
        } catch (Throwable $exception) {
            report($exception);
            logger()->error('AI product material video directory is unavailable.', [
                'product_id' => $product->getKey(),
                'directory' => $directory,
            ]);

            throw ValidationException::withMessages([
                'material_videos' => '服务器视频存储目录不可写，请联系管理员修复 storage 目录权限后重试。已上传的原视频不会被删除。',
            ]);
        }
    }

    /** @return list<array{id:null,type:string,name:string,historical:true,size:string,preview_url:string}> */
    private function historicalReferenceVideoPayloads(AikaipinProduct $product): array
    {
        $file = $product->referenceFilePayload();
        if ($file === null || ! Storage::disk($file['disk'])->exists($file['path'])) return [];

        $hiddenPath = $file['path'].'.erp-hidden-videos.json';
        $hidden = Storage::disk($file['disk'])->exists($hiddenPath)
            ? array_map('intval', (array) (json_decode(Storage::disk($file['disk'])->get($hiddenPath), true) ?: [])) : [];
        $stream = Storage::disk($file['disk'])->readStream($file['path']);
        if (! is_resource($stream)) return [];

        $items = [];
        $historyIndex = 0;
        $type = OperationAiProductReferenceVideo::TYPE_FLOW;
        $tail = '';
        $absolute = 0;
        $lastEventEnd = -1;
        $date = $product->created_at?->copy()->timezone('Asia/Shanghai')->format('ymd') ?: now('Asia/Shanghai')->format('ymd');
        try {
            while (! feof($stream)) {
                $chunk = fread($stream, 1024 * 1024);
                if ($chunk === false || $chunk === '') continue;
                $buffer = $tail.$chunk;
                $base = $absolute - strlen($tail);
                // Chunk boundaries can split a UTF-8 character. Do not use the
                // UTF-8 regex modifier here, otherwise one incomplete boundary
                // makes preg_match_all return no historical videos at all.
                preg_match_all('/Flow\s*素材|扒的素材|引流素材|混剪素材|<video\b/i', $buffer, $matches, PREG_OFFSET_CAPTURE);
                foreach ($matches[0] as [$token, $offset]) {
                    $eventStart = $base + $offset;
                    $eventEnd = $eventStart + strlen($token);
                    if ($eventEnd <= $lastEventEnd) continue;
                    $lastEventEnd = $eventEnd;
                    if (stripos($token, '<video') === 0) {
                        $number = ++$historyIndex;
                        if (! in_array($number - 1, $hidden, true)) {
                            $items[] = [
                                'id' => null, 'history_index' => $number - 1, 'type' => $type,
                                'name' => $this->referenceProductCode($product).'-'.OperationAiProductReferenceVideo::fileTypeCode($type).'-'.$date.'-'.str_pad((string) $number, 3, '0', STR_PAD_LEFT).'.mp4',
                                'historical' => true, 'size' => '历史 HTML',
                                'preview_url' => route('aikaipin.product-library.reference-preview.content', [
                                    'product' => $product,
                                    'embedded' => 1,
                                    'history_video' => $number - 1,
                                ]),
                            ];
                        }
                    } elseif (str_contains($token, '混剪')) {
                        $type = OperationAiProductReferenceVideo::TYPE_REMIX;
                    } elseif (str_contains($token, '扒') || str_contains($token, '引流')) {
                        $type = OperationAiProductReferenceVideo::TYPE_TRAFFIC;
                    } else {
                        $type = OperationAiProductReferenceVideo::TYPE_FLOW;
                    }
                }
                $absolute += strlen($chunk);
                $tail = substr($buffer, -65536);
            }
        } finally {
            fclose($stream);
        }

        return $items;
    }

    /** @param list<int> $indexes */
    private function hideHistoricalReferenceVideos(AikaipinProduct $product, array $indexes): void
    {
        $file = $product->referenceFilePayload();
        if ($file === null || $indexes === []) return;

        $disk = Storage::disk($file['disk']);
        $hiddenPath = $file['path'].'.erp-hidden-videos.json';
        $existing = $disk->exists($hiddenPath)
            ? (array) (json_decode($disk->get($hiddenPath), true) ?: [])
            : [];
        $hidden = collect([...$existing, ...$indexes])
            ->map(static fn ($index): int => (int) $index)
            ->filter(static fn (int $index): bool => $index >= 0)
            ->unique()
            ->sort()
            ->values()
            ->all();

        $disk->put($hiddenPath, json_encode($hidden, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    /** @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function shopifyImportPayload(array $payload): array
    {
        $variants = collect($payload['variants'] ?? [])->map(static fn (array $variant): array => [
            'sku' => (string) ($variant['sku'] ?? ''),
            'price' => number_format((float) ($variant['price'] ?? 0), 2, '.', ''),
            'inventory_quantity' => (int) ($variant['inventory_quantity'] ?? 0),
            'options' => collect($variant['options'] ?? [])->map(static fn (array $option): string => trim((string) ($option['name'] ?? '')).': '.trim((string) ($option['value'] ?? ''))
            )->values()->all(),
        ])->values();

        return [
            'title' => (string) ($payload['title'] ?? ''),
            'handle' => (string) ($payload['handle'] ?? ''),
            'vendor' => (string) ($payload['vendor'] ?? ''),
            'product_type' => (string) ($payload['product_type'] ?? ''),
            'status' => (string) ($payload['status'] ?? ''),
            'published' => (bool) ($payload['published'] ?? false),
            'source_file' => (string) ($payload['source_file'] ?? ''),
            'imported_at' => (string) ($payload['imported_at'] ?? ''),
            'description_length' => mb_strlen((string) ($payload['description_html'] ?? '')),
            'variant_count' => $variants->count(),
            'image_count' => count((array) ($payload['images'] ?? [])),
            'variants' => $variants->all(),
        ];
    }

    private function shopifyImportCacheKey(string $token): string
    {
        return 'aikaipin:product-library:shopify-import:'.$token;
    }

    private function deleteUploadSession(AikaipinProductUploadSession $session): void
    {
        $this->storage->deleteUploadTemporaryFiles($session);
        $session->parts()->delete();
        $session->delete();
    }

    /** @param iterable<AikaipinProductUploadSession> $sessions */
    private function deleteCompletedUploadSessions(iterable $sessions): void
    {
        foreach ($sessions as $session) {
            try {
                $this->deleteUploadSession($session);
            } catch (Throwable $exception) {
                report($exception);
            }
        }
    }

    private function canViewProduct(AdminUser $user, AikaipinProduct $product): bool
    {
        if ($this->authorization->canManageProductLibrary($user)) {
            return true;
        }

        $departmentIds = $this->authorization->operationDepartmentIdsForUser($user);

        return $departmentIds !== []
            && array_intersect($departmentIds, $product->visibleDepartmentIds()) !== [];
    }

    /** @return array{keyword:string} */
    private function placementEvaluationFilters(Request $request): array
    {
        return [
            'keyword' => trim((string) $request->query('keyword', '')),
        ];
    }

    /** @return array{product_id:int,test_started_on:string,data_ended_on:string,remark:?string,records:list<array{platform:string,currency:string,actual_spend:string|int|float,orders:string|int}>} */
    private function validatedPlacementEvaluationData(Request $request): array
    {
        return $request->validate([
            'product_id' => ['required', 'integer', 'min:1'],
            'test_started_on' => ['required', 'date'],
            'data_ended_on' => ['required', 'date', 'after_or_equal:test_started_on'],
            'remark' => ['nullable', 'string', 'max:2000'],
            'records' => ['required', 'array', 'min:1', 'max:60'],
            'records.*.platform' => ['required', 'in:facebook,google,tiktok,mediago,newsbreak,applovin'],
            'records.*.currency' => ['required', 'in:usd,eur,cny'],
            'records.*.actual_spend' => ['required', 'numeric', 'min:0', 'max:99999999999999.99'],
            'records.*.orders' => ['required', 'integer', 'min:0', 'max:4294967295'],
            'records.*.roi' => ['required', 'numeric', 'min:0', 'max:99999999.9999'],
        ]);
    }

    /** @param list<array{platform:string,currency:string,actual_spend:string|int|float,orders:string|int}> $records
     * @return list<array{platform:string,currency:string,actual_spend:string,orders:int}>
     */
    private function placementEvaluationRecords(array $records): array
    {
        return collect($records)
            ->map(static fn (array $record): array => [
                'platform' => (string) $record['platform'],
                'currency' => (string) $record['currency'],
                'actual_spend' => (string) $record['actual_spend'],
                'orders' => (int) $record['orders'],
                'roi' => (string) $record['roi'],
            ])
            ->values()
            ->all();
    }

    private function placementEvaluationProduct(AdminUser $user, int $productId): AikaipinProduct
    {
        $product = AikaipinProduct::query()->find($productId);
        if ($product === null || ! $this->canViewProduct($user, $product)) {
            throw ValidationException::withMessages([
                'product_id' => __('aikaipin.placement_evaluation.messages.related_product_invalid_message'),
            ]);
        }

        return $product;
    }

    /** @param array{keyword:string} $filters */
    private function placementEvaluationQuery(AdminUser $user, bool $canReviewAll, array $filters): Builder
    {
        $query = AikaipinPlacementEvaluation::query()
            ->with('records')
            ->latest('updated_at')
            ->latest('id');

        if (! $canReviewAll) {
            $query->where('created_by', $user->getKey());
        }
        if ($filters['keyword'] !== '') {
            $like = '%'.$filters['keyword'].'%';
            $query->where(function (Builder $evaluations) use ($like): void {
                $evaluations->where('evaluation_code', 'like', $like)
                    ->orWhere('product_code', 'like', $like)
                    ->orWhere('product_name', 'like', $like);
            });
        }

        return $query;
    }

    private function canViewPlacementEvaluation(AdminUser $user, AikaipinPlacementEvaluation $evaluation): bool
    {
        return $this->authorization->canManageProductLibrary($user)
            || (int) $evaluation->created_by === (int) $user->getKey();
    }

    private function canEditPlacementEvaluation(AdminUser $user, AikaipinPlacementEvaluation $evaluation): bool
    {
        return (int) $evaluation->created_by === (int) $user->getKey();
    }

    /** @return array<string, mixed> */
    private function placementEvaluationPayload(AdminUser $user, AikaipinPlacementEvaluation $evaluation): array
    {
        return [
            'id' => (int) $evaluation->getKey(),
            'evaluation_code' => (string) $evaluation->evaluation_code,
            'product' => [
                'id' => (int) $evaluation->product_id,
                'code' => (string) $evaluation->product_code,
                'name' => (string) $evaluation->product_name,
            ],
            'test_started_on' => $evaluation->test_started_on?->toDateString(),
            'data_ended_on' => $evaluation->data_ended_on?->toDateString(),
            'remark' => $evaluation->remark,
            'created_by_name' => $evaluation->created_by_name,
            'created_at' => $evaluation->created_at?->toAtomString(),
            'updated_at' => $evaluation->updated_at?->toAtomString(),
            'can_edit' => $this->canEditPlacementEvaluation($user, $evaluation),
            'records' => $evaluation->records->map(static fn (AikaipinPlacementEvaluationRecord $record): array => [
                'id' => (int) $record->getKey(),
                'platform' => (string) $record->platform,
                'currency' => (string) $record->currency,
                'actual_spend' => (string) $record->actual_spend,
                'orders' => (int) $record->orders,
                'roi' => $record->roi !== null ? (string) $record->roi : null,
            ])->values()->all(),
        ];
    }

    private function nextPlacementEvaluationCode(): string
    {
        $connection = config('admin.database.connection') ?: config('database.default');
        $period = now()->format('Ym');
        $sequences = DB::connection($connection)->table('aikaipin_placement_evaluation_code_sequences');
        $sequences->insertOrIgnore([
            'period' => $period,
            'last_number' => 0,
            'updated_at' => now(),
        ]);
        $sequence = $sequences->where('period', $period)->lockForUpdate()->first();
        $nextNumber = (int) ($sequence->last_number ?? 0) + 1;
        $sequences->where('period', $period)->update([
            'last_number' => $nextNumber,
            'updated_at' => now(),
        ]);

        return sprintf('ATE-%s-%06d', $period, $nextNumber);
    }

    private function productCodeForId(int $productId): string
    {
        return 'kky-'.$productId;
    }

    private function temporaryProductCode(): string
    {
        return 'pending-'.strtolower(Str::random(20));
    }

    /** @return array{keyword:string} */
    private function selectionProposalFilters(Request $request): array
    {
        return [
            'keyword' => trim((string) $request->query('keyword', '')),
        ];
    }

    /** @param list<mixed> $values
     * @return list<string>
     */
    private function selectionProposalTagValues(array $values): array
    {
        return collect($values)
            ->map(static fn ($value): string => trim(preg_replace('/\s+/u', ' ', (string) $value) ?: ''))
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    /** @param list<string> $specifications
     * @param  list<string>  $attributes
     */
    private function syncSelectionProposalTags(AikaipinSelectionProposal $proposal, array $specifications, array $attributes): void
    {
        $proposal->tags()->delete();
        foreach ($specifications as $sort => $value) {
            $proposal->tags()->create([
                'type' => AikaipinSelectionProposalTag::TYPE_SPECIFICATION,
                'value' => $value,
                'sort' => $sort,
            ]);
        }
        foreach ($attributes as $sort => $value) {
            $proposal->tags()->create([
                'type' => AikaipinSelectionProposalTag::TYPE_ATTRIBUTE,
                'value' => $value,
                'sort' => $sort,
            ]);
        }
    }

    /** @param array{keyword:string} $filters */
    private function selectionProposalQuery(AdminUser $user, bool $canReviewAll, array $filters): Builder
    {
        $query = AikaipinSelectionProposal::query()
            ->with(['tags', 'images'])
            ->latest('updated_at')
            ->latest('id');

        if (! $canReviewAll) {
            $query->where('created_by', $user->getKey());
        }
        if ($filters['keyword'] !== '') {
            $like = '%'.$filters['keyword'].'%';
            $query->where(function (Builder $proposals) use ($like): void {
                $proposals->where('proposal_code', 'like', $like)
                    ->orWhere('product_name', 'like', $like)
                    ->orWhereHas('tags', static fn (Builder $tags) => $tags->where('value', 'like', $like));
            });
        }

        return $query;
    }

    private function canViewSelectionProposal(AdminUser $user, AikaipinSelectionProposal $proposal): bool
    {
        return $this->authorization->canManageProductLibrary($user)
            || (int) $proposal->created_by === (int) $user->getKey();
    }

    private function canEditSelectionProposal(AdminUser $user, AikaipinSelectionProposal $proposal): bool
    {
        return $proposal->withdrawn_at === null
            && (int) $proposal->created_by === (int) $user->getKey();
    }

    /** @return array<string, mixed> */
    private function selectionProposalPayload(AdminUser $user, AikaipinSelectionProposal $proposal): array
    {
        return [
            'id' => (int) $proposal->getKey(),
            'proposal_code' => (string) $proposal->proposal_code,
            'product_name' => (string) $proposal->product_name,
            'specifications' => $proposal->tags
                ->where('type', AikaipinSelectionProposalTag::TYPE_SPECIFICATION)
                ->pluck('value')
                ->values()
                ->all(),
            'attributes' => $proposal->tags
                ->where('type', AikaipinSelectionProposalTag::TYPE_ATTRIBUTE)
                ->pluck('value')
                ->values()
                ->all(),
            'link_1688' => $proposal->link_1688,
            'competitor_url' => $proposal->competitor_url,
            'remark' => $proposal->remark,
            'created_by_name' => $proposal->created_by_name,
            'created_at' => $proposal->created_at?->toAtomString(),
            'updated_at' => $proposal->updated_at?->toAtomString(),
            'withdrawn_at' => $proposal->withdrawn_at?->toAtomString(),
            'can_edit' => $this->canEditSelectionProposal($user, $proposal),
            'images' => $proposal->images->map(function (AikaipinSelectionProposalImage $image) use ($proposal): array {
                return [
                    'id' => (int) $image->getKey(),
                    'name' => (string) $image->original_name,
                    'url' => route('aikaipin.selection-proposals.images.show', ['proposal' => $proposal, 'image' => $image]),
                ];
            })->values()->all(),
        ];
    }

    private function nextSelectionProposalCode(): string
    {
        $connection = config('admin.database.connection') ?: config('database.default');
        $period = now()->format('Ym');
        $sequences = DB::connection($connection)->table('aikaipin_selection_proposal_code_sequences');
        $sequences->insertOrIgnore([
            'period' => $period,
            'last_number' => 0,
            'updated_at' => now(),
        ]);
        $sequence = $sequences->where('period', $period)->lockForUpdate()->first();
        $nextNumber = (int) ($sequence->last_number ?? 0) + 1;
        $sequences->where('period', $period)->update([
            'last_number' => $nextNumber,
            'updated_at' => now(),
        ]);

        return sprintf('SPR-%s-%06d', $period, $nextNumber);
    }

    /** @return array{keyword:string,category:string,source:string,type:string} */
    private function productFilters(Request $request): array
    {
        return [
            'keyword' => trim((string) $request->query('keyword', '')),
            'category' => trim((string) $request->query('category', '')),
            'source' => trim((string) $request->query('source', '')),
            'type' => trim((string) $request->query('type', '')),
        ];
    }

    /**
     * @param  array{keyword:string,category:string,source:string,type:string}  $filters
     */
    private function productQuery(AdminUser $user, bool $canManageProductLibrary, array $filters): Builder
    {
        $query = AikaipinProduct::query()
            ->select([
                'id', 'product_code', 'name', 'sku', 'categories', 'source_platform', 'product_type',
                'landing_page_url', 'images', 'reference_file', 'package_file', 'visible_department_ids', 'is_published',
                'created_at', 'updated_at',
            ])
            ->with(['productPages:id,aikaipin_product_id,name,landing_page_url,is_default'])
            ->withCount('productPages')
            ->selectRaw('shopify_data IS NOT NULL AS has_shopify_data')
            ->latest('created_at')
            ->latest('id');

        if (! $canManageProductLibrary) {
            $departmentIds = $this->authorization->operationDepartmentIdsForUser($user);

            if ($departmentIds === []) {
                $query->whereRaw('1 = 0');
            } else {
                $query->where(function (Builder $products) use ($departmentIds): void {
                    foreach ($departmentIds as $departmentId) {
                        $products->orWhereJsonContains('visible_department_ids', (int) $departmentId);
                    }
                });
            }
        }

        if ($filters['keyword'] !== '') {
            $like = '%'.$filters['keyword'].'%';

            $query->where(function (Builder $products) use ($like): void {
                $products->where('product_code', 'like', $like)
                    ->orWhere('name', 'like', $like)
                    ->orWhere('sku', 'like', $like);
            });
        }

        if ($filters['category'] !== '') {
            $query->whereJsonContains('categories', $filters['category']);
        }

        if ($filters['source'] !== '') {
            $query->where('source_platform', $filters['source']);
        }

        if ($filters['type'] !== '') {
            $query->where('product_type', $filters['type']);
        }

        return $query;
    }

    /** @return list<array{value:string,label:string}> */
    private function productCategoryOptions(): array
    {
        return Cache::remember(self::PRODUCT_CATEGORY_OPTIONS_CACHE_KEY, now()->addMinutes(30), function (): array {
            return AikaipinProduct::query()
                ->whereNotNull('categories')
                ->select('categories')
                ->distinct()
                ->get()
                ->flatMap(static fn (AikaipinProduct $product): array => $product->categoryValues())
                ->map(static fn (string $category): string => trim($category))
                ->filter()
                ->unique(static fn (string $category): string => mb_strtolower($category))
                ->sort(static fn (string $left, string $right): int => strnatcasecmp($left, $right))
                ->values()
                ->map(static fn (string $category): array => ['value' => $category, 'label' => $category])
                ->all();
        });
    }

    /** @param iterable<mixed> $values
     * @return list<string>
     */
    private function normalizeProductValues(iterable $values): array
    {
        $seen = [];
        $normalized = [];

        foreach ($values as $value) {
            $item = trim(preg_replace('/\s+/u', ' ', (string) $value) ?: '');
            $key = mb_strtolower($item);

            if ($item === '' || isset($seen[$key])) {
                continue;
            }

            $seen[$key] = true;
            $normalized[] = $item;
        }

        return $normalized;
    }

    /** @param iterable<mixed> $values */
    private function joinProductValues(iterable $values): ?string
    {
        $items = $this->normalizeProductValues($values);

        return $items === [] ? null : implode(',', $items);
    }

    /** @param array{path:string,original_name:string,mime_type:?string,size:int,sha256:string} $payload
     * @return array{disk:string,path:string,original_name:string,mime_type:?string,size:int,sha256:?string}
     */
    private function productFilePayload(array $payload): array
    {
        return [
            'disk' => AikaipinProductLibraryStorageService::DISK,
            'path' => (string) $payload['path'],
            'original_name' => (string) $payload['original_name'],
            'mime_type' => $payload['mime_type'] ?: null,
            'size' => (int) $payload['size'],
            'sha256' => $payload['sha256'] ?: null,
        ];
    }

    /**
     * Temporary frontend-only sample data.
     *
     * @return list<array{
     *     code:string,
     *     name_key:string,
     *     skus:list<string>,
     *     category:string,
     *     source:string,
     *     type:string,
     *     images:list<array{url:?string}>,
     *     landing_url:string,
     *     reference_url:string,
     *     updated_at:string
     * }>
     */
    private function sampleProducts(): array
    {
        return [
            [
                'code' => 'AKP-202610-000001',
                'name_key' => 'samples.products.foldable_organizer',
                'skus' => ['FDO-GRY-01', 'FDO-BLK-01', 'FDO-WHT-01'],
                'category' => 'home_living',
                'source' => 'tiktok',
                'type' => 'trending_product',
                'images' => [['url' => null], ['url' => null], ['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000001',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000001',
                'updated_at' => '2026-10-19 09:36',
            ],
            [
                'code' => 'AKP-202610-000002',
                'name_key' => 'samples.products.portable_blender',
                'skus' => ['PBL-PNK-01'],
                'category' => 'kitchen',
                'source' => 'amazon',
                'type' => 'competitive_product',
                'images' => [['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000002',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000002',
                'updated_at' => '2026-10-19 08:52',
            ],
            [
                'code' => 'AKP-202610-000003',
                'name_key' => 'samples.products.pocket_projector',
                'skus' => ['PPR-SLV-01', 'PPR-BLU-01'],
                'category' => 'electronics',
                'source' => 'independent_store',
                'type' => 'seasonal_product',
                'images' => [['url' => null], ['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000003',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000003',
                'updated_at' => '2026-10-18 21:14',
            ],
            [
                'code' => 'AKP-202610-000004',
                'name_key' => 'samples.products.pet_grooming_kit',
                'skus' => ['PGK-ORA-01', 'PGK-GRN-01', 'PGK-BLU-01', 'PGK-PNK-01'],
                'category' => 'pet_supplies',
                'source' => 'tiktok',
                'type' => 'trending_product',
                'images' => [['url' => null], ['url' => null], ['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000004',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000004',
                'updated_at' => '2026-10-18 16:30',
            ],
            [
                'code' => 'AKP-202610-000005',
                'name_key' => 'samples.products.travel_jewelry_case',
                'skus' => ['TJC-BEI-01'],
                'category' => 'fashion_accessories',
                'source' => 'facebook',
                'type' => 'test_product',
                'images' => [['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000005',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000005',
                'updated_at' => '2026-10-18 11:05',
            ],
            [
                'code' => 'AKP-202610-000006',
                'name_key' => 'samples.products.led_book_light',
                'skus' => ['LBL-AMB-01', 'LBL-WHT-01'],
                'category' => 'home_living',
                'source' => 'amazon',
                'type' => 'competitive_product',
                'images' => [['url' => null], ['url' => null]],
                'landing_url' => 'https://example.invalid/aikaipin/landing/AKP-202610-000006',
                'reference_url' => 'https://example.invalid/aikaipin/reference/AKP-202610-000006',
                'updated_at' => '2026-10-17 18:40',
            ],
        ];
    }

    /**
     * Temporary frontend-only sample data.
     *
     * @return list<array{
     *     code:string,
     *     name_key:string,
     *     specification_keys:list<string>,
     *     attribute_keys:list<string>,
     *     updated_at:string
     * }>
     */
    private function sampleSelectionProposals(): array
    {
        return [
            [
                'code' => 'SPR-202610-000001',
                'name_key' => 'samples.proposals.portable_camping_lamp',
                'specification_keys' => [
                    'samples.proposal_options.specifications.warm_white',
                    'samples.proposal_options.specifications.us_plug',
                ],
                'attribute_keys' => [
                    'samples.proposal_options.attributes.rechargeable',
                    'samples.proposal_options.attributes.waterproof',
                ],
                'updated_at' => '2026-10-19 10:26',
            ],
            [
                'code' => 'SPR-202610-000002',
                'name_key' => 'samples.proposals.travel_pill_organizer',
                'specification_keys' => [
                    'samples.proposal_options.specifications.seven_day',
                ],
                'attribute_keys' => [
                    'samples.proposal_options.attributes.portable',
                    'samples.proposal_options.attributes.large_capacity',
                ],
                'updated_at' => '2026-10-18 15:40',
            ],
        ];
    }

    /**
     * Temporary frontend-only sample data.
     *
     * @return list<array{
     *     code:string,
     *     product_code:string,
     *     product_name_key:string,
     *     start_date:string,
     *     end_date:string,
     *     records:list<array{platform:string,currency:string,spend:string,orders:string}>,
     *     updated_at:string
     * }>
     */
    private function samplePlacementEvaluations(): array
    {
        return [
            [
                'code' => 'ATE-202610-000001',
                'product_code' => 'AKP-202610-000001',
                'product_name_key' => 'samples.products.foldable_organizer',
                'start_date' => '2026-10-10',
                'end_date' => '2026-10-16',
                'records' => [
                    ['platform' => 'facebook', 'currency' => 'usd', 'spend' => '168.20', 'orders' => '12'],
                    ['platform' => 'tiktok', 'currency' => 'usd', 'spend' => '96.50', 'orders' => '8'],
                ],
                'updated_at' => '2026-10-19 09:15',
            ],
            [
                'code' => 'ATE-202610-000002',
                'product_code' => 'AKP-202610-000003',
                'product_name_key' => 'samples.products.pocket_projector',
                'start_date' => '2026-10-05',
                'end_date' => '2026-10-12',
                'records' => [
                    ['platform' => 'google', 'currency' => 'eur', 'spend' => '142.00', 'orders' => '6'],
                ],
                'updated_at' => '2026-10-18 18:22',
            ],
        ];
    }
}
