<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class OperationReport extends Model
{
    use SoftDeletes;

    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';

    protected $fillable = [
        'report_date', 'operator_user_id', 'operator_name', 'operation_department_id',
        'operation_department_name', 'metric_rows', 'advertising_rows',
        'first_purchase_cost', 'first_shipping_cost', 'first_return_fee', 'actual_ad_spend',
        'first_profit', 'renewal_net_revenue', 'overall_profit', 'status', 'submitted_by',
        'submitted_at', 'reviewed_by', 'reviewed_at', 'review_reason',
        'deletion_key',
    ];

    protected static function booted(): void
    {
        static::deleting(function (self $report): void {
            if (! $report->isForceDeleting() && (int) $report->deletion_key === 0) {
                // Keep the soft-deleted row for audit history, while removing
                // it from the active date/operator unique-key slot.
                $report->forceFill(['deletion_key' => (int) $report->getKey()])->saveQuietly();
            }
        });
    }

    public function __construct(array $attributes = [])
    {
        $this->setConnection(config('admin.database.connection') ?: config('database.default'));
        parent::__construct($attributes);
    }

    protected function casts(): array
    {
        return [
            'report_date' => 'date:Y-m-d',
            'metric_rows' => 'array',
            'advertising_rows' => 'array',
            'submitted_at' => 'datetime',
            'reviewed_at' => 'datetime',
            'deleted_at' => 'datetime',
        ];
    }

    public function operator(): BelongsTo
    {
        return $this->belongsTo(AdminUser::class, 'operator_user_id');
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(AdminUser::class, 'reviewed_by');
    }

    public function operationDepartment(): BelongsTo
    {
        return $this->belongsTo(Department::class, 'operation_department_id');
    }

    public function statusLabel(): string
    {
        return match ($this->status) {
            self::STATUS_APPROVED => '已审核',
            self::STATUS_REJECTED => '审核不通过',
            default => '待审核',
        };
    }
}
